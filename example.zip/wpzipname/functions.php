<?php

define ( 'PREVIOUS_VERSION', '1.0.6.2' );
define ( 'CURRENT_VERSION', '1.0.6.3' );

require_once( 'lib/Feedback/feedback.php' );


add_action('wp_ajax_nopriv_siren_user_login', 'siren_process_ajax_login' );


add_action( 'wp_enqueue_scripts', 'md_elementor_child_theme' );

function md_elementor_child_theme() 
{
    
    $page_url = esc_url( $_SERVER['REQUEST_URI'] );
    
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    
    wp_enqueue_style( 'child-style',  get_stylesheet_directory_uri() . '/style.css', array( 'parent-style' ), wp_get_theme()->get('Version') );
    
    wp_enqueue_style( 'main', get_stylesheet_directory_uri() . '/css/main.css', array( 'font-awesome' ) );

    wp_enqueue_style( 'font-awesome', get_stylesheet_directory_uri() . "/dist/font-awesome-4.7.0/css/font-awesome.min.css" );

    wp_enqueue_style( 'daterangepicker', get_stylesheet_directory_uri() . "/dist/daterangepicker.min.css" );
    
    wp_enqueue_script( 'jquery');
    wp_enqueue_script( 'bootstrap', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', array(), '', true );
   
    wp_enqueue_script( 'venu-ajax', get_stylesheet_directory_uri() . '/js/venu_ajax.js', array('jquery') );
    wp_localize_script( 'venu-ajax', 'venu_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

    wp_enqueue_script( 'course-select-ajax', get_stylesheet_directory_uri() . '/js/course-selector-ajax.js', array('jquery') );
    wp_enqueue_script( 'course-selector-js', get_stylesheet_directory_uri() . '/js/course-selector.js', array('jquery') );
    wp_localize_script( 'course-select-ajax', 'course_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

	wp_enqueue_script( 'moment_js', get_stylesheet_directory_uri() . "/dist/moment.min.js" );
    
	wp_enqueue_script( 'daterangepicker_js', get_stylesheet_directory_uri() . "/dist/jquery.daterangepicker.min.js" );


}

add_action( 'wp_print_styles', 'siren_dashbaord_classroom_styles' );

function siren_dashbaord_classroom_styles() 
{

    $page_url = esc_url( $_SERVER['REQUEST_URI'] );

    // Load the css on any dashboard page
    if ( strpos( $page_url, "/dashboard/" ) !== FALSE )
    {
        // wp_die( get_stylesheet_directory_uri() . '/css/dashboard.css' );
        wp_enqueue_style( 'siren_dashboard', get_stylesheet_directory_uri() . '/css/dashboard.css' ); 

    // global $wp_styles;

    //     wp_die( "<pre>".print_r( $wp_styles, true )."</pre>" );

      $localize_data = array(
        'ajaxurl'       => admin_url('admin-ajax.php'),
        'nonce_key'     => tutor()->nonce,
        tutor()->nonce  => wp_create_nonce( tutor()->nonce_action ),
        //'options'       => $options,
        'placeholder_img_src' => tutor_placeholder_img_src(),
        'enable_lesson_classic_editor' => get_tutor_option('enable_lesson_classic_editor'),

        'text' => array(
          'assignment_text_validation_msg' => __('Assignment answer can not be empty', 'tutor'),
        )
      );  
    
      $localize_data = apply_filters('tutor_localize_data', $localize_data);
    
      wp_enqueue_script( 'jquery');
      
      wp_enqueue_script( 'tutor-main', tutor()->url . 'assets/js/tutor.js', array( 'jquery' ), tutor()->version, true );
			wp_enqueue_script( 'tutor-frontend', tutor()->url . 'assets/js/tutor-front.js', array( 'jquery' ), tutor()->version, true );
			wp_localize_script('tutor-frontend', '_tutorobject', $localize_data);
      
      wp_enqueue_script( 'main-js', get_stylesheet_directory_uri() . '/js/main.js', array( 'jquery', 'bootstrap' ) );
      
    }

    // Load the company-learners.js only on the company-learners page
    if ( strpos( $page_url, "/company-learners/" ) !== FALSE )
    {

      wp_enqueue_script( 'company-learners-js', get_stylesheet_directory_uri() . '/js/company-learners.js', array( 'jquery', 'bootstrap' ) );

    }
}

add_action( 'init', 'siren_schedule_daily_event_new');

function siren_schedule_daily_event_new() {
  if( !wp_next_scheduled( 'email_cron_job_new' ) ) {
    wp_schedule_event(time(), 'daily', 'email_cron_job_new');
  }
}

if ( class_exists ( "Twig_Loader_Filesystem" ) )
$theme_loader = new Twig_Loader_Filesystem( get_stylesheet_directory().'/templates/' );

$theme_uploads = wp_upload_dir();

if ( class_exists ( "Twig_Environment" ) )
$theme_twig = new Twig_Environment( $theme_loader, array( 'cache' => $theme_uploads[ 'path' ].'/twiglets', 'auto_reload' => true ) );

// Remove cross-sells at cart

remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );


add_action( 'wp_login_failed', 'my_front_end_login_fail' );  // hook failed login

function my_front_end_login_fail( $username )
{

  $referrer = $_SERVER['HTTP_REFERER'];  // where did the post submission come from?
  // if there's a valid referrer, and it's not the default log-in screen
  if ( !empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin') )
  {
    if ( !empty( $_POST['redirect_to'] ) )
    wp_redirect( $_POST['redirect_to'] . '?login=failed' );  // let's append some information (login=failed) to the URL for the theme to use
    else
    wp_redirect( $referrer . '?login=failed' );  // let's append some information (login=failed) to the URL for the theme to use
    exit;
  }
}

add_action( 'init', 'siren_url_rewrites_init' );
function siren_url_rewrites_init(){
  add_rewrite_rule(
      '^trainers/([^/]*)/course/([^/]*)/?$',
      'index.php?pagename=tc-details&trainer_id=$matches[1]&course_id=$matches[2]',
      'top' );

    add_rewrite_rule(
        '^course-details/([^/]*)/trainer/([^/]*)/?$',
        'index.php?pagename=course-details&trainer_id=$matches[2]&course_id=$matches[1]',
        'top' );

    add_rewrite_rule(
        '^pdf-generator/([^/]*)/([^/]*)/?$',
        'index.php?pagename=pdf-generator&pdf=$matches[1]&_id=$matches[2]',
        'top' );

    add_rewrite_rule(
    '^feedback/([^/]*)/([^/]*)/?$',
    'index.php?pagename=course-feedback&course_id=$matches[1]&learner_id=$matches[2]',
    'top' );

    add_rewrite_rule('^add-attendee/([^/]*)/?$',
    'index.php?pagename=add-attendee&course_id=$matches[1]', 'top');


    // add_rewrite_rule(
    //   '^corporate/?$',
    //   'index.php?pagename=corp-dashboard',
    //   'top' );

    // add_rewrite_rule(
    //   '^corporate/([^/]*)/?$',
    //   'index.php?pagename=corp-dashboard&tag=$matches[1]',
    //   'top' );

    add_rewrite_rule(
      '^corporate/?$',
      'index.php?pagename=corporate&siren_corporate_page=dashboard',
      'top' );

    add_rewrite_rule(
      '^corporate/([^/]*)/?$',
      'index.php?pagename=corporate&siren_corporate_page=$matches[1]',
      'top' );

    // add_rewrite_rule(
    //   '^corporate/([^/]*)/learners/?$',
    //   'index.php?pagename=corp-learners&tag=$matches[1]',
    //   'top' );
  

    flush_rewrite_rules(  );

}

add_filter( 'query_vars', 'siren_add_query_vars' );
function siren_add_query_vars( $query_vars ){
    $query_vars[] = 'trainer_id';
    $query_vars[] = 'course_id';
    $query_vars[] = 'pdf';
    $query_vars[] = '_id';
    $query_vars[] = '_id2';
    $query_vars[] = 'learner_id';
    $query_vars[] = 'syllabus';
    $query_vars[] = 'siren_corporate_page';
    $query_vars[] = 'page';
    $query_vars[] = 'order_by';
    $query_vars[] = 'sort_by';

    return $query_vars;
}


add_filter('template_include', 'siren_template_include', 1, 1);
function siren_template_include($template)
{
global $wp, $wp_query; //Load $wp_query object

    $page_name = $wp_query->query_vars['pagename'];

    if ($page_name)
    {
        switch ($page_name)
        {
            case  "course-details" :
                $wp_query->is_404 = false;
                status_header( 200 );

                $template =  get_stylesheet_directory().'/page-course-details.php'; //Load your template or file
                break;

            case 'pdf-generator' :
               
                $wp_query->is_404 = false;
                status_header( 200 );

                $template =  get_stylesheet_directory().'/page-pdf-generator.php'; //Load your template or file
                break;

            case 'course-feedback' :
                $wp_query->is_404 = false;
                status_header( 200 );

                $template =  get_stylesheet_directory().'/page-feedback.php'; //Load your template or file
                break;

            case 'add-attendee' :
                $wp_query->is_404 = false;
                status_header( 200 );

                $template = get_stylesheet_directory() . '/page-add-attendee.php';
                break;

            // case 'corporate' :
            //     $wp_query->is_404 = false;
            //     status_header( 200 );

            //     if ( is_user_logged_in() )
            //     {
            //         $slug = $wp_query->query_vars['siren_corporate_page'];

            //         if ( "logout" == $slug )
            //         {
            //             wp_logout();
            //             $template = get_stylesheet_directory() . '/templates/corporate/login.php';
            //         }
            //         else
            //             $template = get_stylesheet_directory() . '/templates/corporate/index.php';

            //     }
            //     else
            //         $template = get_stylesheet_directory() . '/templates/corporate/login.php';
            //     break;

          }
    }

    // wp_die( $template ) ;

    return $template; //Load normal template when $page_value != "true" as a fallback
}

// * @hooked woocommerce_template_single_meta - 40

function siren_product_courses( )
{
    echo "<h2>"."Courses"."</h2>";
}

remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);

add_action( 'woocommerce_single_product_summary', 'siren_product_courses', 20 );

add_shortcode( "course_firstaid", "course_firstaid_shortcode" );
add_shortcode( "course_paediatric", "course_paediatric_shortcode" );
add_shortcode( "course_mhfa", "course_mhfa_shortcode" );
add_shortcode( "course_fst", "course_fst_shortcode" );


add_shortcode( "course_calendar", "course_calendar_shortcode" );
add_shortcode( "global_course_calendar", "global_course_calendar_shortcode" );
add_shortcode( "booker_course_calendar", "booker_course_calendar_shortcode" );

function get_total_stock( $product = null ) 
{

    if ( $product == null )
        return 0;
        
    if ( sizeof( $product->get_children() ) > 0 ) 
    {
        $total_stock = max( 0, $product->get_stock_quantity() );

        foreach ( $product->get_children() as $child_id ) 
        {
            if ( 'yes' === get_post_meta( $child_id, '_manage_stock', true ) ) 
            {
                $stock = get_post_meta( $child_id, '_stock', true );
                $total_stock += max( 0, wc_stock_amount( $stock ) );
            }
        }
    } 
    else 
    {
      $total_stock = $product->get_stock_quantity();
    }
    
    return wc_stock_amount( $total_stock );
}


function course_calendar_shortcode1( $atts )
{

  global $wpdb, $post;
    $postID = $post->ID;
  // May need $atts later
  if ( !empty( $atts ) )  {
    // use shortcode_atts() to set defaults then extract() to variables
    extract( shortcode_atts( array( 'id' => false ), $atts ) );
    $postID = $id;
  }

  $get_google_api_key = get_option('custom_google_api_key');


  $events = get_posts(
    array(
      'posts_per_page' => -1,
      'post_type' => 'product_variation',
      'post_parent' => $postID,
      'nopaging' => true,
      'post_status' => 'publish',
      'meta_query' => array (
        array (
          'relation' => 'AND',
          '_calendar_data' => array (
            'key' => '_calendar_data',
            'compare' => 'EXISTS',
          ),
          '_venue_code' => array (
            'key' => '_venue_code',
            'value' => 'none',
            'compare' => '!=',
          ),
          '_start_date' => array (
            'key' => '_start_date',
            'value' => time(),
            'compare' => '>',
          ),
          '_private_course' => array (
            'key' => '_private_course',
            'compare' => 'NOT EXISTS',
          ),
        )
      ),
      'orderby' => array (
        //'_venue_code' => 'DESC',
        '_start_date' => 'ASC'
      )
    )
  );

  //echo "<pre>".print_r( $events, true )."</pre>";

  $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

  $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

  if ( $price_display_suffix )
  {
    $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
  }

  $CxVLondon = array();

  foreach( $events as $event )
  {
    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

    $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

    $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

    /* Why? */
    global $wpdb;

    $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

    $venue_order_num = $get_gallery_main[0]->menu_order;

    if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
      continue;
    }

    $product_data = $event;

    $product = wc_setup_product_data( $product_data );

    $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

    if ( !isset ( $CxVLondon[$venue_order_num] ) )
    $CxVLondon[$venue_order_num] = $calendar_data['venue'];

    if ( $product->is_in_stock() )
    $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
    else
    $booking_link = "Sorry, course fully booked";

    $sale_price = $product->get_sale_price();

    $regular_price = $product->get_regular_price();

    $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

    if ( isset( $venue_meta['address'] ) )
    $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
    else
    $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

    $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
    $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

    $CxVLondon[$venue_order_num]['courses'][] = array (
      'p' => $event,
      'm' => $calendar_data,
      'sa' => get_total_stock( $product ),
                  'regularprice' => $regular_price,
                  'saleprice' => $sale_price,
      'price' => $price,
      'booking' => $booking_link,
    );
  }

          ksort($CxVLondon);

  $CxVBirmingham = array();

  foreach( $events as $event )
  {
    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

    $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

    $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

              global $wpdb;

              $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

              $venue_order_num = $get_gallery_main[0]->menu_order;

    if ($venue_meta['area'] !== 'birmingham') {
      continue;
    }

    $product_data = $event;

    $product = wc_setup_product_data( $product_data );

    $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

    if ( !isset ( $CxVBirmingham[$venue_order_num] ) )
    $CxVBirmingham[$venue_order_num] = $calendar_data['venue'];

    if ( $product->is_in_stock() )
    $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
    else
    $booking_link = "Sorry, course fully booked";

              $sale_price = $product->get_sale_price();

              $regular_price = $product->get_regular_price();

    $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

    if ( isset( $venue_meta['address'] ) )
    $CxVBirmingham[$venue_order_num]['meta'] = $venue_meta;
    else
    $CxVBirmingham[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

    $CxVBirmingham[$venue_order_num]['name'] = $venue_p->post_title;
    $CxVBirmingham[$venue_order_num]['area'] = $venue_meta['area'];

    $CxVBirmingham[$venue_order_num]['courses'][] = array (
      'p' => $event,
      'm' => $calendar_data,
      'sa' => get_total_stock( $product ),
                  'regularprice' => $regular_price,
                  'saleprice' => $sale_price,
      'price' => $price,
      'booking' => $booking_link,
    );
  }

          ksort($CxVBirmingham);

  $CxVManchester = array();

  foreach( $events as $event )
  {
    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

    $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

    $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

              global $wpdb;

              $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

              $venue_order_num = $get_gallery_main[0]->menu_order;

    if ($venue_meta['area'] !== 'manchester') {
      continue;
    }

    $product_data = $event;

    $product = wc_setup_product_data( $product_data );

    $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

    if ( !isset ( $CxVManchester[$venue_order_num] ) )
    $CxVManchester[$venue_order_num] = $calendar_data['venue'];

    if ( $product->is_in_stock() )
    $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
    else
    $booking_link = "Sorry, course fully booked";

    $sale_price = $product->get_sale_price();

    $regular_price = $product->get_regular_price();

    $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

    if ( isset( $venue_meta['address'] ) )
    $CxVManchester[$venue_order_num]['meta'] = $venue_meta;
    else
    $CxVManchester[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

    $CxVManchester[$venue_order_num]['name'] = $venue_p->post_title;
    $CxVManchester[$venue_order_num]['area'] = $venue_meta['area'];

    $CxVManchester[$venue_order_num]['courses'][] = array (
      'p' => $event,
      'm' => $calendar_data,
      'sa' => get_total_stock( $product ),
      'regularprice' => $regular_price,
      'saleprice' => $sale_price,
      'price' => $price,
      'booking' => $booking_link,
    );
  }
              
  ksort($CxVManchester);


  // echo "<pre>".print_r( $CxV, true )."</pre>";

  $output = ob_start( );
  // wc_print_notices();
  ?>
  <?php
          /*echo '<pre>';
          print_r($CxVLondon);
          echo '</pre>';*/

          ?>
  <h4>LONDON</h4>

  <div id="accordion" role='tablist' class="panel-group course-accordions" >
    <?php
    $in ="";
    foreach( $CxVLondon as $venue ) :
              /*echo '<pre>';
              print_r($venue);
              echo '</pre>';*/
      ?>
      <div class="panel panel-default">
        <div class="panel-heading <?php echo ( strpos( strtolower($venue['name']), 'old street' ) !== false ? "old-street" : "not-old-street" ) ; ?>"  role="tab" data-toggle="collapse" data-parent="#accordion" data-target="#collapse<?php echo "-".$venue['key']; ?>" href="#collapse<?php echo "-".$venue['key']; ?>">
          <h4 class="panel-title">
            <?php echo $venue['name']; ?><a  style="float:right"><i class="fa fa-plus"></i></a>
          </h4>
        </div>
        <div id="collapse<?php echo "-".$venue['key']; ?>" class="panel-collapse collapse <?php echo $in; ?>" role="tabpanel">
          <div class="panel-body">
            <table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width='100%'>
              <thead class='cf'>
                <tr>
                  <th data-firstsort="asc">Course Date</th>
                  <th>Time</th>
                  <th>Price</th>
                  <th>Seats Remaining</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach( $venue['courses'] as $course ) : ?>
                  <tr>
                    <td data-title='Course Date' ><?php echo dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ); ?></td>
                    <td data-title='Time'><?php echo date( "H:i", strtotime( $course['m']['start_date_time'] ) ); ?></td>
                    <td data-title='Price' >
                                              <?php if($course['saleprice']){ ?>
                                              <span class="product-sale-price"><?php echo ( "" != $course['regularprice'] ? sprintf( "%4.2lf", $course['regularprice']) . $price_display_suffix : "" ); ?></span>
                                              <?php } ?>
                                              <span class="<?php if($course['saleprice']){ echo "product-original-price"; } ?>"><?php echo ( "" != $course['price'] ? sprintf( "%4.2lf", $course['price']) . $price_display_suffix : "" ); ?></span>

                                              </td>
                    <td data-title='Seats Remaining'><?php echo ( 0 != $course['sa'] ? $course['sa'] : "" ); ?></td>
                    <td data-title='' ><?php echo $course['booking']; ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>

            <table class="location " width="100%">
              <tbody>
                <tr>
                  <td width="25%" valign='top'>
                    <div style="padding:0 10px;">
                      <h3>Address</h3>
                      <?php
                      echo preg_replace( "/\r\n|\r|\n/", "<br />", $venue['meta']['address'] );

                      echo "<br />".$venue['meta']['phone']."<br />";
                      echo $venue['meta']['url']."<br />";
                      echo $venue['meta']['email']."<br />";

                      ?>
                    </div>
                  </td>
                  <td width="50%" >
                    <div style='overflow:hidden;height:240px;width:100%;'>
                      <div id='gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>' style='height:inherit;width:inherit;' class="map_canvas"></div>
                      <style>
                        #gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> img{max-width:none!important;background:none!important}
                      </style>
                    </div>
                  </td>
                  <td  width="25%" valign='top'>
                    <div style="padding:0 10px;">
                      <h3>Cancellation</h3>
                      <ul>
                        <li>More than 7 days = Money Back</li>
                        <li>48 Hours - 7 Days = 50% refund</li>
                        <li>Less than 48 Hours = No refund</li>
                      </ul>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            <br />
          </div>
        </div>
      </div>

      <?php
      $in ="";

    endforeach;
    ?>
  </div>

          <style>
          .product-sale-price{float:left;width:100%;font-style: italic;text-decoration: line-through;}
          .product-original-price{color:#FF0000;}
          </style>

  <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $get_google_api_key; ?>&callback=init_maps" async defer></script>

  <script type='text/javascript'>
  <?php
  foreach( $CxVLondon as $venue ) :

    ?>

    function init_map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>()
    {
      var geocoder = new google.maps.Geocoder();

      geocoder.geocode( { 'address' : '<?php echo preg_replace( "/\r\n|\r|\n/", ", ", $venue['meta']['address'] ); ?>' } , function( results, status ) {

        console.log( status );
        console.log( results );

        var lat = results[0].geometry.location.lat();
        var lng = results[0].geometry.location.lng();

        console.log( lat+" : "+lng );

        if ( status === 'OK' )
        {
          var myOptions<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = {
            zoom:10,
            center:new google.maps.LatLng( lat, lng ),
            mapTypeId: google.maps.MapTypeId.ROADMAP
          };
          map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = new google.maps.Map(document.getElementById('gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>'), myOptions<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>);
          marker<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = new google.maps.Marker(
            {
              map: map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>,
              position: new google.maps.LatLng(lat, lng)
            });
          }
        });
      }

      <?php

    endforeach;

    $shown = "false";

    foreach( $CxVLondon as $venue ) :

      ?>

      var <?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown = <?php echo $shown; $shown = "false"; ?>;

      jQuery('#collapse<?php echo "-".$venue['key']; ?>').on("shown.bs.collapse", function()
      {
        if ( !<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown ){
          init_map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>();
        }

        <?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown = true;
      });



      <?php

    endforeach;

    ?>

    function init_maps()
    {
      <?php
      foreach( $CxVLondon as $venue )
      {
        echo "init_map_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] )."();\n";

      }
      ?>

    }
    </script>


    <?php if (count($CxVBirmingham) > 0 ) : ?>


      <h4 class="margin-top">BIRMINGHAM</h4>

      <div id="accordion" role='tablist' class="panel-group course-accordions" >
        <?php
        $in ="";
        foreach( $CxVBirmingham as $venue ) :
          ?>

          <div class="panel panel-default">
            <div class="panel-heading"  role="tab" data-toggle="collapse" data-parent="#accordion" data-target="#collapse<?php echo "-".$venue['key']; ?>" href="#collapse<?php echo "-".$venue['key']; ?>">
              <h4 class="panel-title">
                <?php echo $venue['name']; ?><a  style="float:right"><i class="fa fa-plus"></i></a>
              </h4>
            </div>
            <div id="collapse<?php echo "-".$venue['key']; ?>" class="panel-collapse collapse <?php echo $in; ?>" role="tabpanel">
              <div class="panel-body">
                <table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width='100%'>
                  <thead class='cf'>
                    <tr>
                      <th data-firstsort="asc">Course Date</th>
                      <th>Time</th>
                      <th>Price</th>
                      <th>Seats Remaining</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach( $venue['courses'] as $course ) : ?>
                      <tr>
                        <td data-title='Course Date' ><?php echo dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ); ?></td>
                        <td data-title='Time'><?php echo date( "H:i", strtotime( $course['m']['start_date_time'] ) ); ?></td>
                        <td data-title='Price' >
                                                          <?php if($course['saleprice']){ ?>
                                              <span class="product-sale-price"><?php echo ( "" != $course['regularprice'] ? sprintf( "%4.2lf", $course['regularprice']) . $price_display_suffix : "" ); 													?></span><?php } ?>
                                              <span class="<?php if($course['saleprice']){ echo "product-original-price"; } ?>"><?php echo ( "" != $course['price'] ? sprintf( "%4.2lf", $course['price']) . $price_display_suffix : "" ); ?></span>
                                                      </td>
                        <td data-title='Seats Remaining'><?php echo ( 0 != $course['sa'] ? $course['sa'] : "" ); ?></td>
                        <td data-title='' ><?php echo $course['booking']; ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>

                <table class="location " width="100%">
                  <tbody>
                    <tr>
                      <td width="25%" valign='top'>
                        <div style="padding:0 10px;">
                          <h3>Address</h3>
                          <?php
                          echo preg_replace( "/\r\n|\r|\n/", "<br />", $venue['meta']['address'] );

                          echo "<br />".$venue['meta']['phone']."<br />";
                          echo $venue['meta']['url']."<br />";
                          echo $venue['meta']['email']."<br />";

                          ?>
                        </div>
                      </td>
                      <td width="50%" >
                        <div style='overflow:hidden;height:240px;width:100%;'>
                          <div id='gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>' style='height:inherit;width:inherit;' class="map_canvas"></div>
                          <style>
                            #gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> img{max-width:none!important;background:none!important}
                          </style>
                        </div>
                      </td>
                      <td  width="25%" valign='top'>
                        <div style="padding:0 10px;">
                          <h3>Cancellation</h3>
                          <ul>
                            <li>More than 7 days = Money Back</li>
                            <li>48 Hours - 7 Days = 50% refund</li>
                            <li>Less than 48 Hours = No refund</li>
                          </ul>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <br />
              </div>
            </div>
          </div>

          <?php
          $in ="";

        endforeach;
        ?>
      </div>

      <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $get_google_api_key; ?>&callback=init_maps" async defer></script>

      <script type='text/javascript'>
      <?php
      foreach( $CxVBirmingham as $venue ) :

        ?>

        function init_map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>()
        {
          var geocoder = new google.maps.Geocoder();

          geocoder.geocode( { 'address' : '<?php echo preg_replace( "/\r\n|\r|\n/", ", ", $venue['meta']['address'] ); ?>' } , function( results, status ) {

            console.log( status );
            console.log( results );

            var lat = results[0].geometry.location.lat();
            var lng = results[0].geometry.location.lng();

            console.log( lat+" : "+lng );

            if ( status === 'OK' )
            {
              var myOptions<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = {
                zoom:10,
                center:new google.maps.LatLng( lat, lng ),
                mapTypeId: google.maps.MapTypeId.ROADMAP
              };
              map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = new google.maps.Map(document.getElementById('gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>'), myOptions<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>);
              marker<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = new google.maps.Marker(
                {
                  map: map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>,
                  position: new google.maps.LatLng(lat, lng)
                });
              }
            });
          }

          <?php

        endforeach;

        $shown = "false";

        foreach( $CxVBirmingham as $venue ) :

          ?>

          var <?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown = <?php echo $shown; $shown = "false"; ?>;

          jQuery('#collapse<?php echo "-".$venue['key']; ?>').on("shown.bs.collapse", function()
          {
            if ( !<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown ){
              init_map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>();
            }

            <?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown = true;
          });



          <?php

        endforeach;

        ?>

        function init_maps( )
        {
          <?php
          foreach( $CxVBirmingham as $venue )
          {
            echo "init_map_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] )."();\n";

          }
          ?>

        }
        </script>


        <?php

        endif;

        if (count($CxVManchester) > 0 ) : ?>


          <h4 class="margin-top">MANCHESTER</h4>

          <div id="accordion" role='tablist' class="panel-group course-accordions" >
            <?php
            $in ="";
            foreach( $CxVManchester as $venue ) :
              ?>
              <div class="panel panel-default">
                <div class="panel-heading"  role="tab" data-toggle="collapse" data-parent="#accordion" data-target="#collapse<?php echo "-".$venue['key']; ?>" href="#collapse<?php echo "-".$venue['key']; ?>">
                  <h4 class="panel-title">
                    <?php echo $venue['name']; ?><a  style="float:right"><i class="fa fa-plus"></i></a>
                  </h4>
                </div>
                <div id="collapse<?php echo "-".$venue['key']; ?>" class="panel-collapse collapse <?php echo $in; ?>" role="tabpanel">
                  <div class="panel-body">
                    <table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width='100%'>
                      <thead class='cf'>
                        <tr>
                          <th data-firstsort="asc">Course Date</th>
                          <th>Time</th>
                          <th>Price</th>
                          <th>Seats Remaining</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach( $venue['courses'] as $course ) : ?>
                          <tr>
                            <td data-title='Course Date' ><?php echo dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ); ?></td>
                            <td data-title='Time'><?php echo date( "H:i", strtotime( $course['m']['start_date_time'] ) ); ?></td>
                            <td data-title='Price' >
                                                              <?php if($course['saleprice']){ ?>
                                              <span class="product-sale-price"><?php echo ( "" != $course['regularprice'] ? sprintf( "%4.2lf", $course['regularprice']) . $price_display_suffix : "" );																	                          ?></span><?php } ?>
                                              <span class="<?php if($course['saleprice']){ echo "product-original-price"; } ?>"><?php echo ( "" != $course['price'] ? sprintf( "%4.2lf", $course['price']) . $price_display_suffix : "" ); ?></span>
                                                              </td>
                            <td data-title='Seats Remaining'><?php echo ( 0 != $course['sa'] ? $course['sa'] : "" ); ?></td>
                            <td data-title='' ><?php echo $course['booking']; ?></td>
                          </tr>
                        <?php endforeach; ?>
                      </tbody>
                    </table>

                    <table class="location " width="100%">
                      <tbody>
                        <tr>
                          <td width="25%" valign='top'>
                            <div style="padding:0 10px;">
                              <h3>Address</h3>
                              <?php
                              echo preg_replace( "/\r\n|\r|\n/", "<br />", $venue['meta']['address'] );

                              echo "<br />".$venue['meta']['phone']."<br />";
                              echo $venue['meta']['url']."<br />";
                              echo $venue['meta']['email']."<br />";

                              ?>
                            </div>
                          </td>
                          <td width="50%" >
                            <div style='overflow:hidden;height:240px;width:100%;'>
                              <div id='gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>' style='height:inherit;width:inherit;' class="map_canvas"></div>
                              <style>
                                #gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> img{max-width:none!important;background:none!important}
                              </style>
                            </div>
                          </td>
                          <td  width="25%" valign='top'>
                            <div style="padding:0 10px;">
                              <h3>Cancellation</h3>
                              <ul>
                                <li>More than 7 days = Money Back</li>
                                <li>48 Hours - 7 Days = 50% refund</li>
                                <li>Less than 48 Hours = No refund</li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <br />
                  </div>
                </div>
              </div>

              <?php
              $in ="";

            endforeach;
            ?>
          </div>

          <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $get_google_api_key; ?>&callback=init_maps" async defer></script>

          <script type='text/javascript'>
          <?php
          foreach( $CxVManchester as $venue ) :

            ?>

            function init_map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>()
            {
              var geocoder = new google.maps.Geocoder();

              geocoder.geocode( { 'address' : '<?php echo preg_replace( "/\r\n|\r|\n/", ", ", $venue['meta']['address'] ); ?>' } , function( results, status ) {

                // console.log( status );
                // console.log( results );

                var lat = results[0].geometry.location.lat();
                var lng = results[0].geometry.location.lng();

                console.log( lat+" : "+lng );

                if ( status === 'OK' )
                {
                  var myOptions<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = {
                    zoom:10,
                    center:new google.maps.LatLng( lat, lng ),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                  };
                  map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = new google.maps.Map(document.getElementById('gmap_canvas<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>'), myOptions<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>);
                  marker<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?> = new google.maps.Marker(
                    {
                      map: map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>,
                      position: new google.maps.LatLng(lat, lng)
                    });
                  }
                });
              }

              <?php

            endforeach;

            $shown = "false";

            foreach( $CxVManchester as $venue ) :

              ?>

              var <?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown = <?php echo $shown; $shown = "false"; ?>;

              jQuery('#collapse<?php echo "-".$venue['key']; ?>').on("shown.bs.collapse", function()
              {
                if ( !<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown ){
                  init_map<?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>();
                }

                <?php echo "_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] ); ?>_shown = true;
              });



              <?php

            endforeach;

            ?>

            function init_maps( )
            {
              <?php
              foreach( $CxVManchester as $venue )
              {
                echo "init_map_".preg_replace('/[^A-Za-z_]/', '', $venue['key'] )."();\n";

              }
              ?>

            }
            </script>


            <?php

            endif;


        return ob_get_clean( );


      }

      function dateRange( $sdt, $edt )
            {
              $y1 = date( 'Y', $sdt );
              $y2 = date( 'Y', $edt );

              $m1 = date( 'n', $sdt );
              $m2 = date( 'n', $edt );

              $d1 = date( 'j', $sdt );
              $d2 = date( 'j', $edt );

              if ( $y1 == $y2 )
              {
                if ( $m1 == $m2 )
                {
                  // same month

                  $d1 = date( 'j', $sdt );
                  $d2 = date( 'j', $edt );

                  if ( $d1 == $d2 )
                  {
                    return date( "jS M Y", $edt );
                  }
                  else
                  {
                    return date( "jS - ", $sdt ).date( "jS M Y", $edt );
                  }
                }
                else
                {
                  return date( "jS M - ", $sdt ).date( "jS M Y", $edt );

                }
              }
              else
              {
                return date( "jS M Y - ", $sdt ).date( "jS M Y", $edt );
              }

              return "";
            }


            add_action('woocommerce_checkout_process', 'my_custom_checkout_field_process');

            function my_custom_checkout_field_process()
            {
              global $woocommerce;

              // Check if set, if its not set add an error.
              if (!$_POST['my_field_name'])
              {
                //$woocommerce->add_error( __('Please enter something into this new shiny field.') );
              }

              debug( "checkout", $_POST );
            }


            add_action('woocommerce_before_checkout_process', 'my_custom_before_checkout_field_process');

            function my_custom_before_checkout_field_process()
            {
              global $woocommerce;

              // Check if set, if its not set add an error.
              if (!$_POST['my_field_name'])
              {
                //$woocommerce->add_error( __('Please enter something into this new shiny field.') );
              }

              debug( "before checkout", $_POST );
            }


            //add_action( 'woocommerce_add_order_item_meta', 'my_add_order_item_meta' );

            function my_add_order_item_meta( $item_id, $values, $cart_item_key, $unique = false )
            {
              debug( 'item_id', $item_id );
              debug( 'values', $values );
              debug( 'cart_item_key', $cart_item_key );
            }


            // add_action( 'woocommerce_before_checkout_form', function( ){ debug( 'before checkout login form', $_POST ); } , 10 );
            // add_action( 'woocommerce_before_checkout_form', function( ){ debug( 'before checkout coupon form', $_POST ); }, 10 );
            // add_action( 'woocommerce_checkout_order_review', function( ){ debug( 'woocommerce order review', $_POST ); }, 10 );
            // add_action( 'woocommerce_checkout_order_review', function( ){ debug( 'woocommerce checkout payment', $_POST ); }, 20 );

            // add_action( 'template_redirect', function( ){ debug( 'template redirect', $_POST ); } );


            add_filter( 'woocommerce_my_account_my_orders_columns', "siren_my_account_bookings" );

            function siren_my_account_bookings( $columns )
            {
              //debug( 'columns', $columns );

              $columns['order-number'] = "Booking";

              unset( $columns['order-status'] );

              return $columns;
            }

            add_filter( 'woocommerce_account_menu_items', "siren_my_account_menu_items" );

            function siren_my_account_menu_items( $items )
            {
              // debug( 'items', $items );

              // $columns['order-number'] = "Booking";

              // unset( $columns['order-status'] );

              $items['orders'] = "Bookings";

              return $items;
            }


            // add_filter( 'manage_edit-learner_columns', 'my_edit_learner_columns' ) ;

            // function my_edit_learner_columns( $columns ) {

            //   $columns = array(
            //     'cb' => '<input type="checkbox" />',
            //     'title' => __( 'Leaner Name' ),
            //     'course_id' => __( 'Course' ),
            //     'order_id' => __( 'Order #' )
            //   );

            //   return $columns;
            // }

            // add_action( 'manage_learner_posts_custom_column', 'my_manage_learner_columns', 10, 2 );

            // function my_manage_learner_columns( $column, $post_id ) {
            //   //global $post;

            //   switch( $column )
            //   {
            //     case 'course_id' :
            //     $post = get_post( $post_id );

            //     if ( $post->post_parent > 0)
            //     {
            //       $calendar = get_post_meta( $post->post_parent, "_calendar_data", true );

            //       echo $calendar['product']['name'].
            //       "<br /><small>".dateRange( strtotime( $calendar['start_date_time'] ), strtotime( $calendar['end_date_time'] ) )."</small>";

            //     }

            //     break;

            //     case 'order_id' :
            //     $woo_order = get_post_meta( $post_id, "_woo_order", true );

            //     echo $woo_order;

            //     break;
            //   }

            // }


            add_filter( 'woocommerce_email_classes', "siren_woo_emails" );

            function siren_woo_emails ( $emails )
            {
              //debug( 'woo emails', $emails );

              //wp_die( "<pre>".print_r( $emails, true )."</pre>" );

              $emails['WC_Email_Customer_Completed_Order'] = include( 'woocommerce/includes/emails/class-wc-email-customer-completed-order-2021.php' );

              return $emails;
            }

            //$this->emails = apply_filters( 'woocommerce_email_classes', $this->emails );

            function init_sidebars( )
            {

              register_sidebar( array(
                'name' => __( 'Product Sidebar', 'sirentraining' ),
                'id' => 'siren_product_sidebar',
                'description' => __( 'Sidebar displayed against products', 'sirentraining' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="widget-inner">',
                'after_widget' => '</div></div>',
                'before_title' => '<h2 class="widget-title maincolor2">',
                'after_title' => '</h2>',
              ));

              register_sidebar( array(
                'name' => __( 'Landing Page Sidebar', 'sirentraining' ),
                'id' => 'siren_landing_page_sidebar',
                'description' => __( 'Sidebar displayed on Landing pages', 'sirentraining' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s"><div class="widget-inner">',
                'after_widget' => '</div></div>',
                'before_title' => '<h2 class="widget-title maincolor2">',
                'after_title' => '</h2>',
              ));

            }

            add_action( "init", "init_sidebars" );

            function siren_update_attendees() {
              $course = $_POST['course_id'];

              $attendees = array ();

              // TODO: add attendees to _l2c

              foreach( $_POST['_fname'][$course] as $idx => $fname )
              {
                $data = array
                (
                  'fname' => $fname,
                  'sname' => $_POST['_sname'][$course][ $idx ],
                  'pemail' => $_POST['_email'][$course][ $idx ],
                  'phone' => $_POST['_phone'][$course][ $idx ],
                  'cemail' => $_POST['_cemail'][$course][ $idx ],
                  'course_id' => $course,
                  'id' => $_POST['_lid'][$course][ $idx ]
                );

                if ( !( "" == trim( $data['fname'] ) && "" == trim ($data['sname'] ) ) )
                {
                  if ( $data['id'] == 0 )
                  {
                    $newlearner = array(
                      'post_title'=> $data['fname']." ".$data['sname'],
                      'post_name' => sanitize_title( $data['fname']." ".$data['sname'] ),
                      'post_status' => 'publish',
                      'post_parent' => $data['course_id'],
                      'post_type' => 'learner',
                      'guid' => "",
                      'post_content' => ""/*print_r( $data, true )*/
                    );

                    $learners = get_posts( array(
                      'posts_per_page' => -1,
                      'post_type' => 'learner',
                      'post_status' => 'publish',
                      'post_parent' => $data['course_id'],
                      'orderby' => 'ID',
                      'order' => 'ASC',
                      'nopaging' => true
                    ) );

                    $empty_learner = true;

                    foreach($learners as $learner) {
                      $learner_meta = get_post_meta( $learner->ID, '_learner_details', true );

                      if ($learner_meta['pemail'] === $data['pemail']) {
                        $empty_learner = false;
                        $learner_id = $learner->ID;
                        break;
                      }
                    }

                    if ($empty_learner) {
                      $newlearner_id = wp_insert_post( $newlearner );
                      $data['id'] = $newlearner_id;
                    } else {
                      $data['id'] = $learner_id;
                    }

                  }

                  update_post_meta( $data['id'], '_learner_details', $data );

                  $user = get_user_by( "email", $data['pemail'] );
                  
                  if ( $user !== FALSE )
                  {
                    // Add learner id to lids
                    $uid = $user->ID;
                    
                    // We don't have the $order_id so cannot do th enext step
                    // if ( function_exists( "tutils" ) )
                    //     tutils()->do_enroll( $data[ 'course_id' ], $order_id, $uid );

                    //error_log( print_r( $user, true ) );
                    
                    update_user_meta( $uid, '_l2c_'.$data[ 'course_id' ], $data['id'] );
                  }
                  
                }
              }

              print_r('<html><head></head><body><h3 style="text-align:center;color:grey;font-family:Arial, Helvetica, sans-serif;">Thank you. The attendees have been successfully added. Please check to add more or change details before the course.</h3></body></html>');
              die();
            }
            add_action( 'admin_post_nopriv_update_attendee', 'siren_update_attendees' );
            add_action( 'admin_post_update_attendee', 'siren_update_attendees' );


/*enque script start*/
function custom_hip_js() {
wp_register_script( 'customnew-js', get_stylesheet_directory_uri() . '/js/custom-new.js', array( 'jquery' ), '1.0' );
$ajax_file_url = array( 'ajax_file_url' => get_stylesheet_directory_uri() );  // Ajax file url
$home_url = array( 'home_url' => site_url() );  // home url

wp_localize_script( 'customnew-js', 'home_url_object', $home_url );
wp_localize_script( 'customnew-js', 'ajax_file_url_object', $ajax_file_url );
wp_enqueue_script( 'customnew-js', get_stylesheet_directory_uri() . '/js/custom-new.js', array( 'jquery' ), '1.0' );
}
add_action( 'wp_enqueue_scripts', 'custom_hip_js' );
/*enque script end*/

/*checkout fields limitation start*/
add_action("wp_footer", "cod_set_max_length");
function cod_set_max_length(){
    ?>
    <script>

    jQuery(document).ready(function($){

        $("#billing_address_1").attr('maxlength','35');
				$("#billing_city").attr('maxlength','25');
				$("#billing_postcode").attr('maxlength','10');

    });
    </script>
<?php
}
/*checkout fields limitation end*/

/*To show trainer documentation start*/
add_action( 'add_meta_boxes', 'news_add_custom_box' );
// add_action( 'save_post', 'news_save_postdata' );  // TODO - WTF

function news_add_custom_box() {
	add_meta_box('trainer_documents',__( 'Trainer Documents', 'news_textdomain' ), 'news_inner_custom_box', 'trainers' , 'normal' , 'high');
}
function news_inner_custom_box( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'myplugin_noncename' );
	$trainer_docs_attach_ids = get_post_meta($post->ID,'_trainer_meta_documentation',true);
	if($trainer_docs_attach_ids){
		echo '<ul>';
		foreach($trainer_docs_attach_ids as $trainer_docs_attach_id){
		//echo $trainer_docs_attach_id;
			$attachment_title = explode("/",$trainer_docs_attach_id);
			$size_attachment_title = sizeof($attachment_title);
			$full_size_attachment_title = $size_attachment_title - 1;
			//$trainer_src_url = wp_get_attachment_url($trainer_docs_attach_id);
			echo '<li><a href="'.$trainer_docs_attach_id.'">'.$attachment_title[$full_size_attachment_title].'</a></li>';
		}
		echo '</ul>';
	}
	echo '<hr>';


	$get_favourite_courses = get_post_meta( $post->ID, 'favourite_trainer_coursetype', true );
	echo '<label for="myplugin_new_field" style="float: left;font-size: 14px;font-weight: bold;width: 100%;margin-bottom: 10px;">';
       _e("Favourite Trainer For Which Course Type? : ", 'news_textdomain' );
  echo '</label> ';
	if($get_favourite_courses){
		foreach($get_favourite_courses as $get_favourite_course){
		echo '->'.' '.get_the_title($get_favourite_course);
		echo '<br>';
		}
	}else{
		echo 'Not Selected.';
	}

}
/*To show trainer documentation end*/


// To add favourite trainer section start
add_action( 'add_meta_boxes', 'resources_read_add_custom_box' );
add_action( 'save_post', 'resources_read_save_postdata' );

function resources_read_add_custom_box() {
   add_meta_box('',__( 'Favourite Trainer', 'news_textdomain' ), 'resources_read_inner_custom_box', 'product' , 'normal' , 'high');
}
function resources_read_inner_custom_box( $post ) {
wp_nonce_field( plugin_basename( __FILE__ ), 'myplugin_noncename' );

  $get_fav_trainer = get_post_meta( $post->ID, 'favourite_trainer_data', true );
	$get_trainers = array('posts_per_page'   => -1,'order' => 'DESC','post_type' => 'trainers','post_status' => 'publish',);
	$get_trainer_lists = get_posts($get_trainers);
?>

	<select name="favourite_trainer_course" id="favourite_trainer_course">
		<option value="">Select favourite trainer</option>
		<?php foreach($get_trainer_lists as $get_trainer_list) { ?>
		<option value="<?php echo $get_trainer_list->ID; ?>" <?php selected( $get_fav_trainer, $get_trainer_list->ID ); ?>><?php echo $get_trainer_list->post_title; ?></option>
		<?php } ?>
	</select>

<?php
}

/* When the post is saved, saves our custom data */
function resources_read_save_postdata( $post_id ) {

  if ( isset( $_REQUEST['post_type'] ) && 'page' == $_REQUEST['post_type'] ) {
    if ( ! current_user_can( 'edit_page', $post_id ) )
        return;
  } else {
    if ( ! current_user_can( 'edit_post', $post_id ) )
        return;
  }

  // Secondly we need to check if the user intended to change this value.
  if ( ! isset( $_POST['myplugin_noncename'] ) || ! wp_verify_nonce( $_POST['myplugin_noncename'], plugin_basename( __FILE__ ) ) )
      return;

  $post_ID = $_POST['post_ID'];
  $custom_link_data = sanitize_text_field( $_POST['favourite_trainer_course'] );

	/*To remove old trainer start*/
	$fav_trainer_old_datas = get_post_meta($post_ID,'favourite_trainer_data',true);
	if($fav_trainer_old_datas){
		$fav_trainer_check_old_datas = get_post_meta($fav_trainer_old_datas,'favourite_trainer_coursetype',true);
		$search_old_data_pos = array_search($post_ID, $fav_trainer_check_old_datas);
		unset($fav_trainer_check_old_datas[$search_old_data_pos]);
		update_post_meta($fav_trainer_old_datas, 'favourite_trainer_coursetype', $fav_trainer_check_old_datas);
	}
	/*To remove old trainer end*/

  add_post_meta($post_ID, 'favourite_trainer_data', $custom_link_data, true) or update_post_meta($post_ID, 'favourite_trainer_data', $custom_link_data);

	$favourite_get_trainer_course = get_post_meta($custom_link_data,'favourite_trainer_coursetype',true);

	if(!empty($favourite_get_trainer_course)){
		array_push($favourite_get_trainer_course,$post_ID);
		$trainer_update_data = $favourite_get_trainer_course;
	}else{
		$trainer_update_data[] = $post_ID;
	}
	update_post_meta($custom_link_data, 'favourite_trainer_coursetype', $trainer_update_data);
}
// To add favourite trainer section end

/*run the cron two days before for update the attendee list start*/
function my_cron_schedules_test($schedules){
    if(!isset($schedules["everyday"])){
        $schedules["everyday"] = array(
            'interval' => 1440*60,
            'display' => __('Everyday'));
    }
    return $schedules;
}
add_filter('cron_schedules','my_cron_schedules_test');

add_action('init', 'siren_schedule_twoday_before_attendeelist');
function siren_schedule_twoday_before_attendeelist() {
  if( !wp_next_scheduled('email_cron_job_twodays_before_attendeelist')) {
    wp_schedule_event(time(), 'everyday', 'email_cron_job_twodays_before_attendeelist');
  }
}

add_action('email_cron_job_twodays_before_attendeelist', 'email_cron_job_twodays_before_attendeelist_action');
function email_cron_job_twodays_before_attendeelist_action(){

	/* functionality start*/
	$get_private_courses = get_posts(
                    array(
                      'posts_per_page' => -1,
                      'post_type' => 'product_variation',
                      'post_status' => 'publish',
                      'meta_query' => array(
                        array(
												'relation' => 'AND',
													array(
														'key' => '_private_course',
														'value' => 'true'
													),
													array (
														'key' => '_start_date',
														'value' => time(),
														'compare' => '>=',
													),
                        ),
                      )
                    )
                  );

	foreach($get_private_courses as $get_private_course){

		$course_id = $get_private_course->ID;
		$get_course_start_date = get_post_meta($course_id,'_start_date',true);
		$get_course_start_date_fm = date('d M Y', $get_course_start_date);
		$date_one = strtotime("+1 day");
		$date_one_fm = date('d M Y', $date_one);

		if($get_course_start_date_fm == $date_one_fm){
		/*send mail start*/
		$calendar_data = get_post_meta($course_id, '_calendar_data', true);
		$calender_start_date = date('d F Y H:i', strtotime($calendar_data['start_date_time']));
		$calender_end_date = date('d F Y H:i', strtotime($calendar_data['end_date_time']));
		$calender_coursename = $calendar_data['product']['name'];
		$calender_venuename = $calendar_data['venue']['name'];

		$client_email = get_post_meta($course_id,'privatecourse_client_mail',true);
		$client_email_name = explode('@',$client_email);
		$client_email_name_orig = $client_email_name[0];
		$add_attendee_link = site_url('/') . 'add-attendee/' . $course_id;

		$admin_email = get_option( 'admin_email' );
		$subject = "Sirentraining update the attendee details";
		$message = '
		<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Siren Training</title>
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="font-family: "Arial", sans-serif;">
  <div id="wrapper" dir="ltr">
    <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
      <tr>
        <td align="center" valign="top">
          <table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">
            <tr>
              <td align="left" valign="top">
                <div id="booking_header_image">
                  <img src="'.site_url().'/wp-content/uploads/2014/03/LOGO1-copy.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">
                </div>
              </td>
            </tr>
            <tr>
              <td align="right" valign="top">
                <div id="address">
                  SIREN TRAINING LTD<br />
                  New North House<br />
                  Lower Groudn Floor<br />
                  202/208 New North road<br />
                  London<br />
                  N1 7BJ<br />
                  <br />
                  <b>This is not the course location</b><br />
                </div>
              </td>
            </tr>

            <tr>
              <td>
                <p>Hi '.$client_email_name_orig.',</p>
								<h4>COURSE DETAILS</h4>
								<p>Course Name - '.$calender_coursename.'</p>
								<p>Course Start Date - '.$calender_start_date.'</p>
								<p>Course End Date - '.$calender_end_date.'</p>
                <p> Location - '.$calender_venuename.'</p>
                <p>We are looking forward to delivering your course for you tomorrow. Can you please ensure that all student names have been entered on to the electronic register. Certificates cannot be issued unless this register is complete. </p>
								<p>Don&#39;t worry if you&#39;re not fully certain of all attendee names. You can re-visit this link at any time to add or remove student names. There will also be an opportunity to adjust the register a day after the course has taken place if required.</p>
								<p>Entering personal emails / phones are optional but help us to contact students if they are running late or have not attended. Permission should be gained before sharing with us.</p>
								<p>Our Instructor will also be taking a register on the day to ensure there are no discrepancies.</p>
								<p>We ask you to do this to ensure your certificates are produced quickly, with less risk of any spelling mistakes.</p>
								<p>Thank you. See link below: <a href="'.$add_attendee_link.'">'.$add_attendee_link.'</a></p>
                <p>Tel:0203 740 8088<br>
                email: info@sirentraining.co.uk</p>
                <br>

                  <p>Kind regards,<br>
                    The Siren team</p>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>

      </tbody>
    </table>
		</div>
</body>
</html>
		';
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
		$headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
		$headers .= 'Reply-To: '.$admin_email. "\r\n";
		wp_mail($client_email, $subject, $message, $headers, '');
		//wp_mail('developer1@webanatomy.co.uk', $subject, $message, $headers, '');
		}
		}
		/* functionality end*/


}
/*run the cron two days before for update the attendee list end*/

/* run the cron 24 hours after that course completion start */
add_action('email_cron_job_twodays_before_attendeelist', 'email_cron_job_after_oneday_attendeelist_action');
function email_cron_job_after_oneday_attendeelist_action(){

		$get_yesterdays = date('Y-m-d', strtotime('-1 day'));
		$get_yesterday = strtotime($get_yesterdays);

		$get_tomorrows = date('Y-m-d', strtotime('+1 day'));
		$get_tomorrow = strtotime($get_tomorrows);


	$get_private_courses = get_posts(
                    array(
                      'posts_per_page' => -1,
                      'post_type' => 'product_variation',
                      'post_status' => 'publish',
                      'meta_query' => array(
                        array(
												'relation' => 'AND',
													array(
														'key' => '_private_course',
														'value' => 'true'
													),
													array (
														'key' => '_end_date',
														'value' => $get_yesterday,
														'compare' => '>',
													),
													array (
														'key' => '_end_date',
														'value' => $get_tomorrow,
														'compare' => '<',
													),
                        ),
                      )
                    )
                  );


	foreach($get_private_courses as $get_private_course){

		$course_id = $get_private_course->ID;

		$calender_details_end = get_post_meta($course_id,'_end_date',true);
		$calender_details_end_format = date('d M Y', $calender_details_end);

		$current_date_sym = strtotime("-1 day");
		$current_date_sym_format = date('d M Y', $current_date_sym);

		if($calender_details_end_format == $current_date_sym_format){

		$calendar_data = get_post_meta($course_id, '_calendar_data', true);
		$calender_start_date = date('d F Y H:i', strtotime($calendar_data['start_date_time']));
		$calender_end_date = date('d F Y H:i', strtotime($calendar_data['end_date_time']));
		$calender_coursename = $calendar_data['product']['name'];
		$calender_venuename = $calendar_data['venue']['name'];

		$client_email = get_post_meta($course_id,'privatecourse_client_mail',true);
		$client_email_name = explode('@',$client_email);
		$client_email_name_orig = $client_email_name[0];
		$add_attendee_link = site_url('/') . 'add-attendee/' . $course_id;

		$admin_email = get_option( 'admin_email' );
		$subject = "Sirentraining update the attendee details after course completion";
		$message = '
		<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Siren Training</title>
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="font-family: "Arial", sans-serif;">
  <div id="wrapper" dir="ltr">
    <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
      <tr>
        <td align="center" valign="top">
          <table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">
            <tr>
              <td align="left" valign="top">
                <div id="booking_header_image">
                  <img src="'.site_url().'/wp-content/uploads/2014/03/LOGO1-copy.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">
                </div>
              </td>
            </tr>
            <tr>
              <td align="right" valign="top">
                <div id="address">
                  SIREN TRAINING LTD<br />
                  New North House<br />
                  Lower Groudn Floor<br />
                  202/208 New North road<br />
                  London<br />
                  N1 7BJ<br />
                  <br />
                  <b>This is not the course location</b><br />
                </div>
              </td>
            </tr>

            <tr>
              <td>
                <p>Hi '.$client_email_name_orig.',</p>
								<h4>COURSE DETAILS</h4>
								<p>Course Name - '.$calender_coursename.'</p>
								<p>Course Start Date - '.$calender_start_date.'</p>
								<p>Course End Date - '.$calender_end_date.'</p>
                <p> Location - '.$calender_venuename.'</p>
                <p>Thank you for accommodating Siren Training for your recent course. In order for certificates to be issued, .can you please ensure that the students entered on the electronic register prior to the course, did actually attend. Please amend the register in the link below if required. <a href="'.$add_attendee_link.'">'.$add_attendee_link.'</a></p>

                <p>Tel:0203 740 8088<br>
                email: info@sirentraining.co.uk</p>
                <br>

                  <p>Kind regards,<br>
                    The Siren team</p>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
		</div>
</body>
</html>
		';
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
		$headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
		$headers .= 'Reply-To: '.$admin_email. "\r\n";
		wp_mail($client_email, $subject, $message, $headers, '');
		//wp_mail('developer1@webanatomy.co.uk', $subject, $message, $headers, '');
		}

	}

}
/* run the cron 24 hours after that course completion end */

/*apply custom css start*/
add_action('admin_head', 'my_custom_fonts');
function my_custom_fonts() {
  echo '<style>
    .post-type-venues .acf-button-edit{
			display:none;
		}
  </style>';
}
/*apply custom css end*/

/*theme options for google api key start*/
add_action( 'admin_init', 'theme_options_init' );
add_action( 'admin_menu', 'theme_options_add_page' );
function theme_options_init(){
 register_setting( 'sample_options', 'sample_theme_options');
}

function theme_options_add_page() {
 add_theme_page( __( 'Google Api Key', 'sampletheme' ), __( 'Google Api Key', 'sampletheme' ), 'edit_theme_options', 'Google Api Key', 'theme_options_do_page' );
}

function theme_options_do_page()
{
if ( $_POST['update_themeoptions'] == 'true' ) { themeoptions_update(); }
?>
<div class="wrap">
	<div id="social_options">
		<form method="post" action="" name="social_form" id="social_form" enctype="multipart/form-data">
			<input type="hidden" name="update_themeoptions" value="true" />
			<label>Enter Google Api Key Here.</label><br />
			<input type="text" name="custom_google_api_key" size="70" id="custom_google_api_key" value="<?php echo get_option('custom_google_api_key'); ?>"/><br />
			<input id="btn" type="submit" value="Save" name="req_submit" />
		</form>
	</div>
</div>
<style>
	#page-fm{
	width:250px;
	}
	#social_options{
		width: 50%;
		}
	#social_options label {
    font-size: 15px;
    font-weight: bold;
    padding: 0 0 12px;
	}
	#social_options input {
    margin: 0 0 25px;
	}
	#social_options form {
		margin-left: 25px;
		margin-top:35px;
	}
	#social_options #btn {
    background: #0073aa none repeat scroll 0 0;
    border: 1px solid #0073aa;
    color: #ffffff;
    cursor: pointer;
    padding: 5px;
    width: 100px;
	}
	</style>
<?php
}

function themeoptions_update(){
	update_option('custom_google_api_key',$_POST['custom_google_api_key']);
}

/*theme options for google api key end*/
function product_shortdesc_shortcode( $atts ){
    // use shortcode_atts() to set defaults then extract() to variables
    extract( shortcode_atts( array( 'id' => false ), $atts ) );

    // if an $id was passed, and we could get a Post for it, and it's a product....
    if ( ! empty( $id ) && null != ( $product = get_post( $id ) ) && $product->post_type = 'product' ){
        // apply woocommerce filter to the excerpt
        echo apply_filters( 'woocommerce_short_description', $product->post_content );
    }
}
// process [product_shortdesc] using product_shortdesc_shortcode()
add_shortcode( 'product_shortdesc', 'product_shortdesc_shortcode' );

if(!function_exists('ct_details_event_course')){
	function check_event_course($product_id){
		$post_type = 'null';
		$args = array(
			'posts_per_page'   => 1,
			'meta_key'         => 'product_id',
			'meta_value'       => $product_id,
			'post_type'        => 'u_event',
		);
		$posts_array = new WP_Query( $args );
		$num_it = $posts_array->post_count;
		if($num_it > 0){
			$post_type = 'u_event';
		}else{
			$args = array(
				'posts_per_page'   => 1,
				'meta_key'         => 'product_id_course',
				'meta_value'       => $product_id,
				'post_type'        => 'u_course',
			);
			$posts_array = new WP_Query( $args );
			$num_it = $posts_array->post_count;
			if($num_it > 0){
				$post_type = 'u_course';
			}
		}
		return $post_type;
	}
	function ct_details_event_course($product_id, $data_if=false){
		$post_type = 'u_event';
		$args = array(
			'posts_per_page'   => 1,
			'meta_key'         => 'product_id',
			'meta_value'       => $product_id,
			'post_type'        => $post_type,
		);
		$posts_array = new WP_Query( $args );
		$num_it = $posts_array->post_count;
		if($num_it < 1){
			$post_type = 'u_course';
			$args = array(
				'posts_per_page'   => 1,
				'meta_key'         => 'product_id_course',
				'meta_value'       => $product_id,
				'post_type'        => $post_type,
			);
			$posts_array = new WP_Query( $args );
		}
		
		if($posts_array->have_posts()){
			while($posts_array->have_posts()){ $posts_array->the_post();
				$it_info_id = get_the_ID();?>
                <?php if($data_if=='checkout'){ ?>
                <td class="event-cpurse-if"><h4 style="margin-bottom:0"><?php if(check_event_course($product_id)=='u_event'){ echo __('Event Details');}elseif(check_event_course($product_id)=='u_course'){ echo __('Course Details');}?></h4></td>
				<?php
				}?>
				<td class="product-event-course" style="padding-top:20px; padding-bottom:20px; <?php if($data_if=='email'){ ?>border:1px solid #eee;border-right:0;<?php }?>">
					<span><a href="<?php the_permalink()?>" title="<?php the_title_attribute()?>"><?php echo get_the_title();  ?></a></span><br>
					<?php 
						if($post_type == 'u_course'){
							$date_format = get_option('date_format');
							$startdate = get_post_meta(get_the_ID(),'u-course-start', true );
							if($startdate){
								$startdate = gmdate("Y-m-d\TH:i:s\Z", $startdate);// convert date ux
								$con_date = new DateTime($startdate);
								$start_datetime = $con_date->format($date_format);
							}?>
							<span class="small-text"><?php _e('START:','cactusthemes') ?><?php echo date_i18n( get_option('date_format'), strtotime($startdate));?></span><br>
							<span class="small-text"><?php _e('DURATION:','cactusthemes') ?><?php echo get_post_meta(get_the_ID(),'u-course-dur', true );?></span><br>
						<?php
						}else{
							$all_day = get_post_meta(get_the_ID(),'all_day', true );
							$date_format = get_option('date_format');
							$hour_format = get_option('time_format');
							$startdate = get_post_meta(get_the_ID(),'u-startdate', true );
							$start_datetime = '';
							$start_hourtime = '';
							if($startdate){
								$startdate_cal = gmdate("Ymd\THis", $startdate);
								$startdate = gmdate("Y-m-d\TH:i:s\Z", $startdate);// convert date ux
								$con_date = new DateTime($startdate);
								$con_hour = new DateTime($startdate);
								$start_datetime = $con_date->format($date_format);
								$start_hourtime = $con_date->format($hour_format);
							}
							$enddate = get_post_meta(get_the_ID(),'u-enddate', true );
							$end_datetime = '';
							$end_hourtime = '';
							if($enddate){
								$enddate_cal = gmdate("Ymd\THis", $enddate);
								$enddate = gmdate("Y-m-d\TH:i:s\Z", $enddate);
								$conv_enddate = new DateTime($enddate);
								$conv_hourtime = new DateTime($enddate);
								$end_datetime = $conv_enddate->format($date_format);
								$end_hourtime = $conv_enddate->format($hour_format);
							}
							?>
								<span class="small-text"><?php _e('START:','cactusthemes') ?><?php if($startdate){ echo date_i18n( get_option('date_format'), strtotime($startdate));} if($start_datetime && $all_day !=1){ echo ' - '.$start_hourtime;}?></span><br>
								<span class="small-text"><?php _e('END: ','cactusthemes') ?><?php if($enddate){echo date_i18n( get_option('date_format'), strtotime($enddate));  } if($end_hourtime && $all_day !=1){ echo ' - '.$end_hourtime;}?></span><br>
							<?php
						}
						?>
				</td>
                <?php
				break;
				
			}
			wp_reset_postdata();
		}
		
	}
}


add_action( "init", "siren_remove_api_from_headers" );
function siren_remove_api_from_headers( )
{
      // Remove the REST API lines from the HTML Header
      remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
      remove_action( 'template_redirect', 'rest_output_link_header', 11, 0 );
      remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
}

add_action( 'template_redirect', 'siren_redirect_to_best_dashboard' );

function siren_redirect_to_best_dashboard() 
{
global $wp;
  
    if ( is_checkout() && ! empty( $wp->query_vars['order-received'] ) ) 
    {
        $redirect_url = get_site_url().'/dashboard';

        $order = wc_get_order( $wp->query_vars['order-received'] );

        $tutor_products = 0;

        if ( $order !== false )
        {
          $order_lines = $order->get_items();
  
          foreach( $order_lines as $item_id => $item )
          {
              $_tp = get_post_meta( $item->get_product_id(), '_tutor_product', 'no');
  
              if ( $_tp === 'yes' )
              {
                  $tutor_products++;
              }
          }

          if ( $tutor_products == count( $order_lines ) )
          {
              // If we only have tutor products redirect to tutor dashboard
  
              wp_redirect($redirect_url );
  
              exit;
          }
        }

    }
}


// add_filter( 'woocommerce_order_formatted_billing_address', 'siren_filter_test' );
// add_filter( 'woocommerce_order_get_formatted_billing_address', 'siren_filter_test' );

function siren_filter_test( $args )
{
  wp_die( "<pre>".print_r(  $args, true )."</pre>" );

}

add_filter( 'gettext', 'siren_gettext', 20, 3 );

function siren_gettext( $translation, $text, $domain )
{
    if ( is_singular() ) 
    {
  
        switch ( $translation ) 
        {
            case 'Enrolled Courses' :

                $translation = __( 'Online Courses', 'siren' );
                break;
            
            case 'You didn\'t purchased any course' :

                $translation = __( 'You haven\'t taken any online courses', 'siren' );
                break;

            case 'Practical Courses' :

                $translation = __( 'Courses', 'siren' );
                break;
              
          }

    }

    return $translation;
}


function siren_get_lids( $user_id )
{
    $lids = get_usermeta( $user_id, 'lids' );

    return $lids;
}


function siren_get_classroom_courses_ids_by_user($user_id = 0, $user_ids = array() )
{
    global $wpdb;

    if ( !empty( $user_ids ) )
        $user_id_str = implode( ",", $user_ids );
    else
        $user_id_str = "".$user_id;

    // $user_id = tutor()->get_user_id($user_id);
    $course_ids = $wpdb->get_col("select post_parent from {$wpdb->posts} WHERE post_type = 'tutor_enrolled' AND post_author in ({$user_id_str}) AND post_status = 'completed'; ");

    // wp_die ( "select post_parent from {$wpdb->posts} WHERE post_type = 'tutor_enrolled' AND post_author in ({$user_id_str}) AND post_status = 'completed'; " );

    // wp_die( print_r(  $course_ids, true ) );

    return $course_ids;

}


function siren_get_company_ids_by_user($user_id = 0){
  global $wpdb;

  $this_company_tag = get_the_author_meta( 'company_tag', $user_id );

  if ( '' == $this_company_tag )
  {

    $user_ids = array ( $user_id );

  }
  else
  {
    // $user_id = tutor()->get_user_id($user_id);
    $user_ids = $wpdb->get_col("select user_id from {$wpdb->usermeta} WHERE meta_key = 'company_tag' and meta_value like  '%{$this_company_tag}%'; ");
  }


  return $user_ids;

}

function siren_get_classroom_courses_by_user($user_id = 0)
{

    global $wpdb;

    // $company_ids = siren_get_company_ids_by_user( $user_id );

    // $course_ids = $wpdb->get_col("select post_parent from {$wpdb->posts} WHERE post_type = 'tutor_enrolled' AND post_author = {$user_id} AND post_status = 'completed'; ");

    $l2c_ids = $wpdb->get_col("select meta_key from {$wpdb->usermeta} where user_id = {$user_id} and meta_key like '%l2c%'" );

    $course_ids = array();

    foreach( $l2c_ids as $l2c_id )
    {
        $course_ids[] = trim( $l2c_id, "_l2c" );
    }

    // error_log( "user id : ". $user_id );

    // error_log( print_r( $course_ids, true ) );

    // $user_id = tutor()->get_user_id($user_id);

    if (count($course_ids)){
        $course_post_type = tutor()->course_post_type;
        $course_args = array(
            'post_type'     => 'product_variation',
            'post_status'   => 'publish',
            'post__in'      => $course_ids,
            'posts_per_page' => -1,
        );

        // print_r( $course_args );

        return new \WP_Query($course_args);
    }
    return false;
}

add_action( "init", "siren_disable_async_javascript" );

function siren_disable_async_javascript( )
{
    $page_url = esc_url( $_SERVER['REQUEST_URI'] );

    // Load the css on any dashboard page
    if ( strpos( $page_url, "/dashboard/" ) !== FALSE )
    {
        // remove async_javascript filter if already set
        if ( isset( $ajFrontend ) )
            remove_filter( 'script_loader_tag', array( $ajFrontend, 'aj_async_js') , 20, 3 );
        else
        {
            // Do it the hard way if we must

            add_filter( 'script_loader_tag', function( $tag, $handle, $src ) {

            return str_replace( "async='async'", "", str_replace( "async='defer'", "", $tag ) );

            }, 99, 3 );
        }
    }
}


function siren_get_template( $template = null ) 
{
    if ( ! $template ) {
        return false;
    }
    
    $template = str_replace( '.', DIRECTORY_SEPARATOR, $template );

    /**
     * Get template first from child-theme if exists
     * If child theme not exists, then get template from parent theme
     */
    $template_location = trailingslashit( get_stylesheet_directory() ) . "templates/{$template}.php";
    $file_location = $template_location;
    
    if ( ! file_exists($template_location))
    {
        $template_location = trailingslashit( get_template_directory() ) . "templates/{$template}.php";
    }
    // $file_in_theme = $template_location;

    if ( ! file_exists($template_location))
    {
        echo '<div class="tutor-notice-warning"> '.__(sprintf('The file you are trying to load does not exist in your theme, please create a php file at location %s ', "<code>{$file_location}</code>"), 'tutor').' </div>';      
    }

    return $template_location;
}


function get_company_lids ( $user_id ) 
{
global $wpdb;

    $team_user_ids = siren_get_company_ids_by_user( $user_id );

    $emails = $wpdb->get_col( 'select meta_value from '.$wpdb->usermeta.' where meta_key = "billing_email" and user_id in ('.implode( ',', $team_user_ids).')');
    
    // for each email get list of learners
    
    $company_lids = array();

    if ( !empty( $emails ) )
    {
        foreach( $emails as $email )
        {
            $lids = $wpdb->get_col('select post_id from '.$wpdb->postmeta.' WHERE ( meta_key = "_learner_details" AND meta_value like "%'.$email.'%" ) or ( meta_key = "billing_email" and meta_value like "%'.$email.'%" )');
    
            // echo "<pre>".print_r( $lids, true )."</pre>";
    
            foreach( $lids as $lid )
            {
              $learner_details = get_post_meta( $lid, "_learner_details", true );
                
              if ( isset( $learner_details['course_id'] ) && $learner_details['course_id'] > 0 )
                  $company_lids[$lid] = $lid;          
            }
    
        }  
    }

    return $company_lids;
}


function siren_get_orders_by_company($user_id = 0){
  global $wpdb;

  if ( $user_id == 0 )
      $user_id = get_current_user_id();

  $users = siren_get_company_ids_by_user( $user_id );

  if ( !empty( $users ) )
      $users_str = implode( ',', $users );
  else
      $users_str = "".$user_id;

  $emails = $wpdb->get_col( 'select meta_value from '.$wpdb->usermeta.' where meta_key = "billing_email" and user_id in ('.$users_str.')');
    
  $company_emails = array_reduce( $emails, function ( $email_str, $email ) {
    
    $comma = ",";
    
    if ( "" == $email_str )
      $comma = "";

    return $email_str.$comma."'".$email."'";

  });

           
  $query = $wpdb->get_results("SELECT {$wpdb->posts}.* FROM {$wpdb->posts}
     INNER JOIN {$wpdb->postmeta} customer ON ID = customer.post_id AND customer.meta_key = '_billing_email'
    WHERE post_type = 'shop_order' AND customer.meta_value in ({$company_emails})  
    ORDER BY {$wpdb->posts}.ID DESC");

  return $query;
}


function siren_remove_filters_with_method_name( $hook_name = '', $method_name = '', $priority = 0 ) 
{
global $wp_filter;

    // Take only filters on right hook name and priority
    if ( ! isset( $wp_filter[ $hook_name ][ $priority ] ) || ! is_array( $wp_filter[ $hook_name ][ $priority ] ) ) 
    {
        return false;
    }
    
    // Loop on filters registered
    foreach ( (array) $wp_filter[ $hook_name ][ $priority ] as $unique_id => $filter_array ) 
    {
        // Test if filter is an array ! (always for class/method)
        if ( isset( $filter_array['function'] ) && is_array( $filter_array['function'] ) ) 
        {
            // Test if object is a class and method is equal to param !
            if ( is_object( $filter_array['function'][0] ) && get_class( $filter_array['function'][0] ) && $filter_array['function'][1] == $method_name ) 
            {
                // Test for WordPress >= 4.7 WP_Hook class (https://make.wordpress.org/core/2016/09/08/wp_hook-next-generation-actions-and-filters/)
                if ( is_a( $wp_filter[ $hook_name ], 'WP_Hook' ) ) {
                    unset( $wp_filter[ $hook_name ]->callbacks[ $priority ][ $unique_id ] );
                } else {
                    unset( $wp_filter[ $hook_name ][ $priority ][ $unique_id ] );
                }
            }
        }
    }
    return false;
}


add_filter( "tutor_dashboard/nav_ui_items", "siren_dashboard_nav_items" );

function siren_dashboard_nav_items( $links )
{

    $user_id = get_current_user_id();

    $new_navs = array (
        'practical'         => __('Courses', 'tutor'),
    );

    $all_nav_items = array_insert( $links, 2, $new_navs );

    if ( $user_id != 0 )
    {
        $company_tag = get_the_author_meta( 'company_tag', $user_id );

        if ( "" != $company_tag )
        {
            $all_nav_items = array_insert( $all_nav_items, 0, array( 
              // 'corp-separator' => array( 'title' => __('Company Management','siren'), 'type' => 'separator' ),
              'company'                  => array( 'title' =>  __('Company Overview') ),
              'company-learners'         => __('Learners', 'siren'),
              // 'company-bookers'         => __('Bookers', 'siren'),
              'company-team'             => __('Team', 'siren'),
              'company-bookings'         => __('Bookings', 'siren'),
              // 'tutor-icons'              => __( 'Icons', 'siren'),
              'corp-separator-end' => array( 'type' => 'separator' ),

            ) );
        }
    }

    return $all_nav_items;

}

add_filter( "tutor_dashboard/permalinks", "siren_dashboard_links" );

function siren_dashboard_links( $links )
{

    $new_navs = array(
        'practical' => array( 'title' => __('Courses', 'siren'), 'login_require' => true, 'icon' => 'scooby' ), 
        'company' => array( 'title' => __('Overview', 'siren'), 'login_require' => true, 'icon' => 'scooby' ), 
        'company-learners' => array( 'title' => __('Learner Management', 'siren'), 'login_require' => true, 'icon' => 'scooby' ), 
                // 'company-bookers' => array( 'title' => __('Bookers', 'siren'), 'login_require' => true, 'icon' => 'scooby' ),
'company-team' => array( 'title' => __('Team Management', 'siren'), 'login_require' => true, 'icon' => 'scooby' ), 
        'company-bookings' => array( 'title' => __('Bookings Management', 'siren'), 'login_require' => true, 'icon' => 'scooby' ), 
        // 'tutor-icons' => array( 'title' => __('Icons', 'siren'), 'login_require' => true, 'icon' => 'scooby' ), 
    );

    $all_nav_items = array_insert( $links, 1, $new_navs );

    return $all_nav_items;

}


if (!function_exists( "array_insert" ) ) :

    function array_insert($array, $pos, $val)
    {
        $before = array_slice($array, 0, $pos);
    
        $after = array_slice($array, $pos);
    
        foreach ($val as $k => $v)
            $before[$k] = $v;
    
        foreach ($after as $k => $v)
            $before[$k] = $v;
    
        //array_push
    
        return $before;
    }
  
endif;
  

/*
 *  Modified version of the Tutor AJAX Login.  Provides a fix for the wp_signon redirect issue
 */


function siren_process_ajax_login(){
    tutils()->checking_nonce();

    $username = tutils()->array_get('log', $_POST);
    $password = tutils()->array_get('pwd', $_POST);
    $redirect_to = tutils()->array_get('redirect_to', $_POST);

    // $this->md_log( "Processing ajax login : ".print_r( $_POST, true ) );
    // $this->md_log( "username : ". $username );
    // $this->md_log( "password : ". $password );

    try {
      $creds = array(
        'user_login'    => trim( wp_unslash( $username ) ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        'user_password' => $password, // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
        'remember'      => isset( $_POST['rememberme'] ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
      );

      $validation_error = new \WP_Error();
      $validation_error = apply_filters( 'tutor_process_login_errors', $validation_error, $creds['user_login'], $creds['user_password'] );

      if ( $validation_error->has_errors() )
      {
        if ( $validation_error->get_error_code() ) {
          // $this->md_log( "Bailing out here" );

          wp_send_json_error( ['error' => '<strong>' . __( 'ERROR:', 'tutor' ) . '</strong> ' . $validation_error->get_error_message()] );
        }
      }
      
      if ( empty( $creds['user_login'] ) ) {
        $this->md_log( "empty creds[user_login] : ". (empty( $creds['user_login'] ) ? "True" : "False" ) );

        wp_send_json_error( ['error' => '<strong>' . __( 'ERROR:', 'tutor' ) . '</strong> ' . __( 'Username is required.', 'tutor' )] );
      }

      // On multisite, ensure user exists on current site, if not add them before allowing login.
      if ( is_multisite() ) {
        $user_data = get_user_by( is_email( $creds['user_login'] ) ? 'email' : 'login', $creds['user_login'] );

        if ( $user_data && ! is_user_member_of_blog( $user_data->ID, get_current_blog_id() ) ) {
          add_user_to_blog( get_current_blog_id(), $user_data->ID, 'customer' );
        }
      }

      // we only want this when we are logging in via ajax
      add_action ( "wp_login_failed", "siren_ajax_login_failed", 1, 2 );

      // Perform the login.
      $user = wp_signon( apply_filters( 'tutor_login_credentials', $creds ), is_ssl() );

      // we only want this when we are logging in via ajax
      remove_action ( "wp_login_failed", "siren_ajax_login_failed", 1, 2 );

      if ( is_wp_error( $user ) ) {
        // $this->md_log( "wp_signon error : ", $user->get_error_message() );

        $message = $user->get_error_message();
        $message = str_replace( '<strong>' . esc_html( $creds['user_login'] ) . '</strong>', '<strong>' . esc_html( $creds['user_login'] ) . '</strong>', $message );
        
        wp_send_json_error( ['error' => $message] );
      } else {
        // $this->md_log( "wp_signon success : " );

        wp_send_json_success([
          'redirect' => apply_filters('tutor_login_redirect_url', $redirect_to)
        ]);
      }
    } catch ( \Exception $e ) {
      // $this->md_log( "Exception : ".$e->getMessage() );

      wp_send_json_error( "total_fail" . apply_filters( 'login_errors', $e->getMessage()) );
      do_action( 'tutor_login_failed' );
    }
}

function siren_ajax_login_failed( $username, $error ) 
{

  // Send back our ajax error message
  wp_send_json_error( "There was a problem with your username or password. If you can not log in please reset your password using the 'Forgot Password?' link"  );

  // we only want this when we are logging in via ajax
  remove_action ( "wp_login_failed", "siren_ajax_login_failed", 1, 2 );

  // Theres nothing else to see here.  Move along
  exit;
}


add_action('after_switch_theme', 'siren_copy_customizer_options');

function siren_copy_customizer_options () 
{
    if( get_option( 'customiser_copied_'.CURRENT_VERSION ) != '1' ) 
    {
        update_option( 'customiser_copied_'.CURRENT_VERSION, '1' );

        // RUN THEME_ACTIVATION STUFF HERE

        $customiser_options = get_option( "theme_mods_siren-ct-".PREVIOUS_VERSION );

        // error_log( print_r( $customiser_options, true ) );

        update_option( "theme_mods_siren-ct-".CURRENT_VERSION, $customiser_options );
    }
}


function siren_get_learner_table ( $user_id = -1, $context = "", $page = 1, $sort_by = 'name', $order_by = "desc", $search = "" )
{

    if ( $user_id == -1 )
    {
        $user_id = get_current_user_id();
    }

    $lids = get_company_lids( $user_id );

    $table = get_transient( "learners_".$context );  

    if ( $table === false )
    {

        $table = array();

        if ( !empty( $lids ) )
        {
            foreach( $lids as $lid )
            {
                $learner_details = get_post_meta( $lid, "_learner_details", true );
                
                if ( isset( $learner_details['course_id'] ) && $learner_details['course_id'] > 0 )
                {
                    $calendar_data = get_post_meta( $learner_details['course_id'], '_calendar_data'. false );
                  
                    if ( is_array( $calendar_data ) )
                        $calendar_data = $calendar_data[0];

                    $start_date = date( "D, d M Y H:i", strtotime( $calendar_data['start_date_time'] ) );   // date( "Y-m-d H:i:s", 
                    $end_date = date( "D, d M Y H:i", strtotime( $calendar_data['end_date_time'] ) );

                    $product = get_post( $learner_details['course_id'] );

                    if ( $product != null )
                    {
                        $table[] = array( 
                          'id' => $lid,
                          'name' => $learner_details['fname'].' ' .$learner_details['sname'],
                          'course' => ( trim($calendar_data['product']['name']) != "" ? $calendar_data['product']['name'] : $product->post_title),
                          'start_date_time' => strtotime($calendar_data['start_date_time']),  // Used for sorting
                          'end_date_time' => strtotime($calendar_data['end_date_time']),  // Used for sorting
                          'fdate' => dateRange(strtotime($calendar_data['start_date_time']), strtotime($calendar_data['end_date_time']))."<p><small>".date( "H:i", strtotime( $calendar_data['start_date_time']) )." - ".date( "H:i", strtotime( $calendar_data['end_date_time']) )."</small></p>",
                          'certificate' => $learner_details['passed']
                        );
                    }

                    else
                    {
                        $table[] = array( 
                          'id' => $lid,
                          'name' => $learner_details['fname'].' ' .$learner_details['sname'],
                          'course' => "** COURSE NAME MISSING **" ,
                          'start_date_time' => strtotime($calendar_data['start_date_time']),  // Used for sorting
                          'end_date_time' => strtotime($calendar_data['end_date_time']),  // Used for sorting
                          'fdate' => dateRange(strtotime($calendar_data['start_date_time']), strtotime($calendar_data['end_date_time']))."<p><small>".date( "H:i", strtotime( $calendar_data['start_date_time']) )." - ".date( "H:i", strtotime( $calendar_data['end_date_time']) )."</small></p>",
                          'certificate' => $learner_details['passed']
                        );
                    }

                }
            }
        }

        set_transient( "learners_".$context, $table, 3600 );
    }

    // if we have a search key then filter the results

    if ( $search != "" )
    {
      $table = array_filter( $table, function ( $elem ) use ($search ) 
      {
          $found = false;

          if ( stripos( $elem['name'], $search ) !== false )
              $found = true;
          else if ( stripos( $elem['course'], $search ) !== false )
              $found = true;
          else if ( stripos( $elem['fdate'], $search ) !== false )
              $found = true;

          return $found;

      } );
    }

    // Sort the table
    usort( $table, "siren_sort_".$sort_by."_".$order_by );
    
    // If we now have less data reset the page number
    if ( count( $table ) < ($page-1) * 10 )
        $page = 1;

    return array ( 
        'count' => count( $table ),
        'page_size' => 10,
        'page_count' => ceil( count( $table ) /10 ),
        'page'  => (int)$page,
        'data' => array_slice( $table, ($page-1) * 10, 10 ),
        'context' => $context
        );

}

add_action('wp_ajax_page_of_learners', 'siren_page_of_learners' );

function siren_page_of_learners( )
{

    if ( !isset( $_POST['context'] ) )
    {
        wp_send_json_error( "No Context" );
        
        wp_die();
    }

    if ( !isset( $_POST['page'] ) )
    {
        wp_send_json_error( "No Page" );
        
        wp_die();
    }
   
    $context = $_POST['context'];
    $page = $_POST['page'];
    $sort_by = $_POST['sortBy'];
    $order = $_POST['order'];
    $search = $_POST['search'];

    // error_log( "search = [".$search."]" );
    
    wp_send_json_success( siren_get_learner_table ( -1, $context, $page, $sort_by, $order, $search ) );

    // wp_send_json_success(array ( 

    //       'count' => count( $table ),
    //       'page_size' => 10,
    //       'page_count' => ceil( count( $table ) / 10 ),
    //       'page' => $page,
    //       'data' => array_slice( $table, $page * 10, 10 )

    //     )

    // );

  wp_die();
}



function siren_sort_name_asc($a, $b) 
{
    return strcmp( $b['name'], $a['name'] );
}

function siren_sort_name_desc($a, $b) 
{
    return strcmp( $a['name'], $b['name'] );
}

function siren_sort_course_asc($a, $b) 
{
    return strcmp( $b['course'], $a['course'] );
}

function siren_sort_course_desc($a, $b) 
{
    return strcmp( $a['course'], $b['course'] );
}

function siren_sort_date_asc($a, $b) 
{
    return $a['start_date_time'] - $b['start_date_time'] ;
}

function siren_sort_date_desc($a, $b) 
{
    return $b['start_date_time'] - $a['start_date_time'] ;
}

function siren_sort_cert_asc($a, $b) 
{

    // error_log( "Certificate sort ascending". ( $a['certificate'] === true ? "true": "false")." <> ".( $b['certificate'] === true ? "true": "false") );

    if ( $a['certificate'] === true  && $b['certificate'] === true )
        return 0;
    else if ( $a['certificate'] === true  )
        return 1;
    else
        return -1;

    // return $b['certificate'] == $a['certificate'] ;
}

function siren_sort_cert_desc($a, $b) 
{

    if ( $b['certificate'] === true && $a['certificate'] === true )
        return 0;
    else if ( $b['certificate'] === true )
        return 1;
    else
        return -1;
}


function siren_order_details_message( $order )
{

  echo "<p><h2>You can access your account by clicking 'Login' in the right top corner.</h2></p>";

}

// add_action( 'woocommerce_order_details_before_order_table_items', 'siren_order_details_message', 10, 2 );

if ( 0 ) :
// add_action( "wp_ajax_update_trainer_doc_info", "update_trainer_details_ajax_handler" );
// add_action( "wp_ajax_nopriv_update_trainer_doc_info", "update_trainer_details_ajax_handler" );

function update_trainer_details_ajax_handler( )
{
    /*trainer docs start*/
    // error_log( "Update trainer info" );

    check_admin_referer( "Trainer_Profile_nonce", "nonce" );
    
    extract( $_REQUEST );

    // error_log( print_r( $_FILES, true ) );

    $trainer_meta = get_post_meta( $upload_trainer_id, "_trainers_meta", true );

    // error_log( print_r( $trainer_meta, true ) );

    $trainer_meta['phone'] = $phone;

    $trainer_meta['address'] = $address;
        
    $trainer_meta['dateQualExpd'] = $dateQualExpd;

    $trainer_meta['preferredVenues'] = $preferredVenues;

    // error_log( print_r( $preferredVenues, true ) );

    update_post_meta(  $upload_trainer_id, "_trainers_meta", $trainer_meta );

    // error_log( print_r( $_FILES, true ) );

    echo "success";

    die();

}

function update_trainer_details_ajax_handler1( )
{
    // /*trainer docs start*/
    // error_log( "Update trainer info" );

    // check_admin_referer( "Trainer_Profile_nonce", "nonce" );

    // error_log( "Post Data ");
    // error_log( print_r( $_POST, true ) );

    // error_log( "Request ");
    // error_log( print_r( $_REQUEST, true ) );

    // phone

    // password

    // address

    // dateQualExpd

    // preferredVenues

    // error_log( print_r( $_FILES, true ) );

    require_once ABSPATH . 'wp-admin/includes/image.php';

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $trainer_id = $_REQUEST['upload_trainer_id'];

    $file_name = $_FILES['upload_trainer_certificates']['name'];

    $file_tmp_name = $_FILES['upload_trainer_certificates']['tmp_name'];

    $uploadedfile = $_FILES['upload_trainer_certificates'];

    $upload_overrides = array('test_form' => false);

    $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

    $attach_id = $movefile["url"];

    $trainer_docs_exists = get_post_meta($trainer_id, '_trainer_meta_documentation', true);

    if (!empty($trainer_docs_exists)) {
        array_push($trainer_docs_exists, $attach_id);
        $update_data = $trainer_docs_exists;
    } else {
        $update_data[] = $attach_id;
    }

    update_post_meta($trainer_id, '_trainer_meta_documentation', $update_data);

    echo "success";

    /*trainer docs end*/

    die();
}


endif;

// add_action( 'woocommerce_checkout_before_customer_details', 'siren_custom_checkout_field' );

function siren_custom_checkout_field( ) {

    $checkout = WC()->checkout;

    echo '<div id="siren_custom_checkout_field"><h3>' . __('Type of booking') . '</h3>';

    woocommerce_form_field( 'business_or_personal', array(
        'type'          => 'select',
        'required'      => true,
        'class'         => array('business_or_personal form-row-wide'),
        'label'         => __('Are you booking this for yourself?'),
        'options'       => array( 
            
            'undefined' => 'Please select...',
            'personal'  => 'Yes, I am booking this for myself',
            'business'  => 'No, This is a company booking'            
        ),
        'placeholder'   => "Please select?",
        'default'       => 'undefined' 
        ), $checkout->get_value( 'business_or_personal' ));

    echo '</div>';

}

/**
 * Update the order meta with field value
 */
add_action( 'woocommerce_checkout_update_order_meta', 'siren_custom_checkout_field_update_order_meta' );

function siren_custom_checkout_field_update_order_meta( $order_id ) {

    // error_log( print_r( $_POST, true ) );

    if ( ! empty( $_POST['business_or_personal'] ) ) {
        update_post_meta( $order_id, 'business_or_personal', sanitize_text_field( $_POST['business_or_personal'] ) );
    }
}

/**
 * Display field value on the order edit page
 */

add_action( 'woocommerce_admin_order_data_after_billing_address', 'siren_custom_checkout_field_display_admin_order_meta', 10, 1 );

function siren_custom_checkout_field_display_admin_order_meta($order){
    echo '<p><strong>'.__('Booking Type').':</strong> ' . get_post_meta( $order->id, 'business_or_personal', true ) . '</p>';
}


add_action('woocommerce_checkout_process', 'siren_checkout_validation');

function siren_checkout_validation() 
{

	// you can add any custom validations here
	if ( empty( $_POST['business_or_personal'] ) )
		wc_add_notice( 'Please select the <b>Type of Booking</b>.', 'error' );
    else
    {
        if ( "undefined" == $_POST['business_or_personal'] )
            wc_add_notice( 'Please select the <b>Type of Booking</b>.', 'error' );
    }
    
}


add_filter('woocommerce_billing_fields', 'custom_woocommerce_billing_fields2');

function custom_woocommerce_billing_fields2($fields)
{
    $checkout = WC()->checkout;

  //  global $current_user;

    // $user_roles = $current_user->roles;
    // print_r($user_roles);
    // $user_role = array_shift($user_roles);


    $new_fields = array(
        'type'          => 'select',
        'required'      => true,
        'class'         => array('business_or_personal form-row-wide'),
        'label'         => __('Are you booking this for yourself?'),
        'options'       => array( 
            
            'undefined' => 'Please select...',
            'personal'  => 'Yes, I am booking this for myself',
            'business'  => 'No, This is a company booking'            
        ),
        'placeholder'   => "Please select?",
        'default'       => 'undefined',
        'value'         => $checkout->get_value( 'business_or_personal' ),
        'priority'      => 1
    );

    $fields = insert_before( $fields, 'billing_first_name', $new_fields, 'business_or_personal' );
    
    // error_log( print_r( $fields, true ) );

    return $fields;
}


function insert_before( $src, $target, $fields, $index )
{
    $dest = array();

    foreach( $src as $label => $data )
    {
        if ( $label == $target )
        {
            $dest[ $index ] = $fields;
        }
            
        $dest[ $label ] = $data;
    }

    return $dest;
}



// customer with all type course mail


// notifiy_get_completed_courses_by_customer();
    function notifiy_get_completed_courses_by_customer() {
        	    global $wpdb;

            $customer_users_ids =  $wpdb->get_results("SELECT * FROM wp_posts WHERE post_type = 'learner'");

              foreach( $customer_users_ids as $key => $row) {

                $p_date = $row->post_date;
                $completed_date =date('Y-m-d', strtotime($p_date));
                $three_yrs = date('Y-m-d', strtotime($completed_date .' +3 years'));
                $current_date = date("Y-m-d");
                $thirty_Days_before = date('Y-m-d', strtotime($three_yrs .' -30 days'));

                $sixty_Days_before = date('Y/m/d', strtotime($three_yrs .' -60 days'));
                $ten_month = date('Y-m-d', strtotime($completed_date .' +10 months'));
                $ten_month_fifteendays_before = date('Y-m-d', strtotime($ten_month .' -15 days'));

              ##send email
                $admin_email = get_option( 'admin_email' );
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
                $headers .= 'Reply-To: '.$admin_email. "\r\n";

// Reminder about the expiration - First aid. 30days

            if($current_date == $thirty_Days_before) {

              $course = get_post($row->post_parent);
              // print_r($course);die;
              $first_aid = array("111", "107", "140", "137","120","118");

            if (in_array($course->post_parent, $first_aid)){
              $learner_meta = get_post_meta($row->ID, "_learner_details", true);

              $user_email = $learner_meta['pemail'];


              $subject = esc_html__('Your Certificate Will Expire In 30 Days');
              $email_content = 'Your Certificate is expiring in 30 Days. Please contact us for renewal.';

              $body = '';
              $body .= '<!DOCTYPE html><html><head>';
              $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
              $body .= '<title>Siren Training</title>';
              $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
              $body .= '<div id="wrapper" dir="ltr">';
              $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
              $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
              $body .= '<tr>';
              $body .= '<td align="left" valign="top"><div id="booking_header_image">';
              $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
              $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
              $body .= '<tr><td><br /><br />';
              $body .= '<p>Hi,</p>';
              $body .= '<p>Only 30 days left until your '.$course->post_title.' certificate expires.</p>';
              // $body .= '<p>Only 30daysWe wanted to remind you that your '.$course->post_title.' certificate will expire in 30 days. If you want to remain compliant and up-to-date, please renew your certificate.</p>';
              $body .= '<p>We would love to see you on our course again. Please use the DISCOUNT CODE at the checkout page: <span style="color: #dd3061;"><b>loyal10%</b></span></p>';
              $body .= '<p><b>The code is valid for 15 days after your certificate expires.</b></p>';
              $body .= '<p>Visit our public calendar to book the course</p>';
              $body .= '<p><a href="https://www.sirentraining.co.uk/first-aid-courses/1-day-emergency-first-aid-at-work/">1 day EFAW</a> | <a href="https://www.sirentraining.co.uk/first-aid-courses/3-day-first-aid-course/">3 day FAW</a> | <a href="https://www.sirentraining.co.uk/first-aid-courses/first-aid-at-work-requalification/">2 day Requalification</a> | <a href="https://www.sirentraining.co.uk/first-aid-courses/2-days-paediatric-first-aid/">Paediatric FA</a></p>';
              $body .= '<p>If you want to book for a group, please give us a call 02037408088 or send an enquiry form from our website.</p>';

              // $body .= '<p>' . $email_content . ' <a href="https://www.sirentraining.co.uk/" target="_blank" rel="noopener noreferrer" style="color:#1f4f99; font-weight:normal; text-decoration:underline">here</a></p>';
              // $body .= '<h4>COURSE DETAILS</h4>';
              // $body .= '<p>Course Name - '.$course->post_title.'</p>';
              // $body .= '<p>Course Completed Date - '.date('d-m-Y',strtotime($row->comment_date)).'</p>';
              $body .= '<br><p>Tel:0203 740 8088<br>';
              $body .= 'email: info@sirentraining.co.uk</p><br>';
              $body .= '<p>Kind regards,<br>';
              $body .= 'The Siren team</p>';
              $body .= '<p><a href="https://www.facebook.com/SirenTraining/">Facebook</a> | <a href="https://twitter.com/SirenTraining">Twitter</a> | <a href="https://www.instagram.com/siren_training/">Instagram</a> | <a href="https://www.linkedin.com/company/siren-training-ltd/">LinkedIn</a></p>';
              $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';

                wp_mail($user_email, $subject, $body,$headers);
              }

              }

                              		// echo "<pre>"; print_r($thirty_Days_before);die;
// Reminder about the expiration - First aid. 60days


            if ($current_date == $sixty_Days_before) {
              $first_aid = array("111", "107", "140", "137","120","118");

            if (in_array($course->post_parent, $first_aid)){
              $subject = esc_html__('Your Certificate Will Expire In 60 Days');
              $email_content = 'Hello,
              Your Certificate Will Expire In 60 Days. Please login for more details.';

              $body = '';
              $body .= '<!DOCTYPE html><html><head>';
              $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
              $body .= '<title>Siren Training</title>';
              $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
              $body .= '<div id="wrapper" dir="ltr">';
              $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
              $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
              $body .= '<tr>';
              $body .= '<td align="left" valign="top"><div id="booking_header_image">';
              $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
              $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
              $body .= '<tr><td><br /><br />';

              $body .= '<p>Hi,</p>';
              $body .= '<p>We wanted to remind you that your first aid certificate will expire in 60 days. If you want to remain compliant and up-to-date, please renew your certificate.</p>';
              $body .= '<p>We would love to see you on our course again. Please use the DISCOUNT CODE at the checkout page: <span style="color: #dd3061;"><b>loyal10%</b></span></p>';
              $body .= '<p><b>The code is valid for 15 days after your certificate expires.</b></p>';
              $body .= '<p>Visit our public calendar to book the course</p>';
              $body .= '<p><a href="https://www.sirentraining.co.uk/first-aid-courses/1-day-emergency-first-aid-at-work/">1 day EFAW</a> | <a href="https://www.sirentraining.co.uk/first-aid-courses/3-day-first-aid-course/">3 day FAW</a> | <a href="https://www.sirentraining.co.uk/first-aid-courses/first-aid-at-work-requalification/">2 day Requalification</a> | <a href="https://www.sirentraining.co.uk/first-aid-courses/2-days-paediatric-first-aid/">Paediatric FA</a></p>';
              $body .= '<p>If you want to book for a group, please give us a call 02037408088 or send an enquiry form from our website.</p>';

              // $body .= '<p>Hi there,</p>';
              // $body .= '<p>' . $email_content . ' <a href="https://www.sirentraining.co.uk/" target="_blank" rel="noopener noreferrer" style="color:#1f4f99; font-weight:normal; text-decoration:underline">here</a></p>';
              // $body .= '<h4>COURSE DETAILS</h4>';
              // $body .= '<p>Course Name - '.$course->post_title.'</p>';
              // $body .= '<p>Course Completed Date - '.date('d-m-Y',strtotime($row->comment_date)).'</p>';
              // $body .= '<br><p>Tel:0203 740 8088<br>';
              // $body .= 'email: info@sirentraining.co.uk</p><br>';
              $body .= '<p>Kind regards,<br>';
              $body .= 'The Siren team</p>';
              $body .= '<p><a href="https://www.facebook.com/SirenTraining/">Facebook</a> | <a href="https://twitter.com/SirenTraining">Twitter</a> | <a href="https://www.instagram.com/siren_training/">Instagram</a> | <a href="https://www.linkedin.com/company/siren-training-ltd/">LinkedIn</a></p>';
              $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';


                wp_mail($user_email, $subject, $body,$headers);
              }
            }


// Reminder about the expiration - Fire marshal:


            if ($current_date == $ten_month_fifteendays_before) {
              $fire_marshal = array("1635", "71");

            if (in_array($course->post_parent, $fire_marshal)){
              $subject = esc_html__('Your Certificate Will Expire In 10 Months');
              $email_content = 'Hello,
              Your Certificate Will Expire In 10 Months. Please login for more details.';

              $body = '';
              $body .= '<!DOCTYPE html><html><head>';
              $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
              $body .= '<title>Siren Training</title>';
              $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
              $body .= '<div id="wrapper" dir="ltr">';
              $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
              $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
              $body .= '<tr>';
              $body .= '<td align="left" valign="top"><div id="booking_header_image">';
              $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
              $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
              $body .= '<tr><td><br /><br />';

              $body .= '<p>Hi,</p>';
              $body .= '<p>We wanted to remind you of something. You attended a fire marshal course with us 10 months ago. The Fire Service strongly recommends renewing fire marshal certificates yearly.</p>';
              $body .= '<p>We would love to see you on our course again. Please use the discount code at the checkout page: <span style="color: #dd3061;"><b>loyal10%</b></span></p>';
              $body .= '<p><b>The code is valid 15 days after your certificate expires.</b></p>';
              $body .= '<p>Visit the public calendar:</p>';
              $body .= '<p><a href="https://www.sirentraining.co.uk/first-aid-courses/fire-marshal-training/">Fire Marshal</a></p>';
              $body .= '<p>If you want to book for a group, give us a call 02037408088 or send an enquiry form.</p>';


              $body .= '<p>Kind regards,<br>';
              $body .= 'The Siren team</p>';
              $body .= '<p><a href="https://www.facebook.com/SirenTraining/">Facebook</a> | <a href="https://twitter.com/SirenTraining">Twitter</a> | <a href="https://www.instagram.com/siren_training/">Instagram</a> | <a href="https://www.linkedin.com/company/siren-training-ltd/">LinkedIn</a></p>';
              $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';


                wp_mail($user_email, $subject, $body,$headers);
              }
            }



            // Reminder about the expiration - MHFA reminder 3 years


                        if($current_date == $thirty_Days_before) {

                          $course = get_post($row->post_parent);
                          // print_r($course);die;
                          $mhfa = array("63125", "70046", "62620", "63156");

                        if (in_array($course->post_parent, $mhfa)){
                          $learner_meta = get_post_meta($row->ID, "_learner_details", true);

                          $user_email = $learner_meta['pemail'];


                          $subject = esc_html__('Your Certificate Will Expire In 30 Days');
                          $email_content = 'Your Certificate is expiring in 30 Days. Please contact us for renewal.';

                          $body = '';
                          $body .= '<!DOCTYPE html><html><head>';
                          $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
                          $body .= '<title>Siren Training</title>';
                          $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
                          $body .= '<div id="wrapper" dir="ltr">';
                          $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
                          $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
                          $body .= '<tr>';
                          $body .= '<td align="left" valign="top"><div id="booking_header_image">';
                          $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
                          $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
                          $body .= '<tr><td><br /><br />';
                          $body .= '<p>Hi,</p>';
                          $body .= '<p>You attended a mental health first aid course with us almost 3 years ago. Mental Health First Aid England strongly recommends that you refresh your knowledge after 3 years.</p>';
                          $body .= '<p>We would love to see you on our course again. Please use the discount code at the checkout page: <span style="color: #dd3061;"><b>loyal10%</b></span></p>';
                          $body .= '<p><b>The code is valid for 30 days.</b></p>';
                          $body .= '<p>Visit our public calendar to book the course</p>';
                          $body .= '<p><a href="https://www.sirentraining.co.uk/first-aid-courses/2-day-mental-health-first-aid-training/">MHFA Refresher</a></p>';
                          $body .= '<p>If you want to book a group give us a call 02037408088 or send an enquiry form.</p>';

                          // $body .= '<p>' . $email_content . ' <a href="https://www.sirentraining.co.uk/" target="_blank" rel="noopener noreferrer" style="color:#1f4f99; font-weight:normal; text-decoration:underline">here</a></p>';
                          // $body .= '<h4>COURSE DETAILS</h4>';
                          // $body .= '<p>Course Name - '.$course->post_title.'</p>';
                          // $body .= '<p>Course Completed Date - '.date('d-m-Y',strtotime($row->comment_date)).'</p>';
                          $body .= '<br>';
                          $body .= '<p>Kind regards,<br>';
                          $body .= 'The Siren team</p>';
                          $body .= '<p><a href="https://www.facebook.com/SirenTraining/">Facebook</a> | <a href="https://twitter.com/SirenTraining">Twitter</a> | <a href="https://www.instagram.com/siren_training/">Instagram</a> | <a href="https://www.linkedin.com/company/siren-training-ltd/">LinkedIn</a></p>';
                          $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';

                            wp_mail($user_email, $subject, $body,$headers);
                          }

                          }


            }

    }

    add_action ( 'get_completed_courses_by_customer', 'notifiy_get_completed_courses_by_customer' );



/**
 * @return \TUTOR\Utils
 *
 * Get all helper functions/methods
 *
 */

/*
 <b>Warning</b>:  include_once(): https:// wrapper is disabled in the server configuration by allow_url_include=0 in
  <b>/home/customer/www/staging2.sirentraining.co.uk/public_html/wp-content/themes/siren-ct-1.0.7.13/functions.php</b> on 
  line <b>3306</b><br />
<br />
<b>Warning</b>:  include_once(https://www.staging2.sirentraining.co.uk/wp-content/pluginstutor/classes/Utils.php): failed to open stream: no suitable wrapper could be found in <b>/home/customer/www/staging2.sirentraining.co.uk/public_html/wp-content/themes/siren-ct-1.0.7.13/functions.php</b> on line <b>3306</b><br />
<br />
<b>Warning</b>:  include_once(): Failed opening 'https://www.staging2.sirentraining.co.uk/wp-content/pluginstutor/classes/Utils.php' for inclusion (include_path='.:/usr/local/php74/pear') in <b>/home/customer/www/staging2.sirentraining.co.uk/public_html/wp-content/themes/siren-ct-1.0.7.13/functions.php</b> on line <b>3306</b><br />
*/

if ( ! class_exists('\TUTOR\Utils') ) {
    $plugins_url = WP_CONTENT_DIR . '/plugins/';

	include_once ( $plugins_url.'tutor/classes/Utils.php' );
}


if ( ! function_exists('tutor_utils') ) {
	function tutor_utils() {
		if(!isset($GLOBALS['tutor_utils_object'])) {
			// Use runtime cache
			$GLOBALS['tutor_utils_object'] = new \TUTOR\Utils();
		}

		return $GLOBALS['tutor_utils_object'];
	}
}

// $tut = tutor_utils()->get_option('email_to_students.completed_course');



	/**
	 * @param $course_id
	 *
	 * Send course completion E-Mail to Student
	 */
// 	 course_complete_email_to_student_custom('114879');

add_filter( 'tutor_course_complete_after', function( $course_id ) {


		$course_completed_to_student = tutor_utils()->get_option('email_to_students.completed_course');

// 		if (!$course_completed_to_student) {
// 			return;
// 		}

		$admin_email = get_option( 'admin_email' );


        if ($course_completed_to_student) {
      		$user_id = get_current_user_id();
                	     // echo "<pre>";print_r($user_id);die;

      		$course = get_post($course_id);
      		$student = get_userdata($user_id);



		        ##send email
          $subject = __('Congratulations on Finishing the Course '.$course->post_title.' Give Me your Feedback', 'tutor-pro');
          $site_url = 'https://docs.google.com/forms/d/e/1FAIpQLScZExXNswizsSmE1uPqJpTVzBUiZqQmlg56aqee10d8Pu7BlQ/viewform';
          $email_content = 'This is the feedback form about Course Complete. Please Give your Feedback.';
          $email_content .= '<a href="'.$site_url.'">Click here</a>';
          $body = '';



          $body = '';
          $body .= '<!DOCTYPE html><html><head>';
          $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
          $body .= '<title>Siren Training</title>';
          $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
          $body .= '<div id="wrapper" dir="ltr">';
          $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
          $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
          $body .= '<tr>';
          $body .= '<td align="left" valign="top"><div id="booking_header_image">';
          $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
          $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
          $body .= '<tr><td><br /><br />';
          $body .= '<p>Hi there,</p>';
          $body .= '<p>' . $email_content . '</p>';
          $body .= '<h4>COURSE DETAILS</h4>';
          $body .= '<p>Course Name - '.$course->post_title.'</p><br>';
          $body .= '<br><p>Tel:0203 740 8088<br>';
          $body .= 'email: info@sirentraining.co.uk</p><br>';
          $body .= '<p>Kind regards,<br>';
          $body .= 'The Siren team</p>';
          $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';



          $headers  = 'MIME-Version: 1.0' . "\r\n";
          $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
          $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
          $headers .= 'Reply-To: '.$admin_email. "\r\n";
          // $header = 'Content-Type: ' . $this->get_content_type() . "\r\n";

          $mail_sent = wp_mail($student->user_email, $subject, $body,$headers);

          return $mail_sent;
        }

        /*$course_completed_to_teacher = tutor_utils()->get_option('email_to_teachers.a_student_completed_course');

//         if (!$course_completed_to_teacher) {
// 			return;
// 		}
        if($course_completed_to_teacher){
		$user_id = get_current_user_id();
		$student = get_userdata($user_id);

		$course = get_post($course_id);
		$teacher = get_userdata($course->post_author);


		$subject = __($teacher->display_name . ' just completed ' . $course->post_title, 'tutor-pro');

          $site_url = get_bloginfo( 'url' );
          $email_content = 'Hello,
          This is the feedback form about Course Complete. Please Give your Feedback.';
          $email_content .= '<a href="'.$site_url.'">Click here</a>';
          $body = '';

          $body .= '<div style="width: 100%; float: left; padding: 0 0 60px; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box;">';
          $body .= '<div style="width: 100%; float: left;">';
          $body .= '<p>' . $email_content . '</p>';
          $body .= '</div>';
          $body .= '</div>';
          $headers  = 'MIME-Version: 1.0' . "\r\n";
          $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
          $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
          $headers .= 'Reply-To: '.$admin_email. "\r\n";
          wp_mail($teacher->user_email, $subject, $body,$headers);
        }*/



	},10);






//   email_cron_job_twodays_before_course_action();
  function email_cron_job_twodays_before_course_action(){
    global $wpdb;
  	$get_private_courses = get_posts(array('posts_per_page' => -1,'post_type' => 'product_variation','post_status' => 'publish','meta_query' => array(array(array ('key' => '_start_date',
//   	'value' => '1634892300',
  	'value' => time(),
  	'compare' => '>=',),),)));


    $admin_email = get_option( 'admin_email' );

    // echo "<pre>"; print_r($curdat);die;



  	foreach($get_private_courses as $get_private_course){
  		$course_id = $get_private_course->ID;

		$course = get_post($course_id);



		  		$calendar_data = get_post_meta($course_id, '_calendar_data', true);

  		                // echo "<pre>"; print_r($calendar_data);die;

  		$get_course_start_date = get_post_meta($course_id,'_start_date',true);
  	 	$get_course_start_date_fm = date('Y-m-d', $get_course_start_date);
        $currentdate = "2021-12-16";
  		$two_days_before = date('Y-m-d', strtotime($get_course_start_date_fm .' -2 days'));



  		if($two_days_before == $currentdate){


        // learners email
        $learners = get_posts( array('posts_per_page' => -1,'post_type' => 'learner','post_status' => 'publish','post_parent' => $course_id,'orderby' => 'ID','order' => 'ASC','nopaging' => true) );

        foreach($learners as $learner) {
          $learner_meta = get_post_meta( $learner->ID, '_learner_details', true );
          $learner_email[] = $learner_meta['pemail'];

          // $learner_email = 'harishankerv@gmail.com';
          if($learner_email){
          $subject = esc_html__('Siren Training upcoming Event');
            $email_content = 'You have an upcoming event in 2 days time. Please find below the details';

            $body = '';
            $body .= '<!DOCTYPE html><html><head>';
            $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
            $body .= '<title>Siren Training</title>';
            $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
            $body .= '<div id="wrapper" dir="ltr">';
            $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
            $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
            $body .= '<tr>';
            $body .= '<td align="left" valign="top"><div id="booking_header_image">';
            $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
            $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
            $body .= '<tr><td><br /><br />';
            $body .= '<p>Hi there,</p>';
            $body .= '<p>' . $email_content . '</p>';
            $body .= '<h4>EVENT DETAILS</h4>';
            $body .= '<p>Event Name - '.$calendar_data['product']['name'].'</p>';
            $body .= '<p>Start Date - '.$get_course_start_date_fm.'</p>';
            $body .= '<p>Location - '.$calendar_data['venue']['name'].'</p>';
            $body .= '<br><p>Tel:0203 740 8088<br>';
            $body .= 'email: info@sirentraining.co.uk</p><br>';
            $body .= '<p>Kind regards,<br>';
            $body .= 'The Siren team</p>';
            $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';


            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
            $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
            $headers .= 'Reply-To: '.$admin_email. "\r\n";

            wp_mail($learner_email, $subject, $body,$headers);
          }

        }


        // company email
        $client_email = get_post_meta($course_id,'privatecourse_client_mail',true);

        // $client_email = 'eficaztechsol@gmail.com';

        if($client_email){
          $subject = esc_html__('Siren Training upcoming Event');
            $email_content = 'You have an upcoming event in 2 days time. Please find below the details';

            $body = '';
            $body .= '<!DOCTYPE html><html><head>';
            $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
            $body .= '<title>Siren Training</title>';
            $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
            $body .= '<div id="wrapper" dir="ltr">';
            $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
            $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
            $body .= '<tr>';
            $body .= '<td align="left" valign="top"><div id="booking_header_image">';
            $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
            $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
            $body .= '<tr><td><br /><br />';
            $body .= '<p>Hi there,</p>';
            $body .= '<p>' . $email_content . '</p>';
            $body .= '<h4>EVENT DETAILS</h4>';
            $body .= '<p>Event Name - '.$calendar_data['product']['name'].'</p>';
            $body .= '<p>Start Date - '.$get_course_start_date_fm.'</p>';
            $body .= '<p>Location - '.$calendar_data['venue']['name'].'</p>';
            $body .= '<br><p>Tel:0203 740 8088<br>';
            $body .= 'email: info@sirentraining.co.uk</p><br>';
            $body .= '<p>Kind regards,<br>';
            $body .= 'The Siren team</p>';
            $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';

            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
            $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
            $headers .= 'Reply-To: '.$admin_email. "\r\n";

            wp_mail($client_email, $subject, $body,$headers);
          }


                // echo "<pre>client -"; print_r($client_email);


        // trainer email


  		$trainer_display_name = $calendar_data['trainer']['name'];
        $users_email = $wpdb->get_results("SELECT user_email FROM $wpdb->users WHERE display_name = '$trainer_display_name'");
        $trainer_email = $users_email[0]->user_email;
        // $All_email[] = $trainer_email;

        // $trainer_email = "keerthi.eficaz@gmail.com";
        if($trainer_email){
          $subject = esc_html__('Siren Training upcoming Event');
            $email_content = 'You have an upcoming event in 2 days time. Please find below the details';

            $body = '';
            $body .= '<!DOCTYPE html><html><head>';
            $body .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
            $body .= '<title>Siren Training</title>';
            $body .= '</head><body leftmargin="0"  topmargin="0" offset="0">';
            $body .= '<div id="wrapper" dir="ltr">';
            $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
            $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
            $body .= '<tr>';
            $body .= '<td align="left" valign="top"><div id="booking_header_image">';
            $body .= '<img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">';
            $body .= '</div></td></tr><tr><td align="right" valign="top"><div id="address"><div></td></tr>';
            $body .= '<tr><td><br /><br />';
            $body .= '<p>Hi there,</p>';
            $body .= '<p>' . $email_content . '</p>';
            $body .= '<h4>EVENT DETAILS</h4>';
            $body .= '<p>Event Name - '.$calendar_data['product']['name'].'</p>';
            $body .= '<p>Start Date - '.$get_course_start_date_fm.'</p>';
            $body .= '<p>Location - '.$calendar_data['venue']['name'].'</p>';
            $body .= '<br><p>Tel:0203 740 8088<br>';
            $body .= 'email: info@sirentraining.co.uk</p><br>';
            $body .= '<p>Kind regards,<br>';
            $body .= 'The Siren team</p>';
            $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';

            $admin_email = get_option( 'admin_email' );
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
            $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
            $headers .= 'Reply-To: '.$admin_email. "\r\n";

            wp_mail($trainer_email, $subject, $body,$headers);
          }

                        // echo "<pre>trainer -"; print_r($trainer_email);




  	   }
  	 }
  }

  add_action('email_cron_job_twodays_before_course', 'email_cron_job_twodays_before_course_action');





function course_calendar_shortcode( $atts )
{

    global $wpdb, $post;
        $postID = $post->ID;
      // May need $atts later
      if ( !empty( $atts ) )  {
        // use shortcode_atts() to set defaults then extract() to variables
        extract( shortcode_atts( array( 'id' => false ), $atts ) );
        $postID = $id;
      }

      $get_google_api_key = get_option('custom_google_api_key');


      $events = get_posts(
        array(
          'posts_per_page' => -1,
          'post_type' => 'product_variation',
          'post_parent' => $postID,
          'nopaging' => true,
          'post_status' => 'publish',
          'meta_query' => array (
            array (
              'relation' => 'AND',
              '_calendar_data' => array (
                'key' => '_calendar_data',
                'compare' => 'EXISTS',
              ),
              '_venue_code' => array (
                'key' => '_venue_code',
                'value' => 'none',
                'compare' => '!=',
              ),
              '_start_date' => array (
                'key' => '_start_date',
                'value' => time(),
                'compare' => '>',
              ),
              '_private_course' => array (
                'key' => '_private_course',
                'compare' => 'NOT EXISTS',
              ),
            )
          ),
          'orderby' => array (
            //'_venue_code' => 'DESC',
            '_start_date' => 'ASC'
          )
        )
      );
      //   echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;


      $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

      $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

      if ( $price_display_suffix )
      {
        $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
      }

      $CxVLondon = array();

      foreach( $events as $event )
      {
        $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

        $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

        $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

        /* Why? */
        global $wpdb;

        $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

        $venue_order_num = $get_gallery_main[0]->menu_order;

        if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
          continue;
        }

        $product_data = $event;

        $product = wc_setup_product_data( $product_data );

        $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

        if ( !isset ( $CxVLondon[$venue_order_num] ) )
        $CxVLondon[$venue_order_num] = $calendar_data['venue'];

        if ( $product->is_in_stock() )
        $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
        else
        $booking_link = "Sorry, course fully booked";

        $sale_price = $product->get_sale_price();

        $regular_price = $product->get_regular_price();

        $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

        if ( isset( $venue_meta['address'] ) )
        $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
        else
        $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

        $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
        $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

        $CxVLondon[$venue_order_num]['courses'][] = array (
          'p' => $event,
          'm' => $calendar_data,
          'sa' => get_total_stock( $product ),
                      'regularprice' => $regular_price,
                      'saleprice' => $sale_price,
          'price' => $price,
          'booking' => $booking_link,
        );
      }

              ksort($CxVLondon);





                    //   echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;
                   echo '
    <style>#loader {border: 5px solid #f3f3f3;border-radius: 50%;border-top: 5px solid #3498db;width: 60px;height: 60px;-webkit-animation: spin 2s linear infinite;animation: spin 2s linear infinite;position: absolute;display: none;z-index: 999;left: 0;right: 0;text-align: center;margin: 0 auto;top: 0;bottom: 0;}
    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }}</style>
                   <div class="elementor-row"><div id="loader"></div>';
                   echo '<div class="elementor-column elementor-col-75 elementor-top-column elementor-element" style="width: 100%;">';
                echo '<select name="venuname" class="venuname"><option value="">Choose Location</option>';

                foreach( $CxVLondon as $vname ) :
                        echo '<option data-postid ="'.$postID.'" value="'.$vname['key'].'">'.$vname['name'].'</option>';
                endforeach;



                echo '</select></div>';


                   // echo '<div class="elementor-column elementor-col-25 elementor-top-column elementor-element">';
                   //  echo '<select name="venudate" class="venudate">';
                   //                  echo '<option value="">Select Date</option>';
                   //
                   //  echo '</select></div></div>';
                    echo '</div>';
                    echo ' <div class="elementor-row" style="padding-bottom: 16%;overflow: hidden;">';
                    echo '<div class="elementor-column elementor-col elementor-top-column elementor-element">';
                    echo ' <div class="book_table" style="width: 100%;">';
                    echo '</div></div></div>';
}


add_action( 'wp_ajax_nopriv_venu_ajax_date', 'venu_ajax_date' );
add_action( 'wp_ajax_venu_ajax_date', 'venu_ajax_date' );
    function venu_ajax_date() {

        global $wpdb, $post,$product;
            $postID = $post->ID;

            // print_r($_POST);die;


          $events = get_posts(
                              array(
                                'posts_per_page' => -1,
                                'post_type' => 'product_variation',
                                'post_parent' => $_POST['post_id'],
                                'nopaging' => true,
                                'post_status' => 'publish',
                                'meta_query' => array (
                                  array (
                                    'relation' => 'AND',
                                    '_calendar_data' => array (
                                      'key' => '_calendar_data',
                                      'compare' => 'EXISTS',
                                    ),
                                    '_venue_code' => array (
                                      'key' => '_venue_code',
                                      'value' => $_POST['venu_id'],
                                      'compare' => '=',
                                    ),
                                    '_start_date' => array (
                                      'key' => '_start_date',
                                      'value' => time(),
                                      'compare' => '>',
                                    ),
                                    '_private_course' => array (
                                      'key' => '_private_course',
                                      'compare' => 'NOT EXISTS',
                                    ),
                                  )
                                ),
                                'orderby' => array (
                                  //'_venue_code' => 'DESC',
                                  '_start_date' => 'ASC'
                                )
                              )
                             );

                             // print_r($events);die;



                                                  // echo '<pre>';print_r($events);echo '</pre>';die;


         $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

        $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

        if ( $price_display_suffix )
        {
            $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
        }

        $CxVLondon = array();

        foreach( $events as $event )
        {
            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );
                    // echo "<pre>".print_r( $calendar_data, true )."</pre>";die;

            $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

            $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );


            /* Why? */
            global $wpdb;

            $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$_POST['venu_id']."' ");

            $venue_order_num = $get_gallery_main[0]->menu_order;

            // if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
            // continue;
            // }

            $product_data = $event;

            $product = wc_setup_product_data( $product_data );

            $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

            if ( !isset ( $CxVLondon[$venue_order_num] ) )
            $CxVLondon[$venue_order_num] = $calendar_data['venue'];

            if ( $product->is_in_stock() )
            $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
            else
            $booking_link = "Sorry, course fully booked";

            $sale_price = $product->get_sale_price();

            $regular_price = $product->get_regular_price();

            $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

            if ( isset( $venue_meta['address'] ) )
            $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
            else
            $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

            $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
            $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

            $CxVLondon[$venue_order_num]['courses'][] = array (
            'p' => $event,
            'm' => $calendar_data,
            'sa' => get_total_stock( $product ),
                        'regularprice' => $regular_price,
                        'saleprice' => $sale_price,
            'price' => $price,
            'booking' => $booking_link,
            );
        }

        ksort($CxVLondon);

        $output = ob_start( );
        wc_print_notices();



            $venuArr = '';
            foreach( $CxVLondon as $venue ) :

            $venuArr = '<table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width="100%">';
            $venuArr .= '<thead class="cf">';
            $venuArr .= '<tr>';
            $venuArr .= '<th data-firstsort="asc">Course Date</th>';
            $venuArr .= '<th>Time</th>';
            $venuArr .= '<th>Price</th>';
            $venuArr .= '<th>Seats</th>';
            $venuArr .= '<th></th>';
            $venuArr .= '</tr>';
            $venuArr .= '</thead>';
            $venuArr .= '<tbody>';
            if(!empty($venue['courses'])){
            foreach( $venue['courses'] as $course ) :
            $venuArr .= '<tr>';
            $venuArr .= '<td data-title="Course Date" >'.dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ).'</td>';
            $venuArr .= '<td data-title="Time">'.date( "H:i", strtotime( $course['m']['start_date_time'] ) ).'</td>';
            $venuArr .= '<td data-title="Price" >';
            if($course['saleprice']){
            $venuArr .= '<span class="product-sale-price">'.( "" != $course['saleprice'] ? sprintf( "%4.2lf", $course['saleprice']) . $price_display_suffix : "" ).'</span>';
            }
            $venuArr .= '<span>'.( "" != $course['regularprice'] ? sprintf( "%4.2lf", $course['regularprice']) . $price_display_suffix : "" ).'</span>';
            $venuArr .= '</td>';
            $venuArr .= '<td data-title="Seats">'.( 0 != $course['sa'] ? $course['sa'] : "" ).'</td>';
            $venuArr .= '<td data-title="">'.$course['booking'].'</td>';
            $venuArr .= '</tr>';
            endforeach;
            }else{

            $venuArr .= '<tr><td colspan="5" >No Record Found</td></tr>';


            }
            $venuArr .= '</tbody></table>';


            $venuArr .= '<table class="location" width="100%"><tbody><tr><td width="25%" valign="top"><div style="padding:0 10px;"><h3>Address</h3>'.preg_replace( "/\r\n|\r|\n/", "<br />", $venue['meta']['address'] );
            $venuArr .= "<br />".$venue['meta']['phone']."<br />";
            $venuArr .= $venue['meta']['url']."<br />";
            $venuArr .= $venue['meta']['email']."<br />";
            $venuArr .= '.</div></td><td width="50%" ><div style="overflow:hidden;height:240px;width:100%;">';
            $venuArr .=  '.<div id="gmap_canvas_'.preg_replace('/[^A-Za-z_]/', '', $venue['key'] ).'" style="height:inherit;width:inherit;" class="map_canvas"></div>';
            $venuArr .=  '<style>#gmap_canvas_'.preg_replace('/[^A-Za-z_]/', '', $venue['key'] ).' img{max-width:none!important;background:none!important}';
            $venuArr .= '</style></div></td><td  width="25%" valign="top"><div style="padding:0 10px;"><h3>Cancellation</h3><ul><li>More than 7 days = Money Back</li><li>48 Hours - 7 Days = 50% refund</li><li>Less than 48 Hours = No refund</li></ul></div></td></tr></tbody></table>
            <br />';

            endforeach;

            $get_google_api_key = get_option('custom_google_api_key');
            $venuArr .= '<style>.product-sale-price{float:left;width:100%;font-style: italic;text-decoration: line-through;}.product-original-price{color:#FF0000;}</style>';
            $venuArr .= '<script async defer>';


        foreach( $CxVLondon as $venue ) :
        $venukey = preg_replace('/[^A-Za-z_]/', '', $venue['key']);
        $venuArr .= 'function init_map_'.$venukey.'(){ ';
        // $venuArr .= 'alert("hi"); ';
        $venuArr .= 'var geocoder = new google.maps.Geocoder(); ';
        $venuArr .= 'geocoder.geocode( { "address" : "'.preg_replace( "/\r\n|\r|\n/", ", ", $venue['meta']['address'] ).'" } , function( results, status ) { ';
        $venuArr .= 'var lat = results[0].geometry.location.lat(); ';
        $venuArr .= 'var lng = results[0].geometry.location.lng(); ';
        $venuArr .= 'if ( status === "OK" ){ ';
        $venuArr .= 'var myOptions_'.$venukey.' = { zoom:10,center:new google.maps.LatLng( lat, lng ),mapTypeId: google.maps.MapTypeId.ROADMAP }; ';
        $venuArr .= 'map_'.$venukey.' = new google.maps.Map(document.getElementById("gmap_canvas_'.$venukey.'"), myOptions_'.$venukey.'); ';
        $venuArr .= 'marker_'.$venukey.' = new google.maps.Marker({ map: map_'.$venukey.',position: new google.maps.LatLng(lat, lng) }); ';
        $venuArr .= '}  });  }';
        endforeach;
        $venuArr .= ' function init_maps(){ ';
        foreach( $CxVLondon as $venue ){
        $venukey = preg_replace('/[^A-Za-z_]/', '', $venue['key']);
        $venuArr .= 'init_map_'.$venukey.'(); ';
        }
        $venuArr .= '}';



        $venuArr .= '</script>';
        $venuArr .= '<script src="https://maps.googleapis.com/maps/api/js?key='.$get_google_api_key.'&callback=init_maps" async defer></script>';

        echo json_encode($venuArr);
        wp_die();  //die();
    }

add_action( 'wp_ajax_nopriv_venu_ajax_name_date', 'venu_ajax_name_date' );
add_action( 'wp_ajax_venu_ajax_name_date', 'venu_ajax_name_date' );


// home filters


function global_course_calendar_shortcode( $atts )
{

    global $wpdb, $post;
        $postID = $post->ID;
      // May need $atts later
      if ( !empty( $atts ) )  {
        // use shortcode_atts() to set defaults then extract() to variables
        extract( shortcode_atts( array( 'id' => false ), $atts ) );
        $postID = $id;
      }

      // 62299 - Mental Health First Aid
      // 48448 - First Aid Courses
      // 3581 - Paediatric First Aid course
      // 48625 - Fire Safety Training
      // 39313 - Fire Risk Assessment

      $events = get_posts(
        array(
          'posts_per_page' => -1,
          'post_type' => 'page',
          'post__in' => array('48448','3581','62299','48625'),    //,'39313'
          'post_status' => 'publish',
          'orderby' => 'post__in'
          )
      );

      echo '
        <style>#loader {border: 5px solid #f3f3f3;border-radius: 50%;border-top: 5px solid #3498db;width: 60px;height: 60px;-webkit-animation: spin 2s linear infinite;animation: spin 2s linear infinite;position: absolute;display: none;z-index: 999;left: 0;right: 0;text-align: center;margin: 0 auto;top: 0;bottom: 0;}
        /* Safari */
        @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
        }}</style>
      <div class="elementor-row"><div id="loader"></div>';
        echo '<div class="elementor-column elementor-col-25 elementor-top-column elementor-element">';
    
            echo '<select name="training_location" class="training_location">
                <option value="">Choose Location</option>';

                echo '<option value="london">London</option>';
                echo '<option value="birmingham">Birmingham</option>';
                echo '<option value="manchester">Manchester</option>';
                
            echo '</select></div>';


        echo '<div class="elementor-column elementor-col-25 elementor-top-column elementor-element">';
    
            echo '<select name="training_category" class="training_category">
                <option value="">Choose Category</option>';

            echo '</select></div>';

        
        echo '<div class="elementor-column elementor-col-25 elementor-top-column elementor-element">';
    
            echo '<select name="training_id" class="training_id">
                <option value="">Choose Course</option>';

            echo '</select></div>';


                    // echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                    // echo '<select name="courselist" class="courselist">';
                    //                 echo '<option value="">Choose Course</option>';

                    // echo '</select></div>';
                    // echo '</div>';

                    //   echo '<div class="elementor-row"><div id="loader"></div>';

                // echo '<div class="elementor-column elementor-col-25 elementor-top-column elementor-element">';
                //     echo '<select name="venu_id" class="venu_id"><option value="">Choose Location</option>';


                //     echo '</select></div>';
                
                // // echo '<div class="elementor-column elementor-col-33 elementor-top-column elementor-element" style="padding: 10px;">';
                    
                // // echo '<select name="venudate" class="globalvenudate">';
                // //     echo '<option value="">Choose Date</option>';

                // //      echo '</select></div>';


                //     echo '</div>';
                //     echo ' <div class="elementor-row">';
                //     echo '<div class="elementor-column elementor-top-column elementor-element home_book_tables">';
                //     echo ' <div class="home_book_table">';
                //     echo '</div></div></div>';
}


add_action( 'wp_ajax_nopriv_global_course_list', 'global_course_list' );
add_action( 'wp_ajax_global_course_list', 'global_course_list' );
function global_course_list(  )
{
        global $wpdb, $post;
        $post_id = $_POST[ 'post_id' ];
        // $post_id = $post->ID;
        $choose_your_product = get_field('choose_your_product',$post_id);
        $imo = implode(",",  $choose_your_product);
        $events = get_posts(
          array(
            'posts_per_page' => -1,
            'post_type' => 'product',
            'post__in' => $choose_your_product,
            'post_status' => 'publish',
            'orderby' => 'post__in'
          )
        );
      foreach( $events as $course_post ) :
      $course_post_list[] = '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
      endforeach;

      echo json_encode($course_post_list);
      wp_die();  //die();
      }


add_action( 'wp_ajax_nopriv_global_course_list_venu_name', 'global_course_list_venu_name' );
add_action( 'wp_ajax_global_course_list_venu_name', 'global_course_list_venu_name' );
function global_course_list_venu_name(  )
{

        global $wpdb, $post;

        $post_id = $_POST['post_id'];

        $location = $_POST[ 'location' ];

        $events = get_posts(
            array(
                'posts_per_page' => -1,
                'post_type' => 'product_variation',
                'post_parent' => $post_id,
                'nopaging' => true,
                'post_status' => 'publish',
                'meta_query' => array (
                array (
                  'relation' => 'AND',
                  '_calendar_data' => array (
                    'key' => '_calendar_data',
                    'compare' => 'EXISTS',
                  ),
                  '_venue_code' => array (
                    'key' => '_venue_code',
                    'value' => 'none',
                    'compare' => '!=',
                  ),
                  '_start_date' => array (
                    'key' => '_start_date',
                    'value' => time(),
                    'compare' => '>',
                  ),
                  '_private_course' => array (
                    'key' => '_private_course',
                    'compare' => 'NOT EXISTS',
                  ),
                )
              ),
              'orderby' => array (
                //'_venue_code' => 'DESC',
                '_start_date' => 'ASC'
              )
            )
          );
          //   echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;


          $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

          $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

          if ( $price_display_suffix )
          {
            $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
          }

          $CxVLondon = array();

          foreach( $events as $event )
          {
            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

            $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

            $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

            /* Why? */
            global $wpdb;

            $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

            $venue_order_num = $get_gallery_main[0]->menu_order;

            if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
              continue;
            }

            $product_data = $event;

            $product = wc_setup_product_data( $product_data );

            $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

            if ( !isset ( $CxVLondon[$venue_order_num] ) )
            $CxVLondon[$venue_order_num] = $calendar_data['venue'];

            if ( $product->is_in_stock() )
            $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
            else
            $booking_link = "Sorry, course fully booked";

            $sale_price = $product->get_sale_price();

            $regular_price = $product->get_regular_price();

            $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

            if ( isset( $venue_meta['address'] ) )
            $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
            else
            $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

            $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
            $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

            $CxVLondon[$venue_order_num]['courses'][] = array (
              'p' => $event,
              'm' => $calendar_data,
              'sa' => get_total_stock( $product ),
                          'regularprice' => $regular_price,
                          'saleprice' => $sale_price,
              'price' => $price,
              'booking' => $booking_link,
            );
          }

        ksort($CxVLondon);

        foreach( $CxVLondon as $vname ) :
                $course_venuname_list[] = '<option data-postid ="'.$postID.'" value="'.$vname['key'].'">'.$vname['name'].'</option>';
        endforeach;



echo json_encode($course_venuname_list);
wp_die();  //die();
}

add_action( 'wp_ajax_nopriv_global_course_list_location', 'global_course_list_location' );
add_action( 'wp_ajax_global_course_list_location', 'global_course_list_location' );
function global_course_list_location(  )
{

    global $wpdb, $post;

    $post_id = $_POST['post_id'];

    $location = $_POST[ 'location' ];

    // error_log( $location );

    $events = get_posts(
        array(
            'posts_per_page' => -1,
            'post_type' => 'product_variation',
            // 'post_parent' => $post_id,
            'nopaging' => true,
            'post_status' => 'publish',
            'meta_query' => array (
            array (
                'relation' => 'AND',
                '_calendar_data' => array (
                'key' => '_calendar_data',
                'compare' => 'EXISTS',
                ),
                '_venue_code' => array (
                'key' => '_venue_code',
                'value' => 'none',
                'compare' => '!=',
                ),
                '_start_date' => array (
                'key' => '_start_date',
                'value' => strtotime( "-5 year" ), //time(),
                'compare' => '>',
                ),
                '_private_course' => array (
                'key' => '_private_course',
                'compare' => 'NOT EXISTS',
                ),
            )
            ),
            'orderby' => array (
            //'_venue_code' => 'DESC',
            '_start_date' => 'ASC'
            )
        )
    );
    //   echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;

    // error_log( "Events -> ".count( $events ) );

    $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

    $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

    if ( $price_display_suffix )
    {
        $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
    }

    $CxVLondon = array();

    foreach( $events as $event )
        {
        $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

        $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

        $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

        /* Why? */
        global $wpdb;

        $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

        $venue_order_num = $get_gallery_main[0]->menu_order;

        
        if ( strlen($venue_meta['area']) <= 0 || $venue_meta['area'] !== $location ) {
            continue;
        }
        
        // error_log( "[".$venue_meta['area']."]" );

        $product_data = $event;

        $product = wc_setup_product_data( $product_data );

        $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

        if ( !isset ( $CxVLondon[$venue_order_num] ) )
            $CxVLondon[$venue_order_num] = $calendar_data['venue'];

        if ( $product->is_in_stock() )
            $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
        else
            $booking_link = "Sorry, course fully booked";

        $sale_price = $product->get_sale_price();

        $regular_price = $product->get_regular_price();

        $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

        if ( isset( $venue_meta['address'] ) )
            $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
        else
            $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

        $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
        $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

        $CxVLondon[$venue_order_num]['courses'][] = array (
            'p' => $event,
            'm' => $calendar_data,
            'sa' => get_total_stock( $product ),
                        'regularprice' => $regular_price,
                        'saleprice' => $sale_price,
            'price' => $price,
            'booking' => $booking_link,
        );
        }

    ksort($CxVLondon);

    // error_log( count( $CxVLondon ) );

    foreach( $CxVLondon as $vname ) :
        $course_venuname_list[] = '<option data-postid ="'.$postID.'" value="'.$vname['key'].'">'.$vname['name'].'</option>';
    endforeach;

    echo json_encode($course_venuname_list);
    wp_die();  //die();
}



function global_venu_ajax_date() {

                global $wpdb, $post,$product;
                    $postID = $post->ID;

                    // print_r($_POST);die;


                  $events = get_posts(
            array(
              'posts_per_page' => -1,
              'post_type' => 'product_variation',
              'post_parent' => $_POST['post_id'],
              'nopaging' => true,
              'post_status' => 'publish',
              'meta_query' => array (
                array (
                  'relation' => 'AND',
                  '_calendar_data' => array (
                    'key' => '_calendar_data',
                    'compare' => 'EXISTS',
                  ),
                  '_venue_code' => array (
                    'key' => '_venue_code',
                    'value' => $_POST['venu_id'],
                    'compare' => '=',
                  ),
                  '_start_date' => array (
                    'key' => '_start_date',
                    'value' => time(),
                    'compare' => '>',
                  ),
                  '_private_course' => array (
                    'key' => '_private_course',
                    'compare' => 'NOT EXISTS',
                  ),
                )
              ),
              'orderby' => array (
                //'_venue_code' => 'DESC',
                '_start_date' => 'ASC'
              )
            )
          );




                 $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

                $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

                if ( $price_display_suffix )
                {
                    $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
                }

                $CxVLondon = array();

                foreach( $events as $event )
                {
                    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );
                            // echo "<pre>".print_r( $calendar_data, true )."</pre>";die;

                    $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

                    $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );


                    /* Why? */
                    global $wpdb;

                    $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$_POST['venu_id']."' ");

                    $venue_order_num = $get_gallery_main[0]->menu_order;

                    // if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
                    // continue;
                    // }

                    $product_data = $event;

                    $product = wc_setup_product_data( $product_data );

                    $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

                    if ( !isset ( $CxVLondon[$venue_order_num] ) )
                    $CxVLondon[$venue_order_num] = $calendar_data['venue'];

                    if ( $product->is_in_stock() )
                    $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
                    else
                    $booking_link = "Sorry, course fully booked";

                    $sale_price = $product->get_sale_price();

                    $regular_price = $product->get_regular_price();

                    $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

                    if ( isset( $venue_meta['address'] ) )
                    $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
                    else
                    $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

                    $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
                    $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

                    $CxVLondon[$venue_order_num]['courses'][] = array (
                    'p' => $event,
                    'm' => $calendar_data,
                    'sa' => get_total_stock( $product ),
                                'regularprice' => $regular_price,
                                'saleprice' => $sale_price,
                    'price' => $price,
                    'booking' => $booking_link,
                    );
                }



                        ksort($CxVLondon);





                // echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;

                $output = ob_start( );
                wc_print_notices();




                    foreach( $CxVLondon as $venue ) :
                      // echo '<pre>';print_r($venue);echo '</pre>';die;

                            foreach( $venue['courses'] as $course ) :

                                $venu_date[] = $course['m']['start_date_time'];

                            endforeach;


                    endforeach;
                      $venu_date['post_title'] = $course['p']->post_title;
                    // $datasss = array_unique(array_column($venu_date, 'post_title'));

                    // array_unique($venu_date['start_date_time'])
                    // array_unique($venu_date['post_title']);

                     foreach( array_unique($venu_date) as $vcourse ) :

                                $vcourse_date[] = '<option data-postid="'.$_POST['post_id'].'" value="'.$vcourse.'">'.date('d-m-Y', strtotime( $vcourse )).'</option>';

                            endforeach;

                    echo json_encode($vcourse_date);
                                                    //   echo '<pre>';print_r($venu_date);echo '</pre>';die;


                wp_die();  //die();
            }

          add_action( 'wp_ajax_nopriv_global_venu_ajax_date', 'global_venu_ajax_date' );
          add_action( 'wp_ajax_global_venu_ajax_date', 'global_venu_ajax_date' );


            function global_venu_ajax_name_date() {

                global $wpdb, $post,$product;
                    $postID =  $_POST['post_id'];

                    $vn = $_POST['venue_name'];
                    // $date = new DateTime($vd);

                     $events = get_posts(
                    array(
                    'posts_per_page' => -1,
                    'post_type' => 'product_variation',
                    'post_parent' => $postID,
                    'nopaging' => true,
                    //   'post__in'      => array($_POST['venu_id']),

                    'post_status' => 'publish',
                    'meta_query' => array (
                        array (
                        'relation' => 'AND',
                        '_calendar_data' => array (
                            'key' => '_calendar_data',
                            'compare' => 'EXISTS',
                        ),
                        '_venue_code' => array (
                            'key' => '_venue_code',
                            'value' => $_POST['venue_name'],
                            'compare' => '=',
                        ),
                        '_start_date' => array (
                            'key' => '_start_date',
                            'value' => time() ,
                            'compare' => '>',
                        ),
                        '_private_course' => array (
                            'key' => '_private_course',
                            'compare' => 'NOT EXISTS',
                        ),
                        )
                    ),
                    'orderby' => array (
                        //'_venue_code' => 'DESC',
                        '_start_date' => 'ASC'
                    )
                    )
                );

                // echo '<pre>';print_r($events);echo '</pre>';die;
                // die( print_r( $events, true ) );

                $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

                $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

                if ( $price_display_suffix )
                {
                    $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
                }

                $CxVLondon = array();

                foreach( $events as $event )
                {
                    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );
                            // echo "<pre>".print_r( $event, true )."</pre>";die;

                    $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

                    $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );


                    /* Why? */
                    global $wpdb;

                    $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$_POST['venu_id']."' ");

                    $venue_order_num = $get_gallery_main[0]->menu_order;

                    // if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
                    // continue;
                    // }

                    $product_data = $event;

                    $product = wc_setup_product_data( $product_data );

                    $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

                    if ( !isset ( $CxVLondon[$venue_order_num] ) )
                    $CxVLondon[$venue_order_num] = $calendar_data['venue'];

                    if ( $product->is_in_stock() )
                    $booking_link = sprintf( "<a data-courseid=".$event->ID." href='%s' class='button'>Book</a>", $product->add_to_cart_url());//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
                    else
                    $booking_link = "Sorry, course fully booked";

                    $sale_price = $product->get_sale_price();

                    $regular_price = $product->get_regular_price();

                    $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

                    if ( isset( $venue_meta['address'] ) )
                    $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
                    else
                    $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

                    $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
                    $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

                    $CxVLondon[$venue_order_num]['courses'][] = array (
                    'p' => $event,
                    'm' => $calendar_data,
                    'sa' => get_total_stock( $product ),
                                'regularprice' => $regular_price,
                                'saleprice' => $sale_price,
                    'price' => $price,
                    'booking' => $booking_link,
                    );
                }

                ksort($CxVLondon);

                $output = ob_start( );
                wc_print_notices();



                    $venuArr = '';
                    foreach( $CxVLondon as $venue ) :

                    $venuArr = '<table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width="100%">';
                    $venuArr .= '<thead class="cf">';
                    $venuArr .= '<tr>';
                    $venuArr .= '<th data-firstsort="asc">Course Date</th>';
                    $venuArr .= '<th>Time</th>';
                    $venuArr .= '<th>Price</th>';
                    $venuArr .= '<th>Seats</th>';
                    $venuArr .= '<th></th>';
                    $venuArr .= '</tr>';
                    $venuArr .= '</thead>';
                    $venuArr .= '<tbody>';
                    if(!empty($venue['courses'])){
                    foreach( $venue['courses'] as $course ) :
                    $venuArr .= '<tr>';
                    $venuArr .= '<td data-title="Course Date" >'.dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ).'</td>';
                    $venuArr .= '<td data-title="Time">'.date( "H:i", strtotime( $course['m']['start_date_time'] ) ).'</td>';
                    $venuArr .= '<td data-title="Price" >';
                    if($course['saleprice']){
                    $venuArr .= '<span class="product-sale-price">'.( "" != $course['saleprice'] ? sprintf( "%4.2lf", $course['saleprice']) . $price_display_suffix : "" ).'</span>';
                    }
                    $venuArr .= '<span>'.( "" != $course['regularprice'] ? sprintf( "%4.2lf", $course['regularprice']) . $price_display_suffix : "" ).'</span>';
                    $venuArr .= '</td>';
                    $venuArr .= '<td data-seatremaining="'.( 0 != $course['sa'] ? $course['sa'] : "" ).'" data-title="Seats Remaining">'.( 0 != $course['sa'] ? $course['sa'] : "" ).'</td>';
                    $venuArr .= '<td data-title="">'.$course['booking'].'</td>';
                    $venuArr .= '</tr>';
                    endforeach;
                    }else{

                    $venuArr .= '<tr><td colspan="5" >No Record Found</td></tr>';


                    }
                    $venuArr .= '</tbody></table>';


                    $venuArr .= '<table class="location" width="100%"><tbody><tr><td width="25%" valign="top"><div style="padding:0 10px;"><h3>Address</h3>'.preg_replace( "/\r\n|\r|\n/", "<br />", $venue['meta']['address'] );
                    $venuArr .= "<br />".$venue['meta']['phone']."<br />";
                    $venuArr .= $venue['meta']['url']."<br />";
                    $venuArr .= $venue['meta']['email']."<br />";
                    $venuArr .= '.</div></td><td width="50%" ><div style="overflow:hidden;height:240px;width:100%;">';
                    $venuArr .=  '.<div id="gmap_canvas_'.preg_replace('/[^A-Za-z_]/', '', $venue['key'] ).'" style="height:inherit;width:inherit;" class="map_canvas"></div>';
                    $venuArr .=  '<style>#gmap_canvas_'.preg_replace('/[^A-Za-z_]/', '', $venue['key'] ).' img{max-width:none!important;background:none!important}';
                    $venuArr .= '</style></div></td><td  width="25%" valign="top"><div style="padding:0 10px;"><h3>Cancellation</h3><ul><li>More than 7 days = Money Back</li><li>48 Hours - 7 Days = 50% refund</li><li>Less than 48 Hours = No refund</li></ul></div></td></tr></tbody></table>
                    <br />';

                    endforeach;

                    $get_google_api_key = get_option('custom_google_api_key');
                    $venuArr .= '<style>.product-sale-price{float:left;width:100%;font-style: italic;text-decoration: line-through;}.product-original-price{color:#FF0000;}</style>';
                    $venuArr .= '<script async defer>';


                foreach( $CxVLondon as $venue ) :
                $venukey = preg_replace('/[^A-Za-z_]/', '', $venue['key']);
                $venuArr .= 'function init_map_'.$venukey.'(){ ';
                // $venuArr .= 'alert("hi"); ';
                $venuArr .= 'var geocoder = new google.maps.Geocoder(); ';
                $venuArr .= 'geocoder.geocode( { "address" : "'.preg_replace( "/\r\n|\r|\n/", ", ", $venue['meta']['address'] ).'" } , function( results, status ) { ';
                $venuArr .= 'var lat = results[0].geometry.location.lat(); ';
                $venuArr .= 'var lng = results[0].geometry.location.lng(); ';
                $venuArr .= 'if ( status === "OK" ){ ';
                $venuArr .= 'var myOptions_'.$venukey.' = { zoom:10,center:new google.maps.LatLng( lat, lng ),mapTypeId: google.maps.MapTypeId.ROADMAP }; ';
                $venuArr .= 'map_'.$venukey.' = new google.maps.Map(document.getElementById("gmap_canvas_'.$venukey.'"), myOptions_'.$venukey.'); ';
                $venuArr .= 'marker_'.$venukey.' = new google.maps.Marker({ map: map_'.$venukey.',position: new google.maps.LatLng(lat, lng) }); ';
                $venuArr .= '}  });  }';
                endforeach;
                $venuArr .= ' function init_maps(){ ';
                foreach( $CxVLondon as $venue ){
                $venukey = preg_replace('/[^A-Za-z_]/', '', $venue['key']);
                $venuArr .= 'init_map_'.$venukey.'(); ';
                }
                $venuArr .= '}';



                $venuArr .= '</script>';
                $venuArr .= '<script src="https://maps.googleapis.com/maps/api/js?key='.$get_google_api_key.'&callback=init_maps" async defer></script>';

                echo json_encode($venuArr);
                wp_die();  //die();
            }

        add_action( 'wp_ajax_nopriv_global_venu_ajax_name_date', 'global_venu_ajax_name_date' );
        add_action( 'wp_ajax_global_venu_ajax_name_date', 'global_venu_ajax_name_date' );






        // bookers filter



        function booker_course_calendar_shortcode( $atts )
        {

            global $wpdb, $post;
                $postID = $post->ID;
              // May need $atts later
              if ( !empty( $atts ) )  {
                // use shortcode_atts() to set defaults then extract() to variables
                extract( shortcode_atts( array( 'id' => false ), $atts ) );
                $postID = $id;
              }

              // 62299 - Mental Health First Aid
              // 48448 - First Aid Courses
              // 3581 - Paediatric First Aid course
              // 48625 - Fire Safety Training
              // 39313 - Fire Risk Assessment

              $events = get_posts(
                array(
                  'posts_per_page' => -1,
                  'post_type' => 'page',
                  'post__in' => array('48448','3581','62299','48625'),    //,'39313'
                  'post_status' => 'publish',
                  'orderby' => 'post__in'
                  )
              );

              echo '
            <style>#loader {border: 5px solid #f3f3f3;border-radius: 50%;border-top: 5px solid #3498db;width: 60px;height: 60px;-webkit-animation: spin 2s linear infinite;animation: spin 2s linear infinite;position: absolute;display: none;z-index: 999;left: 0;right: 0;text-align: center;margin: 0 auto;top: 0;bottom: 0;}
            /* Safari */
            @-webkit-keyframes spin {
              0% { -webkit-transform: rotate(0deg); }
              100% { -webkit-transform: rotate(360deg); }
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }}</style>
                           <div class="elementor-row"><div id="loader"></div>';
                           echo '<div class="elementor-column elementor-col-25 elementor-top-column elementor-element" style="width: 100%;padding: 10px;">';
                            echo '<select name="course_type" class="course_type" style="border-radius: 20px;">';
                                            echo '<option value="">Choose Type</option>';
                                            echo '<option data-postid ="'.$postID.'" value="inhouse">InHouse</option>';
                                            echo '<option data-postid ="'.$postID.'" value="external">External</option>';

                            echo '</select></div>';

                           echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                        echo '<select name="training_id" class="training_id"><option value="">Choose Training</option>';

                        foreach( $events as $post ) :
                                echo '<option value="'.$post->ID.'">'.$post->post_title.'</option>';
                        endforeach;



                        echo '</select></div>';
                           echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                            echo '<select name="courselist" class="courselist">';
                                            echo '<option value="">Choose Course</option>';

                            echo '</select></div>';


                            echo '</div>';


                              echo '<div class="elementor-row"><div id="loader"></div>';
                              echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element inhousevenudatediv" style="width: 100%;display:none;">';
                               echo '<input type="date" style="border-radius: 20px;padding15px 0;" placeholder="Enter the Date" class="inhousevenudate" name="venudate" value=""></div>';

                            echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                         echo '<select name="venu_id" class="venu_id"><option value="">Choose Location</option>';


                         echo '</select></div>';
                            echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                             echo '<select name="venudate" class="bookervenudate">';
                                             echo '<option value="">Choose Date</option>';

                             echo '</select></div>';

                            echo '</div>';

                            echo ' <div class="elementor-row">';

                            echo '<div class="elementor-column elementor-col elementor-top-column elementor-element coursevenudate" style="display:none;"></div>';
                            echo '</div>';


                            echo ' <div class="elementor-row">';

                            echo '<div class="home_book_table" style="display:none;"></div>';
                            echo '</div>';

                            // echo ' <div class="elementor-row">';
                            // echo '<div class="elementor-column elementor-col elementor-top-column elementor-element coursevenudate1" style="display:none;"></div>';
                            // echo '</div>';


                            echo ' <div class="elementor-row"><div class="elementor-column-50 elementor-top-column elementor-element">';

                            echo '</div></div>';
        }


        add_action( 'wp_ajax_nopriv_booker_course_list', 'booker_course_list' );
        add_action( 'wp_ajax_booker_course_list', 'booker_course_list' );
        function booker_course_list(  )
        {
                global $wpdb, $post;
                $post_id = $_POST['post_id'];
                // $post_id = $post->ID;
                $choose_your_product = get_field('choose_your_product',$post_id);
                $imo = implode(",",  $choose_your_product);
                $events = get_posts(
                  array(
                    'posts_per_page' => -1,
                    'post_type' => 'product',
                    'post__in' => $choose_your_product,
                    'post_status' => 'publish',
                    'orderby' => 'post__in'
                  )
                );
              foreach( $events as $course_post ) :
              $course_post_list[] = '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
              endforeach;

              echo json_encode($course_post_list);
              wp_die();  //die();
              }


              add_action( 'wp_ajax_nopriv_booker_course_list_venu_name', 'booker_course_list_venu_name' );
              add_action( 'wp_ajax_booker_course_list_venu_name', 'booker_course_list_venu_name' );
              function booker_course_list_venu_name(  )
              {

                global $wpdb, $post;

                $post_id = $_POST['post_id'];


                  $events = get_posts(
                    array(
                      'posts_per_page' => -1,
                      'post_type' => 'product_variation',
                      'post_parent' => $post_id,
                      'nopaging' => true,
                      'post_status' => 'publish',
                      'meta_query' => array (
                        array (
                          'relation' => 'AND',
                          '_calendar_data' => array (
                            'key' => '_calendar_data',
                            'compare' => 'EXISTS',
                          ),
                          '_venue_code' => array (
                            'key' => '_venue_code',
                            'value' => 'none',
                            'compare' => '!=',
                          ),
                          '_start_date' => array (
                            'key' => '_start_date',
                            'value' => time(),
                            'compare' => '>',
                          ),
                          '_private_course' => array (
                            'key' => '_private_course',
                            'compare' => 'NOT EXISTS',
                          ),
                        )
                      ),
                      'orderby' => array (
                        //'_venue_code' => 'DESC',
                        '_start_date' => 'ASC'
                      )
                    )
                  );
                  //   echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;


                  $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

                  $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

                  if ( $price_display_suffix )
                  {
                    $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
                  }

                  $CxVLondon = array();

                  foreach( $events as $event )
                  {
                    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

                    $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

                    $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

                    /* Why? */
                    global $wpdb;

                    $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

                    $venue_order_num = $get_gallery_main[0]->menu_order;

                    if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
                      continue;
                    }

                    $product_data = $event;

                    $product = wc_setup_product_data( $product_data );

                    $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

                    if ( !isset ( $CxVLondon[$venue_order_num] ) )
                    $CxVLondon[$venue_order_num] = $calendar_data['venue'];

                    if ( $product->is_in_stock() )
                    $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
                    else
                    $booking_link = "Sorry, course fully booked";

                    $sale_price = $product->get_sale_price();

                    $regular_price = $product->get_regular_price();

                    $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

                    if ( isset( $venue_meta['address'] ) )
                    $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
                    else
                    $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

                    $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
                    $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

                    $CxVLondon[$venue_order_num]['courses'][] = array (
                      'p' => $event,
                      'm' => $calendar_data,
                      'sa' => get_total_stock( $product ),
                                  'regularprice' => $regular_price,
                                  'saleprice' => $sale_price,
                      'price' => $price,
                      'booking' => $booking_link,
                    );
                  }

                          ksort($CxVLondon);

                          foreach( $CxVLondon as $vname ) :
                                  $course_venuname_list[] = '<option data-postid ="'.$postID.'" value="'.$vname['key'].'">'.$vname['name'].'</option>';
                          endforeach;



                    echo json_encode($course_venuname_list);
                    wp_die();  //die();
                    }


                    function booker_venu_ajax_date() {

                        global $wpdb, $post,$product;
                            $postID = $post->ID;

                            // print_r($_POST);die;


                          $events = get_posts(
                    array(
                      'posts_per_page' => -1,
                      'post_type' => 'product_variation',
                      'post_parent' => $_POST['post_id'],
                      'nopaging' => true,
                      'post_status' => 'publish',
                      'meta_query' => array (
                        array (
                          'relation' => 'AND',
                          '_calendar_data' => array (
                            'key' => '_calendar_data',
                            'compare' => 'EXISTS',
                          ),
                          '_venue_code' => array (
                            'key' => '_venue_code',
                            'value' => $_POST['venu_id'],
                            'compare' => '=',
                          ),
                          '_start_date' => array (
                            'key' => '_start_date',
                            'value' => time(),
                            'compare' => '>',
                          ),
                          '_private_course' => array (
                            'key' => '_private_course',
                            'compare' => 'NOT EXISTS',
                          ),
                        )
                      ),
                      'orderby' => array (
                        //'_venue_code' => 'DESC',
                        '_start_date' => 'ASC'
                      )
                    )
                  );




                         $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

                        $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

                        if ( $price_display_suffix )
                        {
                            $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
                        }

                        $CxVLondon = array();

                        foreach( $events as $event )
                        {
                            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );
                                    // echo "<pre>".print_r( $calendar_data, true )."</pre>";die;

                            $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

                            $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );


                            /* Why? */
                            global $wpdb;

                            $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$_POST['venu_id']."' ");

                            $venue_order_num = $get_gallery_main[0]->menu_order;

                            // if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
                            // continue;
                            // }

                            $product_data = $event;

                            $product = wc_setup_product_data( $product_data );

                            $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

                            if ( !isset ( $CxVLondon[$venue_order_num] ) )
                            $CxVLondon[$venue_order_num] = $calendar_data['venue'];

                            if ( $product->is_in_stock() )
                            $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
                            else
                            $booking_link = "Sorry, course fully booked";

                            $sale_price = $product->get_sale_price();

                            $regular_price = $product->get_regular_price();

                            $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

                            if ( isset( $venue_meta['address'] ) )
                            $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
                            else
                            $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

                            $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
                            $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

                            $CxVLondon[$venue_order_num]['courses'][] = array (
                            'p' => $event,
                            'm' => $calendar_data,
                            'sa' => get_total_stock( $product ),
                                        'regularprice' => $regular_price,
                                        'saleprice' => $sale_price,
                            'price' => $price,
                            'booking' => $booking_link,
                            );
                        }



                                ksort($CxVLondon);





                        // echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;

                        $output = ob_start( );
                        wc_print_notices();




                            foreach( $CxVLondon as $venue ) :
                              // echo '<pre>';print_r($venue);echo '</pre>';die;

                                    foreach( $venue['courses'] as $course ) :

                                        $venu_date[] = $course['m']['start_date_time'];

                                    endforeach;


                            endforeach;
                              $venu_date['post_title'] = $course['p']->post_title;
                            // $datasss = array_unique(array_column($venu_date, 'post_title'));

                            // array_unique($venu_date['start_date_time'])
                            // array_unique($venu_date['post_title']);

                             foreach( array_unique($venu_date) as $vcourse ) :

                                        $vcourse_date[] = '<option data-postid="'.$_POST['post_id'].'" value="'.$vcourse.'">'.date('d-m-Y', strtotime( $vcourse )).'</option>';

                                    endforeach;

                            echo json_encode($vcourse_date);
                                                            //   echo '<pre>';print_r($venu_date);echo '</pre>';die;


                        wp_die();  //die();
                    }

                  add_action( 'wp_ajax_nopriv_booker_venu_ajax_date', 'booker_venu_ajax_date' );
                  add_action( 'wp_ajax_booker_venu_ajax_date', 'booker_venu_ajax_date' );




                    function booker_venu_ajax_name_date() {

                        global $wpdb, $post,$product;
                            $postID =  $_POST['post_id'];

                            $vd = $_POST['venu_date'];
                            $date = new DateTime($vd);

                             $events = get_posts(
                            array(
                            'posts_per_page' => -1,
                            'post_type' => 'product_variation',
                            'post_parent' => $postID,
                            'nopaging' => true,
                            //   'post__in'      => array($_POST['venu_id']),

                            'post_status' => 'publish',
                            'meta_query' => array (
                                array (
                                'relation' => 'AND',
                                '_calendar_data' => array (
                                    'key' => '_calendar_data',
                                    'compare' => 'EXISTS',
                                ),
                                '_venue_code' => array (
                                    'key' => '_venue_code',
                                    'value' => $_POST['venu_name'],
                                    'compare' => '=',
                                ),
                                '_start_date' => array (
                                    'key' => '_start_date',
                                    'value' => strtotime($_POST['venu_date']),
                                    'compare' => '=',
                                ),
                                '_private_course' => array (
                                    'key' => '_private_course',
                                    'compare' => 'NOT EXISTS',
                                ),
                                )
                            ),
                            'orderby' => array (
                                //'_venue_code' => 'DESC',
                                '_start_date' => 'ASC'
                            )
                            )
                        );

                                                                  // echo '<pre>';print_r($events);echo '</pre>';die;


                         $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

                        $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

                        if ( $price_display_suffix )
                        {
                            $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
                        }

                        $CxVLondon = array();

                        foreach( $events as $event )
                        {
                            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );
                                    // echo "<pre>".print_r( $event, true )."</pre>";die;

                            $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

                            $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );


                            /* Why? */
                            global $wpdb;

                            $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$_POST['venu_id']."' ");

                            $venue_order_num = $get_gallery_main[0]->menu_order;

                            // if ( strlen($venue_meta['area']) > 0 && $venue_meta['area'] !== 'london') {
                            // continue;
                            // }

                            $product_data = $event;

                            $product = wc_setup_product_data( $product_data );

                            $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

                            if ( !isset ( $CxVLondon[$venue_order_num] ) )
                            $CxVLondon[$venue_order_num] = $calendar_data['venue'];

                            if ( $product->is_in_stock() )
                            $booking_link = sprintf( "<a data-courseid=".$event->ID." href='%s' class='button'>Book</a>", $product->add_to_cart_url());//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
                            else
                            $booking_link = "Sorry, course fully booked";

                            $sale_price = $product->get_sale_price();

                            $regular_price = $product->get_regular_price();

                            $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

                            if ( isset( $venue_meta['address'] ) )
                            $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
                            else
                            $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

                            $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
                            $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

                            $CxVLondon[$venue_order_num]['courses'][] = array (
                            'p' => $event,
                            'm' => $calendar_data,
                            'sa' => get_total_stock( $product ),
                                        'regularprice' => $regular_price,
                                        'saleprice' => $sale_price,
                            'price' => $price,
                            'booking' => $booking_link,
                            );


                        }
                        // print_r($CxVLondon[$venue_order_num]['courses'][0]['p']->ID);die;
                        $courseid = $CxVLondon[$venue_order_num]['courses'][0]['p']->ID;
                        // $seatremaining = ( 0 != $course['sa'] ? $course['sa'] : "" );


                        ksort($CxVLondon);

                        $output = ob_start( );
                        wc_print_notices();



                            $venuArr = '';
                            foreach( $CxVLondon as $venue ) :
                            $venuArr = '<table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width="100%">';
                            $venuArr .= '<thead class="cf">';
                            $venuArr .= '<tr>';
                            $venuArr .= '<th data-firstsort="asc">Course Date</th>';
                            $venuArr .= '<th>Time</th>';
                            $venuArr .= '<th>Price</th>';
                            $venuArr .= '<th>Seats</th>';
                            // $venuArr .= '<th></th>';
                            $venuArr .= '</tr>';
                            $venuArr .= '</thead>';
                            $venuArr .= '<tbody>';
                            if(!empty($venue['courses'])){
                            foreach( $venue['courses'] as $course ) :
                            $venuArr .= '<tr>';
                            $venuArr .= '<td data-title="Course Date" >'.dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ).'</td>';
                            $venuArr .= '<td data-title="Time">'.date( "H:i", strtotime( $course['m']['start_date_time'] ) ).'</td>';
                            $venuArr .= '<td data-title="Price" >';
                            if($course['saleprice']){
                            $venuArr .= '<span class="product-sale-price">'.( "" != $course['saleprice'] ? sprintf( "%4.2lf", $course['saleprice']) . $price_display_suffix : "" ).'</span>';
                            }
                            $venuArr .= '<span>'.( "" != $course['regularprice'] ? sprintf( "%4.2lf", $course['regularprice']) . $price_display_suffix : "" ).'</span>';
                            $venuArr .= '</td>';
                            $venuArr .= '<td class="tdseatremaining" data-seatremaining="'.( 0 != $course['sa'] ? $course['sa'] : "" ).'" data-title="Seats Remaining">'.( 0 != $course['sa'] ? $course['sa'] : "" ).'</td>';
                            // $venuArr .= '<td data-title="">'.$course['booking'].'</td>';
                            $venuArr .= '</tr>';

                            endforeach;
                            }else{

                            $venuArr .= '<tr><td colspan="5" >No Record Found</td></tr>';


                            }
                            $venuArr .= '</tbody></table>';


                            $venuArr .= '<table class="location" width="100%"><tbody><tr><td width="25%" valign="top"><div style="padding:0 10px;"><h3>Address</h3>'.preg_replace( "/\r\n|\r|\n/", "<br />", $venue['meta']['address'] );
                            $venuArr .= "<br />".$venue['meta']['phone']."<br />";
                            $venuArr .= $venue['meta']['url']."<br />";
                            $venuArr .= $venue['meta']['email']."<br />";
                            $venuArr .= '.</div></td><td width="50%" ><div style="overflow:hidden;height:240px;width:100%;">';
                            $venuArr .=  '.<div id="gmap_canvas_'.preg_replace('/[^A-Za-z_]/', '', $venue['key'] ).'" style="height:inherit;width:inherit;" class="map_canvas"></div>';
                            $venuArr .=  '<style>#gmap_canvas_'.preg_replace('/[^A-Za-z_]/', '', $venue['key'] ).' img{max-width:none!important;background:none!important}';
                            $venuArr .= '</style></div></td><td  width="25%" valign="top"><div style="padding:0 10px;"><h3>Cancellation</h3><ul><li>More than 7 days = Money Back</li><li>48 Hours - 7 Days = 50% refund</li><li>Less than 48 Hours = No refund</li></ul></div></td></tr></tbody></table>
                            <br />';

                            endforeach;

                            $get_google_api_key = get_option('custom_google_api_key');
                            $venuArr .= '<style>.product-sale-price{float:left;width:100%;font-style: italic;text-decoration: line-through;}.product-original-price{color:#FF0000;}</style>';
                            $venuArr .= '<script async defer>';


                        foreach( $CxVLondon as $venue ) :
                        $venukey = preg_replace('/[^A-Za-z_]/', '', $venue['key']);
                        $venuArr .= 'function init_map_'.$venukey.'(){ ';
                        // $venuArr .= 'alert("hi"); ';
                        $venuArr .= 'var geocoder = new google.maps.Geocoder(); ';
                        $venuArr .= 'geocoder.geocode( { "address" : "'.preg_replace( "/\r\n|\r|\n/", ", ", $venue['meta']['address'] ).'" } , function( results, status ) { ';
                        $venuArr .= 'var lat = results[0].geometry.location.lat(); ';
                        $venuArr .= 'var lng = results[0].geometry.location.lng(); ';
                        $venuArr .= 'if ( status === "OK" ){ ';
                        $venuArr .= 'var myOptions_'.$venukey.' = { zoom:10,center:new google.maps.LatLng( lat, lng ),mapTypeId: google.maps.MapTypeId.ROADMAP }; ';
                        $venuArr .= 'map_'.$venukey.' = new google.maps.Map(document.getElementById("gmap_canvas_'.$venukey.'"), myOptions_'.$venukey.'); ';
                        $venuArr .= 'marker_'.$venukey.' = new google.maps.Marker({ map: map_'.$venukey.',position: new google.maps.LatLng(lat, lng) }); ';
                        $venuArr .= '}  });  }';
                        endforeach;
                        $venuArr .= ' function init_maps(){ ';
                        foreach( $CxVLondon as $venue ){
                        $venukey = preg_replace('/[^A-Za-z_]/', '', $venue['key']);
                        $venuArr .= 'init_map_'.$venukey.'(); ';
                        }
                        $venuArr .= '}';



                        $venuArr .= '</script>';
                        $venuArr .= '<script src="https://maps.googleapis.com/maps/api/js?key='.$get_google_api_key.'&callback=init_maps" async defer></script>';

$venuArr .= '<div class="addattendee">';
$venuArr .= '<h2>Add Attendee <button class="addseat">Add Seat</button></h2>';
// $venuArr .= '<form id="addsubmitseat">';
$venuArr .= '<form id="addsubmitseat" method="post" action="javascript:void(0)">';
$venuArr .= '<input type="hidden" class="courseid" name="courseid" value="'.$courseid.'" />';
$venuArr .= '<input type="hidden" class="seats" name="seats" value="" />';
$venuArr .= '<input type="hidden" class="seatcnt" name="seatcnt" value="1" />';
// $venuArr .= '<table><thead><tr><th>First Name</th><th>Surname</th><th>Personal E-mail</th><th>Personal Phone</th><th>Contact E-mail</th><th>Price Paid</th></tr></thead>';
$venuArr .= '<div class="searemaining"><div class="dataseatremaining"><input name="fname1" type="text" required class="col3 fname" placeholder="First Name" value="" /><input name="sname1" type="text" required class="col3 sname" placeholder="Surname" value="" /><input name="pemail1" placeholder="Personal E-mail" type="text" required class="col3 pemail" value="" /><input placeholder="Personal Phone" name="phone1" type="text" required class="col3 phone" value="" /><input placeholder="Contact E-mail" name="cemail1" type="text" required class="col3 cemail" value="" /><input placeholder="Price Paid" name="price1" type="text" required class="col3 price" value="" /></div></div>';
// $venuArr .= '</table></div>';
// $venuArr .= '<input class="addsubmitseat" value="Submit" type="Submit">';
$venuArr .= '<button type="submit" id="send_form" class="btn btn-block btn-success">Submit</button>';

$venuArr .= '</form>';
$venuArr .= '</div>';

// for($i=0;$i<count($searemaining);$i++) {
//   $venuArr .= '<tr><td><input name="fname[]" type="text" value="" /></td><td><input name="sname[]" type="text" value="" /></td><td><input name="pemail[]" type="text" value="" /></td><td><input name="phone[]" type="text" value="" /></td><td><input name="cemail[]" type="text" value="" /></td><td><input name="price[]" type="text" value="" /></td></tr>';
// }


                        echo json_encode($venuArr);
                        wp_die();  //die();
                    }

                add_action( 'wp_ajax_nopriv_booker_venu_ajax_name_date', 'booker_venu_ajax_name_date' );
                add_action( 'wp_ajax_booker_venu_ajax_name_date', 'booker_venu_ajax_name_date' );

                function booker_api_post_save_learner()
                {
                    // return $_POST;
                    $data = $_POST;
                    // print_r($data);die;
                    // seatcnt
                    for($i=0; $i<count($data['seatcnt']);$i++) {
                      // code...




                            // if (0 == $data['id']) {
                                $newlearner = array(
                                    'post_title' => $data['fname'][$i]." ".$data['sname'][$i],
                                    'post_name' => sanitize_title($data['fname'][$i]." ".$data['sname'][$i]),
                                    'post_status' => 'publish',
                                    'post_parent' => $data['courseid'],
                                    'post_type' => 'learner',
                                    'guid' => "",
                                    'post_content' => "", // print_r($data, true)
                                );

                                $newlearner_id = wp_insert_post($newlearner);

                                // $lData['id'] = $newlearner_id;

                                $lData = array(
                                      'id'          =>    $newlearner_id,
                                      'fname'       =>    $data['fname'][$i],
                                      'sname'       =>    $data['sname'][$i],
                                      'pemail'      =>    $data['pemail'][$i],
                                      'phone'       =>    $data['phone'][$i],
                                      'cemail'      =>    $data['cemail'][$i],
                                      'passed'      =>    false,
                                      'certificate' =>    1,
                                      'course_id'   =>    $data['courseid'],
                                      'price'       =>    $data['price'][$i],
                                      'source'      =>    'Siren',

                                      );

                                serialize($lData);
                                // Add lid here

                                $user = get_user_by( "email", $data['pemail'][$i] );

                                if ( $user !== FALSE )
                                {
                                    // Add learner id to lids
                                    $uid = $user->ID;
                                   // tutils()->do_enroll( $data['courseid'], $order_id, $uid );
                                   update_user_meta( $uid, '_l2c_'.$data['id'], $newlearner_id);
                                }
                                   update_post_meta($newlearner_id, '_learner_details', $lData);

                    }

                    echo json_encode(array( 'id' => (int) $data['courseid'], 'data' => $lData, 'status' => 'success' ));

                    // echo 'success';

                    // $data['registered'] = email_exists( $data['pemail'] );

                    // return array( 'id' => (int) $data['id'], 'registered' => $data['registered'] );
                    // return json_ecode(array('status' => 'success'));
                }

                add_action( 'wp_ajax_nopriv_booker_api_post_save_learner', 'booker_api_post_save_learner' );
                add_action( 'wp_ajax_booker_api_post_save_learner', 'booker_api_post_save_learner' );



                function venu_ajax_coursetype()
                {

                        $data = $_POST;
// echo "<pre>";print_($data);die;
// return array($data);
                        global $current_user;

                        get_currentuserinfo();
                        $current_user_email= $current_user->user_email;
                        $current_user_name= $current_user->display_name;
                        // print_r($current_user_name);die;

                        $user_id = get_current_user_id();

                        $post   = get_post( $data['courseid'] );
                        $date   = date('d-m-Y',strtotime($data['inhouse_date']));

                        $admin_email = get_option( 'admin_email' );
                        // $admin_email = 'ajithkumar072@gmail.com';
                // if(is_user_logged_in()){
$dataTable = '';
for($i=0; $i<count($data['seatcnt']);$i++) {

  $dataTable .= '<tr><td>'.$data['fname'][$i].'</td><td>'.$data['sname'][$i].'</td><td>'.$data['pemail'][$i].'</td><td>'.$data['phone'][$i].'</td><td>'.$data['cemail'][$i].'</td><td>'.$data['price'][$i].'</td></tr>';

}
                        if(!empty($admin_email)){
                            $subject = "Sirentraining New Course Request";
                            $message = '
                            <!DOCTYPE html>
                            <html>
                            <head>
                            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                            <title>Siren Training</title>
                            </head>
                            <body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="font-family: "Arial", sans-serif;">
                            <div id="wrapper" dir="ltr">
                            <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
                            <tr>
                            <td align="center" valign="top">
                            <table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">
                            <tr>
                            <td align="left" valign="top">
                            <div id="booking_header_image">
                            <img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">
                            </div>
                            </td>
                            </tr>
                            <tr>
                            <td>
                            <p>Hello</p>
                            <p>You have received a new booking for an In-house course.</p>
                            <p>Course Details: '.$post->post_title.'</p>
                            <p>Course Date: '.$date.'</p>
                            <p>User Details: '.$current_user_email.'</p>
                            <p>Thank you.</p>
                            <br>
                            <p>Kind regards,<br>
                            The Siren team</p>
                            </td>
                            </tr>

                            <tr>
                            <td><table>
                            <thead><tr><th>First Name</th><th>SurName</th><th>PEmail</th><th>Phone</th><th>CEmail</th><th>Price</th></tr></thead>
                            <tbody>'.$dataTable.'</tbody>
                            </table>

                            </td>
                            </tr>
                            </tbody></table></td></tr></tbody></table></div></body></html>';

                            $headers  = 'MIME-Version: 1.0' . "\r\n";
                            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                            $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
                            $headers .= 'Reply-To: '.$admin_email. "\r\n";
                            wp_mail($admin_email, $subject, $message, $headers, '');
                        }


                        if(!empty($current_user_email)){
                            $subject = "Sirentraining New Course Request";
                            $message = '
                            <!DOCTYPE html>
                            <html>
                            <head>
                            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                            <title>Siren Training</title>
                            </head>
                            <body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="font-family: "Arial", sans-serif;">
                            <div id="wrapper" dir="ltr">
                            <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
                            <tr>
                            <td align="center" valign="top">
                            <table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">
                            <tr>
                            <td align="left" valign="top">
                            <div id="booking_header_image">
                            <img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize">
                            </div>
                            </td>
                            </tr>
                            <tr>
                            <td>
                            <p>Hi '.$current_user_name.'</p>
                            <p>Thanks for showing interest in our '.$post->post_title.'.</p>
                            <p>We will update you once the booking process is completed.</p>

                            <p>Thanks again for choosing us.</p>
                            <br>
                            <p>Kind regards,<br>
                            The Siren team</p>
                            <p><a href="https://www.facebook.com/SirenTraining/">Facebook</a> | <a href="https://twitter.com/SirenTraining">Twitter</a> | <a href="https://www.instagram.com/siren_training/">Instagram</a> | <a href="https://www.linkedin.com/company/siren-training-ltd/">LinkedIn</a></p>
                            </td>
                            </tr>
                            </tbody></table>
                            </td></tr></tbody></table></div></body></html>';

                            $headers  = 'MIME-Version: 1.0' . "\r\n";
                            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                            $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
                            $headers .= 'Reply-To: '.$admin_email. "\r\n";
                            wp_mail($current_user_email, $subject, $message, $headers, '');
                        }

                        // echo json_encode(array('msge'=>'Success'));

                        wp_die();
                // }else{
                //
                // // echo json_encode(array('msge'=>'please login to continue'));
                // }



                }

                add_action( 'wp_ajax_nopriv_venu_ajax_coursetype', 'venu_ajax_coursetype' );
                add_action( 'wp_ajax_venu_ajax_coursetype', 'venu_ajax_coursetype' );

                //All first aid course

                function course_firstaid_shortcode($atts)
      {
  global $wpdb, $post;
    $postID = $post->ID;
  // May need $atts later
  if ( !empty( $atts ) )  {
    // use shortcode_atts() to set defaults then extract() to variables
    extract( shortcode_atts( array( 'id' => false ), $atts ) );
    $postID = $id;
  }
        $events = get_posts(
          array(
            'posts_per_page' => -1,
            'post_type' => 'product',
            'post__in' => array('111','137','107','140'),    
            'post_status' => 'publish',
            'orderby' => 'post__in'
          )
        );
        $course_firstaid_shortcode = '';
      //   $course_firstaid_shortcode .= '<select>';
      // foreach( $events as $course_post ) :
      
      // $course_firstaid_shortcode .= '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
      // endforeach;
      // $course_firstaid_shortcode .= '</select>';
      // echo $course_firstaid_shortcode;



      echo '<div class="elementor-column elementor-col elementor-top-column elementor-element">';
                    echo '<select name="courselist" class="courselist">';
                                    echo '<option value="">Choose Course</option>';
                                        foreach( $events as $course_post ) :
      
      $course_firstaid_shortcode .= '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
      endforeach;
 echo $course_firstaid_shortcode;
                    echo '</select></div>';
                    echo '</div>';

                      echo '<div class="elementor-row"><div id="loader"></div>';

                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                 echo '<select name="venu_id" class="venu_id"><option value="">Choose Location</option>';


                 echo '</select></div>';
                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element" style="padding: 10px;">';
                     echo '<select name="venudate" class="globalvenudate">';
                                     echo '<option value="">Choose Date</option>';

                     echo '</select></div>';


                    echo '</div>';
                    echo ' <div class="elementor-row">';
                    echo '<div class="elementor-column elementor-top-column elementor-element home_book_tables">';
                    echo ' <div class="home_book_table">';
                    echo '</div></div></div>';
      }


function course_paediatric_shortcode()
      {
        global $wpdb, $post;

        $events = get_posts(
          array(
            'posts_per_page' => -1,
            'post_type' => 'product',
            'post__in' => array('118','120'),    
            'post_status' => 'publish',
            'orderby' => 'post__in'
          )
        );

                   echo '<div class="elementor-column elementor-col elementor-top-column elementor-element">';
                    echo '<select name="courselist" class="courselist">';
                                    echo '<option value="">Choose Course</option>';
                                   foreach( $events as $course_post ) :
      
      $course_paediatric_shortcode .= '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
      endforeach;
 echo $course_paediatric_shortcode;

                    echo '</select></div>';
                    echo '</div>';

                      echo '<div class="elementor-row"><div id="loader"></div>';

                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                 echo '<select name="venu_id" class="venu_id"><option value="">Choose Location</option>';


                 echo '</select></div>';
                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element" style="padding: 10px;">';
                     echo '<select name="venudate" class="globalvenudate">';
                                     echo '<option value="">Choose Date</option>';

                     echo '</select></div>';


                    echo '</div>';
                    echo ' <div class="elementor-row">';
                    echo '<div class="elementor-column elementor-top-column elementor-element home_book_tables">';
                    echo ' <div class="home_book_table">';
                    echo '</div></div></div>';

                    
      }



      function course_mhfa_shortcode()
      {
        global $wpdb, $post;

        $events = get_posts(
          array(
            'posts_per_page' => -1,
            'post_type' => 'product',
            'post__in' => array('63125','70046','62620','63156'),    
            'post_status' => 'publish',
            'orderby' => 'post__in'
          )
        );

                   echo '<div class="elementor-column elementor-col elementor-top-column elementor-element">';
                    echo '<select name="courselist" class="courselist">';
                                    echo '<option value="">Choose Course</option>';
                                   foreach( $events as $course_post ) :
      
      $course_mhfa_shortcode .= '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
      endforeach;
 echo $course_mhfa_shortcode;

                    echo '</select></div>';
                    echo '</div>';

                      echo '<div class="elementor-row"><div id="loader"></div>';

                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                 echo '<select name="venu_id" class="venu_id"><option value="">Choose Location</option>';


                 echo '</select></div>';
                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element" style="padding: 10px;">';
                     echo '<select name="venudate" class="globalvenudate">';
                                     echo '<option value="">Choose Date</option>';

                     echo '</select></div>';


                    echo '</div>';
                    echo ' <div class="elementor-row">';
                    echo '<div class="elementor-column elementor-top-column elementor-element home_book_tables">';
                    echo ' <div class="home_book_table">';
                    echo '</div></div></div>';

                    
      }


       function course_fst_shortcode()
      {
        global $wpdb, $post;

        $events = get_posts(
          array(
            'posts_per_page' => -1,
            'post_type' => 'product',
            'post__in' => array('1635','71','39291'),    
            'post_status' => 'publish',
            'orderby' => 'post__in'
          )
        );

                   echo '<div class="elementor-column elementor-col elementor-top-column elementor-element">';
                    echo '<select name="courselist" class="courselist">';
                                    echo '<option value="">Choose Course</option>';
                                   foreach( $events as $course_post ) :
      
      $course_fst_shortcode .= '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
      endforeach;
         echo $course_fst_shortcode;

                    echo '</select></div>';
                    echo '</div>';

                      echo '<div class="elementor-row"><div id="loader"></div>';

                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element">';
                 echo '<select name="venu_id" class="venu_id"><option value="">Choose Location</option>';


                 echo '</select></div>';
                    echo '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element" style="padding: 10px;">';
                     echo '<select name="venudate" class="globalvenudate">';
                                     echo '<option value="">Choose Date</option>';

                     echo '</select></div>';


                    echo '</div>';
                    echo ' <div class="elementor-row">';
                    echo '<div class="elementor-column elementor-top-column elementor-element home_book_tables">';
                    echo ' <div class="home_book_table">';
                    echo '</div></div></div>';

                    
      }

require_once dirname( __FILE__)."/course-selector.php" ;

