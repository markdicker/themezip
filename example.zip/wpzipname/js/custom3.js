jQuery(document).ready(function($) {
	var site_home_url = home_url_object.home_url; // alerts 'Some string to translate'
	var ajax_file_url_value = ajax_file_url_object.ajax_file_url; // alerts 'Some string to translate'
	
/*course filter by date start*/
$(document).on('change', '#course-sort-date', function() {
var selected_value = $(this).val();
var preferred_venue_value = $('#get_preferred_venues').val();
var get_trainer_id = $('#get_trainer_id_ajax').val();
$.post(ajax_file_url_value+"/ajax.php", { 
			 a_selected_value: selected_value, 
			 a_preferred_venue_value: preferred_venue_value,
			 a_get_trainer_id: get_trainer_id,
			 action: 'course-filter-by-date'},function(data) {
				 var trimmed_value = jQuery.trim(data);
				 jQuery(".available_table tbody").html(trimmed_value);
				 	});
});
/*course filter by date end*/

});