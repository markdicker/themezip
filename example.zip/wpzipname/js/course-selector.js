jQuery( 'document').ready( function( $ ) 
{
    $('body').prepend( "<div id='loading' class='loader'><div id='spinner'></div></div>");

    $('body').on('click', '.show-button', function(e) {
        e.preventDefault();

        let key = $(this).data('key');

        $('.hidden-'+key ).css('display', 'table-row' );

        $('.show-'+key ).css('display', 'none' );

        $('.hide-'+key ).css('display', 'table-row' );


    }); 

    $('body').on('click', '.hide-button', function(e) {
        e.preventDefault();

        let key = $(this).data('key');

        $('.hidden-'+key ).css('display', 'none' );

        $('.show-'+key ).css('display', 'table-row' );

        $('.hide-'+key ).css('display', 'none' );

    }); 


    $( "#longdate" ).dateRangePicker( 
        {
            autoClose: true,
            format: 'DD/MM/YYYY',
            startDate: moment().format('DD/MM/YYYY'),
        }
    ).bind('datepicker-first-date-selected', function(event, obj)
        {
            /* This event will be triggered when first date is selected */
            
            var sDate = moment(obj.date1).format("YYYY-MM-DD");
            
            $("#sdate").val( sDate);

            fields_entered |= DATE_BIT;

        }
    ).bind('datepicker-change',function(event,obj)
        {
            /* This event will be triggered when second date is selected */

            var sDate = moment(obj.date1).format("YYYY-MM-DD");
            
            var eDate = moment(obj.date2).format("YYYY-MM-DD");

            $("#sdate").val( sDate);
            $("#edate").val( eDate);

            fields_entered |= DATE_BIT;

        }
    ).bind('datepicker-close',function()
        {
            /* This event will be triggered before date range picker close animation */

            if ( fields_entered == CAN_SEARCH )
                do_search();
            else    
                error_messages();

       }
    );

    $('#date-range-calendar').click(function(evt)
    {
        evt.stopPropagation();
        $('#longdate').data('dateRangePicker').open();
    });

    $( '#cs_submit').click( function ( e ) 
    {
        e.preventDefault();
        
        if ( fields_entered == CAN_SEARCH )
            do_search();
        else    
            error_messages();

        return false;
    });

    function error_messages( )
    {
        var message = "";

        if ( (fields_entered & CATEGORY_BIT) != CATEGORY_BIT )
            message = message + "Course Category, ";

        if ( (fields_entered & COURSE_BIT) != COURSE_BIT )
            message = message + "Course, ";

        if ( (fields_entered & AREA_BIT) != AREA_BIT )
            message = message + "Area, ";

        if ( (fields_entered & DATE_BIT) != DATE_BIT )
            message = message + "Date Range.  ";

        if ( message != "" )
        {
            message = "The following fields need correcting :- " + message;
        }

        jQuery( '#cf_error' ).html( message );

    }

    function do_search( )
    {
        var location = $( '#cs_location' ).val();
        var course = $( '#cs_id' ).val();
        var sDate = $( '#sdate' ).val();
        var eDate = $( '#edate' ).val();
        
        $.ajax({
            url : course_ajax_object.ajax_url,
            type : 'post',
            data : {
                action : 'siren_courses_by_location',
                location : location,
                courses : course,
                sdate : sDate,
                edate : eDate,
            },
            beforeSend: function(){
                $( "#loading" ).show();
                $( '#cf_error' ).html( '' );
            },
            complete: function(){
                $( "#loading" ).hide();
            },
            success : function( response ) {
                var JSONArray = $.parseJSON(response);

                // console.log( JSONArray );

                let text = '';

                for (let i = 0; i < JSONArray.length; i++) 
                {
                    text += JSONArray[i];
                }

                // console.log( text );

                $('.home_book_table').html(text);

                // $('.book_table').html(text);
            }
        });

        return false;
    }

    //$('body').on('change', '.cs_location', function(e) 
    $('.cs_location').change(  function(e) 
    {
        e.preventDefault();

        var location = $('#cs_location').val();

        if ( location == "" )
        {
            // console.log( "Before", fields_entered );

            fields_entered &= ~AREA_BIT;

            // console.log( "After", fields_entered );

            return false;
        }

        fields_entered |= AREA_BIT;

        // console.log( "location", location );
        if ( fields_entered == CAN_SEARCH )
            do_search();
        // else    
        //     error_messages();


    } );

    $('.cs_id').change( function(e) 
    {
        e.preventDefault();

        fields_entered |= COURSE_BIT;

        // console.log( "location", location );
        if ( fields_entered == CAN_SEARCH )
            do_search();
        else    
            error_messages();



    } );

    $('body').on('change', '.cs_category', function(e) 
    {
        e.preventDefault();

        var location = $('#cs_location').val();

        var category = $(this).val();

        if ( category == "" )
        {
            // console.log( "Before", fields_entered );

            fields_entered &= ~CATEGORY_BIT;

            // console.log( "After", fields_entered );

            let text = '<option value="">Choose Course</option>';

            $('select[name="cs_id"]').html( text );

            return false;
        }

        var courses = $( this ).find(':selected').data( 'courses' );

        $.ajax({
            url : course_ajax_object.ajax_url,
            type : 'post',
            data : {
                action : 'siren_course_names_by_ids',
                courses : courses
            },
            beforeSend: function(){
                jQuery("#loading").show();
                $( '#cf_error' ).html( '' );
            },
            complete: function(){
                fields_entered |= CATEGORY_BIT | COURSE_BIT;

                if ( fields_entered == CAN_SEARCH )
                    do_search();
                else
                    jQuery("#loading").hide();

            },
            success : function( response ) {
                var JSONArray = $.parseJSON(response);

                let text = ''; //'<option value="">Choose Course</option>';

                for (let i = 0; i < JSONArray.length; i++) 
                {
                    text += JSONArray[i];
                }

                $('select[name="cs_id"]').html(text);
                // $('.book_table').html(text);

    
            }
        });
    });
});
