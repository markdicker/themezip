jQuery(document).ready(function($) {
  $("div.places:not(.buttons_added), td.places:not(.buttons_added)")
    .addClass("buttons_added")
    .append('<input type="button" value="+" id="add99" class="plus" />')
    .prepend('<input type="button" value="-" id="minus99" class="minus" />'),
    $(".buttons_added #minus99").click(function(e) {
      var value =
        parseInt(
          $(this)
            .next()
            .val()
        ) - 1;
      value >= 0 &&
        ($(this)
          .next()
          .val(value),
        $('.woocommerce-cart table.cart input[name="update_cart"]').prop(
          "disabled",
          !1
        ));
    }),
    $(".buttons_added #add99").click(function(e) {
      var value =
          parseInt(
            $(this)
              .prev()
              .val()
          ) + 1,
        max = parseInt(
          $(this)
            .prev()
            .attr("max")
        );
      value <= max &&
        ($(this)
          .prev()
          .val(value),
        $('.woocommerce-cart table.cart input[name="update_cart"]').prop(
          "disabled",
          !1
        ),
        $("table.attendees").append(
          '<tr><td><input type="text" value="" style="width:100%;" /></td><td><input type="text" value="" style="width:100%;" /></td><td><input type="text" value="" style="width:100%;" /></td></tr>'
        ));
    });
    
    /**
     * Replacement Tutor ajax login
     *
     * @since v.1.6.3
     */
    $(document).on('submit', '.siren-login-form-wrap #loginform', function (e) {
        e.preventDefault();
        
        var $that = $(this);
        var $form_wrapper = $('.siren-login-form-wrap');
        var form_data = $that.serialize() + '&action=siren_user_login';
        
        // console.log( "ajax_url", _tutorobject.ajaxurl );
        // console.log( "form_data", form_data );
        
    
        $.ajax({
            url: _tutorobject.ajaxurl,
            type: 'POST',
            data: form_data,
            success: function (response) {
                // console.log( response );
                // console.log( response.success );
    
                if (response.success) {
                    location.assign(response.data.redirect);
                    location.reload();
                } else {
                    if ($form_wrapper.find('.tutor-alert').length) {
                        $form_wrapper.find('.tutor-alert').html(response.data);
                    } else {
                        $form_wrapper.prepend('<div class="tutor-alert tutor-alert-warning">' + response.data + '</div>');
                    }
                }
            },
        });
    });
});


