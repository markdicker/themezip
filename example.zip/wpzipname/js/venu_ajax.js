jQuery.noConflict();
(function( $ ) {
  $(function() {
    // More code using $ as alias to jQuery


    // $(document).ready( function(){
        //  $("#loading").hide();

    $('body').on('change', '.venuname', function(e) {
        e.preventDefault();

        var venu_id = $(this).val();
        // var post_id = $('.venuname').attr('data-postid');
          var post_id = $(this).find(':selected').data('postid')

        $.ajax({
            url : venu_ajax_object.ajax_url,
            type : 'post',
            data : {
                action : 'venu_ajax_date',
                venu_id : venu_id,
                post_id : post_id
            },beforeSend: function(){
     $("#loading").show();
   },
   complete: function(){
     $("#loading").hide();
   },
            success : function( response ) {
                var JSONArray = $.parseJSON(response);


                let text = '';

                for (let i = 0; i < JSONArray.length; i++) {
                  text += JSONArray[i];
                }

              // $('select[name="venudate"]').html(text);
              $('.book_table').html(text);

            }
        });
    });


   //      $('body').on('change', '.venudate', function(e) {
   //      e.preventDefault();
   //
   //      var venu_date = $(this).val();
   //      var venu_name = $('.venuname').val();
   //      var post_id = $(this).find(':selected').data('postid')
   //
   //      $.ajax({
   //          url : venu_ajax_object.ajax_url,
   //          type : 'post',
   //          data : {
   //              action : 'venu_ajax_name_date',
   //              venu_date : venu_date,
   //              venu_name : venu_name,
   //              post_id : post_id
   //          },beforeSend: function(){
   //   $("#loading").show();
   // },
   // complete: function(){
   //   $("#loading").hide();
   // },
   //          success : function( response ) {
   //              var JSONArray = $.parseJSON(response);
   //
   //
   //              let text = '';
   //
   //              for (let i = 0; i < JSONArray.length; i++) {
   //                text += JSONArray[i];
   //              }
   //
   //            $('.book_table').html(text);
   //          }
   //      });
   //  });


// home filters

// $('body').on('change', '.training_location', function(e) {
//     e.preventDefault();
//     // var post_id = $(this).val();
//     var location = $(this).val();

//     console.log( "Location", location );

//     $.ajax({
//         url : venu_ajax_object.ajax_url,
//         type : 'post',
//         data : {
//             action : 'global_course_list_location',
//             location : location
//         },
//         success : function( response ) {
//             var JSONArray = $.parseJSON(response);
//             // console.log(JSONArray);


//             let text = '<option value="">Choose Category</option>';

//             for (let i = 0; i < JSONArray.length; i++) {
//               text += JSONArray[i];
//             }

//           $('select[name="courselist"]').html(text);
//         }
//     });
// });


$('body').on('change', '.courselist', function(e) {
    e.preventDefault();

    var post_id = $(this).val();

    $.ajax({
        url : venu_ajax_object.ajax_url,
        type : 'post',
        data : {
            action : 'global_course_list_venu_name',
            post_id : post_id,
        },success : function( response ) {
            var JSONArray = $.parseJSON(response);


            let text = '<option value="">Choose Location</option>';

            for (let i = 0; i < JSONArray.length; i++) {
              text += JSONArray[i];
            }

            $('select[name="venu_id"]').html(text);
        }
    });
  });


  $('body').on('change', '.venu_id', function(e) {
  e.preventDefault();

  var post_id = $('.courselist').val();
  var venu_name = $('.venu_id').val();

  console.log( "venue", venu_name );

  $.ajax({
      url : venu_ajax_object.ajax_url,
      type : 'post',
      data : {
          action : 'global_venu_ajax_name_date',
          post_id   : post_id,
          venue_name : venu_name
      },success : function( response ) {
        console.log( "response", response );

        var JSONArray = $.parseJSON(response);

        // let text = '<option value="">Select Venue Date</option>';
        let text = '';

        for (let i = 0; i < JSONArray.length; i++) {
          text += JSONArray[i];
        }

        console.log( "text", text );
        $('.home_book_table').html(text);

        //   var JSONArray = $.parseJSON(response);


        //   let text = '<option value="">Choose Date</option>';

        //   for (let i = 0; i < JSONArray.length; i++) {
        //     text += JSONArray[i];
        //   }

        //   $('select[name="venudate"]').html(text);
      }
  });
});


$('body').on('change', '.globalvenudate', function(e) {
e.preventDefault();

var venu_date = $(this).val();
var venu_name = $('.venu_id').val();
var post_id = $('.courselist').val();

$.ajax({
    url : venu_ajax_object.ajax_url,
    type : 'post',
    data : {
        action : 'global_venu_ajax_name_date',
        venu_date : venu_date,
        venu_name : venu_name,
        post_id : post_id
    },beforeSend: function(){
$("#loading").show();
},
complete: function(){
$("#loading").hide();
},
    success : function( response ) {
        var JSONArray = $.parseJSON(response);


        // let text = '<option value="">Select Venue Date</option>';
        let text = '';

        for (let i = 0; i < JSONArray.length; i++) {
          text += JSONArray[i];
        }

      $('.home_book_table').html(text);
    }
});
});


$('body').on('change', '.bookervenudate', function(e) {
e.preventDefault();

var venu_date = $(this).val();
var venu_name = $('.venu_id').val();
var post_id = $('.courselist').val();

$.ajax({
    url : venu_ajax_object.ajax_url,
    type : 'post',
    data : {
        action : 'booker_venu_ajax_name_date',
        venu_date : venu_date,
        venu_name : venu_name,
        post_id : post_id
    },beforeSend: function(){
$("#loading").show();
},
complete: function(){
$("#loading").hide();
},
    success : function( response ) {
        var JSONArray = $.parseJSON(response);


        // let text = '<option value="">Select Venue Date</option>';
        let text = '';

        for (let i = 0; i < JSONArray.length; i++) {
          text += JSONArray[i];
        }

      $('.home_book_table').html(text);

      var post_id = $('.courselist').val();

      var dataseatremaining = $('.tdseatremaining').attr('data-seatremaining');
      var c = parseInt(dataseatremaining) - 1;

      $('.seats').val(c);

      // alert(dataseatremaining);
      // var venuArr = '';
      // for(i = 0; i < dataseatremaining; i++) {
      //   venuArr += '<div class="dataseatremaining"><span>seat '+(i+1)+'</span><input name="fname[]" type="text" class="col3" placeholder="First Name" value="" /><input name="sname[]" type="text" class="col3" placeholder="Surname" value="" /><input name="pemail[]" placeholder="Personal E-mail" type="text" class="col3" value="" /><input placeholder="Personal Phone" name="phone[]" type="text" class="col3" value="" /><input placeholder="Contact E-mail" name="cemail[]" type="text" class="col3" value="" /><input placeholder="Price Paid" name="price[]" type="text" class="col3" value="" /></div>';
      // }
      // console.log(venuArr);
      // $('.searemaining').html(venuArr);

    }
});
});

$('body').on('click', '.addseat', function(e) {
  var dataseatremaining = $('.seats').val();
  var i = parseInt(dataseatremaining) + 1;
  $('.seatcnt').val(i);
  var venuArr = '';
  if(dataseatremaining > 0){
    venuArr = '<div class="dataseatremaining"><input name="fname'+i+'" type="text" required class="col3 fname" placeholder="First Name" value="" /><input name="sname'+i+'" type="text" required class="col3 sname" placeholder="Surname" value="" /><input name="pemail'+i+'" placeholder="Personal E-mail" type="text" required class="col3 pemail" value="" /><input placeholder="Personal Phone" name="phone'+i+'" type="text" required class="col3 phone" value="" /><input placeholder="Contact E-mail" name="cemail'+i+'" type="text" required class="col3 cemail" value="" /><input placeholder="Price Paid" name="price'+i+'" type="text" required class="col3 price" value="" /></div>';
    var c = parseInt(dataseatremaining) - 1;
    $('.seats').val(c);
  }else{
    alert('All Seats Booked');
  }
  // console.log(venuArr);
  $('.searemaining').append(venuArr);
});


// $('body').on('click', '.addsubmitseat', function(e) {
//   var fname = $('.fname').val();
//   var sname = $('.sname').val();
//   var pemail = $('.pemail').val();
//   var phone = $('.phone').val();
//   var cemail = $('.cemail').val();
//   var price = $('.price').val();
//   var yes;
//   if(fname && sname && pemail && phone && cemail && price){
//     yes = 1;
//
//   }else{
//     yes = 0;
//   }

// $('body').on('click', '#submit', function(e) {
//   // $('#addsubmitseat').on('click', function(event){
//
//     alert();
//
//       var data = $(this).serialize();
//       $.ajax({
//           url : venu_ajax_object.ajax_url,
//           type : 'post',
//           data : {
//               action : 'booker_api_post_save_learner',
//               data : data,
//
//           },
//           success: function(response) {
//             console.log(response);
//               // $("#msg").html(response);
//           }
//       });
//       return false;
//
// });
$('body').on('click', '#send_form', function(e) {

        // $("#send_form").click(function(e){
            e.preventDefault();
              // var fname = $(input[name="fname[]"]).val();
              const fname = [];
              const sname = [];
              const pemail = [];
              const phone = [];
              const cemail = [];
              const price = [];



              var seatcnt =  $('.seatcnt').val();
              var courseid =  $('.courseid').val();

for(i=1;i<=seatcnt;i++){
  fname.push($('input[name="fname'+i+'"]').val());
  sname.push($('input[name="sname'+i+'"]').val());
  pemail.push($('input[name="pemail'+i+'"]').val());
  phone.push($('input[name="phone'+i+'"]').val());
  cemail.push($('input[name="cemail'+i+'"]').val());
  price.push($('input[name="price'+i+'"]').val());
}

// alert(fname);

      $.ajax({
          url : venu_ajax_object.ajax_url,
          type : 'post',
          data : {
              action : 'booker_api_post_save_learner',
              fname : fname,
              sname : sname,
              pemail : pemail,
              phone : phone,
              cemail : cemail,
              price : price,
              courseid : courseid,
              seatcnt : seatcnt,

          },
          success: function(response) {
            // console.log(response);
            window.location.href = "https://www.sirentraining.co.uk/dev/dashboard/company-learners/";
            // location.href = "https://www.sirentraining.co.uk/dev/dashboard/company-learners/";

              // $("#msg").html(response);
          }
      });



        });


        $('body').on('change', '.course_type', function(e) {
            e.preventDefault();
            $('.home_book_table').html("");

            var course_type_name = $(this).val();
            // var post_id = $('.venuname').attr('data-postid');
            var course_type_postid = $(this).find(':selected').data('postid');

            if(course_type_name == 'inhouse'){
              var coursedatas;
              $('.venu_id').hide();
              $('.bookervenudate').hide();
              $('.home_book_table').hide();
              $('.coursevenudate').show();
              $('.inhousevenudate').show();
              $('.inhousevenudatediv').show();
              var coursedatas = '<div class="addattendee"><h2>Add Attendee <button class="addseat">Add Seat</button></h2><form id="addsubmitseat" method="post" action="javascript:void(0)"><input type="hidden" class="courseid" name="courseid" value="'+course_type_postid+'" /><input type="hidden" class="seats" name="seats" value="12" /><input type="hidden" class="seatcnt" name="seatcnt" value="1" /><div class="searemaining"><div class="dataseatremaining"><input name="fname1" type="text" required class="col3 fname" placeholder="First Name" value="" /><input name="sname1" type="text" required class="col3 sname" placeholder="Surname" value="" /><input name="pemail1" placeholder="Personal E-mail" type="text" required class="col3 pemail" value="" /><input placeholder="Personal Phone" name="phone1" type="text" required class="col3 phone" value="" /><input placeholder="Contact E-mail" name="cemail1" type="text" required class="col3 cemail" value="" /><input placeholder="Price Paid" name="price1" type="text" required class="col3 price" value="" /></div></div><button type="submit" id="send_form_inhouse" class="btn btn-block btn-success">Submit</button></form></div>';
              $('.coursevenudate').html(coursedatas);
              // var coursedatas1 = '<div class="elementor-column elementor-col-50 elementor-top-column elementor-element" style="padding: 10px;"></div><div class="elementor-column elementor-col-50 elementor-top-column elementor-element" style="padding: 10px;"><input class="inhousesubmit" style="border-radius: 20px;" type="button" name="submit" value="submit"></div>';
              // $('.coursevenudate1').html(coursedatas1);
              // $('.book_table').html("");
              return false;
            }

            if(course_type_name == 'external'){

              $('.venu_id').show();
              $('.bookervenudate').show();
              $('.home_book_table').show();
              $('.coursevenudate').hide();
              $('.inhousevenudate').hide();
              $('.inhousevenudatediv').hide();

              return false;
            }

        });


        $('body').on('click', '.inhousesubmit', function(e) {
            e.preventDefault();

            var inhouse_date = $('.inhousevenudate').val();
            // alert(inhouse_date);
            // var post_id = $('.venuname').attr('data-postid');
            var postid = $('.courselist').val();
// alert(postid);
              $.ajax({
                  url : venu_ajax_object.ajax_url,
                  type : 'post',
                  data : {
                      action          : 'venu_ajax_coursetype',
                      inhouse_date    : inhouse_date,
                      postid          : postid
                  },
                  success : function( response ) {
                    // alert();
                    location.reload();

                  }
              });



        });



        $('body').on('click', '#testimonial_img', function(e) {

                // $("#send_form").click(function(e){
                    e.preventDefault();
                      // var fname = $(input[name="fname[]"]).val();
                      const fname = [];
                      const sname = [];
                      const pemail = [];
                      const phone = [];
                      const cemail = [];
                      const price = [];



                      var seatcnt =  $('.seatcnt').val();
                      var courseid =  $('.courselist').val();
                      var inhouse_date =  $('.inhouse_date').val();

        for(i=1;i<=seatcnt;i++){
          fname.push($('input[name="fname'+i+'"]').val());
          sname.push($('input[name="sname'+i+'"]').val());
          pemail.push($('input[name="pemail'+i+'"]').val());
          phone.push($('input[name="phone'+i+'"]').val());
          cemail.push($('input[name="cemail'+i+'"]').val());
          price.push($('input[name="price'+i+'"]').val());
        }

        // alert(fname);

              $.ajax({
                  url : venu_ajax_object.ajax_url,
                  type : 'post',
                  data : {
                      action : 'venu_ajax_coursetype',
                      fname : fname,
                      sname : sname,
                      pemail : pemail,
                      phone : phone,
                      cemail : cemail,
                      price : price,
                      courseid : courseid,
                      seatcnt : seatcnt,
                      inhouse_date : inhouse_date,

                  },
                  success: function(response) {
                    // alert();
                    // var JSONArray = $.parseJSON(response);
                    // console.log(JSONArray);
                    location.reload();
                    // window.location.href = "https://www.sirentraining.co.uk/dev/dashboard/company-learners/";
                    // location.href = "https://www.sirentraining.co.uk/dev/dashboard/company-learners/";

                      // $("#msg").html(response);
                  }
              });




                });



// });
  });
})(jQuery);
