
var sortBy = 'date';
var order = 'desc';

var search = "";

jQuery(document).ready(function($) {

    // console.log( "Company Learners event handlers loaded" );

    $('.fa-sort, .fa-sort-desc, .fa-sort-asc').click( function( e ) {

        // $('#overlay').fadeIn();

        var column = $(this).data( "column" );

        var id = $(this).attr('id');

        // console.log( column, id );

        if ( column != sortBy )
        {
            $( "#"+sortBy ).removeClass( 'fa-sort-desc' );
            $( "#"+sortBy ).removeClass( 'fa-sort-asc' );
            $( "#"+sortBy ).addClass( 'fa-sort' );

            // console.log( sortBy, order );

            sortBy = column;
            order = 'desc';
            
            // $( this ).addClass( '.fa-sort' );
            $( "#"+column ).removeClass( 'fa-sort' );
            
            $( "#"+column ).removeClass( 'fa-sort-desc' );
            
            $( "#"+column ).removeClass( 'fa-sort-asc' );

            $( "#"+column ).addClass( 'fa-sort-'+order );

            // console.log( sortBy, order );

        }
        else
        {

            if ( order == 'asc' )
                order = 'desc';
            else
                order = 'asc';

            $( "#"+sortBy ).removeClass( 'fa-sort-desc, fa-sort-asc' );
            

            if ( order == 'asc' )
                $( "#"+sortBy ).addClass( 'fa-sort-desc' );
            else
                $( "#"+sortBy ).addClass( 'fa-sort-asc' );
        }

        get_page_of_learners( learners_context, curPage, sortBy, order, search );

        // console.table( e );
        // console.log( column );

        // console.log( learners_context );

        // $('#overlay').fadeOut();

    });

    $( ".fa-arrow-left, .fa-arrow-right" ).click( function( e ) {

        
        if ( $(this).hasClass( 'disabled-option' ) )
        {
            return ;
        }


        var dir = $(this).data( "dir" );

        // var curPage = $(this).data( "curPage" );
        // var lastPage = $(this).data( "lastPage" );

        // console.log( learners_context );

        if ( dir == 'forward' ) 
        {
            if ( curPage < lastPage )
            {
                curPage++;
    
                // console.log( curPage );
    
                get_page_of_learners( learners_context, curPage, sortBy, order, search );

            }
        }
        else
        {
            if ( curPage > 1 )
            {
                curPage--;
    
                // console.log( curPage );
    
                get_page_of_learners( learners_context, curPage, sortBy, order, search );

            }
        }
        
        
    });

    $('#search-box').keyup( function( e ) {

        // Number 13 is the "Enter" key on the keyboard
        if (e.keyCode === 13) {
            // Cancel the default action, if needed
            e.preventDefault();
            // Trigger the button element with a click
            $('#search-action').click();
        }

    });

    $('#search-action').click( function( e ) {

        search = $('#search-box').val();

        // console.log( 'searching for '+search );

        get_page_of_learners( learners_context, curPage, sortBy, order, search );

    });

});


function get_page_of_learners( _context, _page, _sort, _order, _search = undefined )
{

    var data = {
        'action': 'page_of_learners',
        'context': _context,
        'page': _page,
        'sortBy': _sort,
        'order': _order,
        'search': _search,
    };

    // console.table( "About to get data", data );

    jQuery('#overlay').fadeIn();
        
    jQuery.post( _tutorobject.ajaxurl,  data, function(response) 
    {

        // console.log('Got this from the server: ',response);
        // console.log ( response.data );
        
        var data = response.data.data;

        var content = '';
        for (var i = 0; i < data.length; i++) {
            content += '<tr id="' + data[i].id + '">';
            
                content += '<td>' + data[i].name + '</td>';
                content += '<td>' + data[i].course + '</td>';
                content += '<td>' + data[i].fdate + '</td>';

                content += '<td>';
                if ( data[i].certificate )
                    content += '<a href="'+'site_url'+'/pdf-generator/certificate/"' + data[i].id + '<a>Download</a>';
                
                content += '</td>';

            content += '</tr>';
        }

        // console.log( content );

        // if ( curPage > response.data.page )
            curPage = response.data.page;
        
        // if ( lastPage > response.data.page_count )
            lastPage = response.data.page_count;

        jQuery( '.learners tbody' ).html( content );

        jQuery( '.current' ).html( ''+curPage );

        jQuery( '.last-page' ).html( ''+lastPage );

        if ( curPage > 1 )
        {
            jQuery('tfoot').find( '.fa-arrow-left' ).removeClass( 'disabled-option' );
        }
        else
        {
            jQuery('tfoot').find( '.fa-arrow-left' ).addClass( 'disabled-option' );
        }

        if ( curPage >= lastPage )
        {
            jQuery('tfoot').find( '.fa-arrow-right' ).addClass( 'disabled-option' );
        }
        else
        {
            jQuery('tfoot').find( '.fa-arrow-right' ).removeClass( 'disabled-option' );
        }

        jQuery('#overlay').fadeOut();
    });

}
