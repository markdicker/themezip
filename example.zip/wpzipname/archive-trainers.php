<?php 

$layout = 'full';

get_header();

?>
    <div id="body">
    	<div class="container">
        	<div class="content-pad-3x">
                <div class="row">
                    <div id="content" class="<?php echo $layout!='full'?'col-md-9':'col-md-12' ?><?php echo ($layout == 'left') ? " revert-layout":"";?>">
                        <div class="blog-listing">
                            <h2>Trainer Login</h2>
                            <br />
                            <?php 
                                wp_login_form( array( 'redirect' => site_url( '/trainers/' ) ) );
                            ?>
                        </div>
                    </div><!--/content-->
                </div><!--/row-->
            </div><!--/content-pad-->
        </div><!--/container-->
    </div><!--/body-->
<?php get_footer(); ?>