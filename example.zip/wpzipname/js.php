<?php

?>
<script>
    var SIREN_PLUGIN_URL = '<?php echo SIREN_PLUGIN_URL; ?>';

    var COLOURS = [];
    <?php 
        global $palette;

        $sep =";\n";

        foreach ( $palette as $colour )
        {
            echo "COLOURS.push ( { name : '".$colour['name']."', colour : '".$colour['colour']."'} )".$sep;
        }

    ?>
</script>
