<?php

// print_r( $_POST );
// print_r( $_GET );

$_eo = get_option( '_elementor_general_settings' );

if( isset( $_eo[ 'container_width' ] ))
    $max_width = $_eo[ 'container_width' ];
else
    $max_width = 1140;


$course_id = get_query_var( 'course_id' ); 

$learner_id = get_query_var( 'learner_id' ); 


// echo $course_id.PHP_EOL;
// echo $learner_id.PHP_EOL;

$calendar_data = get_post_meta( $course_id, '_calendar_data', true );

if ( !is_array( $calendar_data ) )
    exit( 500 );

$learner_data = get_post_meta( $learner_id, '_learner_details', true );
    
if ( !is_array( $learner_data ) )
    exit( 500 );

$venue_meta = get_post_meta( $learner_id, '_venues_meta', true );
    
if ( !is_array( $learner_data ) )
    exit( 500 );


$assigned_venue = get_page_by_path( $calendar_data['venue']['key'], OBJECT, 'venues' );

if ( $assigned_venue != null )
{
    $location = $assigned_venue->post_title;
}
else
{
    $location = $calendar_data['venue']['name'];
}


$assigned_product = get_page_by_path( $calendar_data['product']['key'], OBJECT, 'products' );

if ( $assigned_product != null )
{
    $course_name = $assigned_product->post_title;
}
else
{
    $course_name = $calendar_data['product']['name'];
}


if ( isset( $_POST['feedback_tag'] ) && wp_verify_nonce( $_POST['feedback_tag'], "feedback-".$course_id."-".$learner_id )  )
{
    // Save the data

    //echo "<pre>".print_r( $_POST, true )."</pre>";

    $feedback = array(
        'post_title'=> "feedback-".$course_id."-".$learner_id,
        'post_name' => "feedback-".$course_id."-".$learner_id,
        'post_status' => 'publish',
        'post_type' => 'feedback',//set post type to product_variation
        'guid'=> ''
    );

    // 
    $feedback_id = wp_insert_post( $feedback );

    update_post_meta( $feedback_id, "_feedback_data", $_POST );

    update_post_meta( $feedback_id, "_course", $course_id );
    update_post_meta( $feedback_id, "_learner", $learner_id );

    update_post_meta( $course_id, "_feedback", $feedback_id );
    update_post_meta( $learner_id, "_feedback", $feedback_id );

    wp_redirect( site_url( "/pdf-generator/certificate/".$learner_id ), 302 );
}

// check if feed back already left

// if feedback already left then go to certificate

$feedback = get_page_by_path( "feedback-".$course_id."-".$learner_id, OBJECT, "feedback" );



if ( $feedback != null )
{
    // wp_redirect( site_url( "/pdf-generator/certificate/".$learner_id ), 302 );
}

wp_enqueue_style( 'survey-css', get_stylesheet_directory_uri().'/css/survey.min.css', false, '1.5.10', true );

wp_enqueue_script( 'survey-js', get_stylesheet_directory_uri().'/js/survey.jquery.min.js', false, '1.5.10', true );

wp_enqueue_script( 'feedback-js', get_stylesheet_directory_uri().'/feedback-questions.php', false, '0.1.15', true );

get_header();

?>
    <div id="body">
    	<div class="container" style="max-width: <?php echo $max_width; ?>px; margin:0 auto;" >
        	<div class="content-pad-3x">
                <div class="row">
                    <div id="content" class="<?php echo $layout!='full'?'col-md-9':'col-md-12' ?><?php echo ($layout == 'left') ? " revert-layout":"";?>">

                        <h2>Please provide feedback on your recent experience on the following course</h2>

                        <form method="post" >
                        <?php

                            wp_nonce_field( "feedback-".$course_id."-".$learner_id, "feedback_tag" );

                            $calendar_data = get_post_meta( $course_id, '_calendar_data', true );
                    
                            $course_syllabus = get_page_by_path( $calendar_data['syllabus']['key'], OBJECT, 'course_syllabus' );

                            $assigned_venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

                            if ($assigned_venue != null) {
                                $location = $assigned_venue->post_title;
                            } else {
                                $location = $calendar_data['venue']['name'];
                            }


                            $course = get_page_by_path($calendar_data['product']['key'], OBJECT,
                            'product');
                    
                        
                            if (null != $course) 
                                $course_name = $course->post_title;
                            else 
                                $course_name = $calendar_data['product']['name'];

                        ?>
                        <input name="_course" type="hidden" value="<?php echo $course_id; ?>" />
                        <input name="_learner" type="hidden" value="<?php echo $learner_id; ?>" />

                        <br />
                        <h2>Course : <?php echo $course_name; ?></h2>
                        <h2>Location : <?php echo $location; ?></h2>
                        <h2>Date : <?php echo dateRange(strtotime($calendar_data['start_date_time']),
                                    strtotime($calendar_data['end_date_time'])); ?></h2>
                        <br />

                        <div class="feedback-form">
                        <?php

                            $default_feedback_qs = 'feedback_questions	[
                                {
                                "type": "rating",
                                "name": "_course_rating",
                                "title": "How did you find the course",
                                "isRequired": true,
                                "rateMax": 9
                                },
                                {
                                "type": "rating",
                                "name": "_trainer_rating",
                                "title": "How did you find the course instructor",
                                "isRequired": true,
                                "rateMax": 9
                                },
                                {
                                "type": "rating",
                                "name": "_venue_rating",
                                "title": "Please rate the choice of course venue",
                                "isRequired": true,
                                "rateMin":1,
                                "rateMax": 9
                                },
                                {
                                "type": "rating",
                                "name": "_hygiene_rating",
                                "title": "Please rate the cleanliness of the quipment",
                                "isRequired": true,
                                "rateMin":1,
                                "rateMax": 9
                                },
                                {
                                "type": "comment",
                                "name": "_comments",
                                "title": "Please use this space to tell us where we could improve or if there was anything that we did well."
                                }';

                            $feedback_questions = json_decode( stripslashes( get_option( 'feedback_questions', $default_feedback_qs )), true );

                            // echo "<pre>".print_r( $feedback_questions, true )."</pre>";
                            $feedback_form = new Feedback( $feedback_questions );

                            $feedback_form->render();
                        ?>
                        </div>
                        <br />
                        <p><input type="submit" value="Submit Feedback" /></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
get_footer();

