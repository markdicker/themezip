<?php

// remove async_javascript filter if already set
if ( isset( $ajFrontend ) )
    remove_filter( 'script_loader_tag', array( $ajFrontend, 'aj_async_js') , 20, 3 );
else
{
    // Do it the hard way if we must
    
    add_filter( 'script_loader_tag', function( $tag, $handle, $src ) {
    
      return str_replace( "async='async'", "", str_replace( "async='defer'", "", $tag ) );

    }, 99, 3 );
}

wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() . '/css/bootstrap.min.css' );
wp_enqueue_style( 'custom-styles', get_stylesheet_directory_uri() . '/css/main.css' );
wp_enqueue_style( 'trainer-styles', get_stylesheet_directory_uri(). '/css/trainer.css', array('bootstrap', 'font-awesome') );
	

wp_enqueue_script( 'jquery');
wp_enqueue_script( 'bootstrap', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', array(), '', true );
wp_enqueue_script( 'main-js', get_stylesheet_directory_uri() . '/js/main.js', array( 'jquery', 'bootstrap' ) );


if (isset( $_POST['action'] ) && "update_trainer_info" == $_POST['action'] )
{
    // error_log( "Update trainer info" );

    check_admin_referer( "Trainer_Profile_nonce", "trainersmeta_noncename" );
    
    extract( $_REQUEST );

    // error_log( print_r( $_FILES, true ) );

    $trainer_meta = get_post_meta( $upload_trainer_id, "_trainers_meta", true );

    // error_log( print_r( $trainer_meta, true ) );

    $trainer_meta['phone'] = $phone;

    $trainer_meta['address'] = $address;
        
    $trainer_meta['dateQualExpd'] = $dateQualExpd;

    $trainer_meta['preferredVenues'] = $preferredVenues;

    // error_log( print_r( $preferredVenues, true ) );

    update_post_meta(  $upload_trainer_id, "_trainers_meta", $trainer_meta );

    // error_log( print_r( $_FILES, true ) );

    // echo "success";

    // These files need to be included as dependencies when on the front end.
    require_once( ABSPATH . 'wp-admin/includes/image.php' );
    require_once( ABSPATH . 'wp-admin/includes/file.php' );
    require_once( ABSPATH . 'wp-admin/includes/media.php' );
        
    require_once ABSPATH . 'wp-admin/includes/image.php';

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $trainer_id = $_REQUEST['upload_trainer_id'];

    $file_name = $_FILES['upload_trainer_certificates']['name'];

    $file_tmp_name = $_FILES['upload_trainer_certificates']['tmp_name'];

    $uploadedfile = $_FILES['upload_trainer_certificates'];

    $upload_overrides = array('test_form' => false);

    $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

    $attach_id = $movefile["url"];

    $trainer_docs_exists = get_post_meta($trainer_id, '_trainer_meta_documentation', true);

    if (!empty($trainer_docs_exists)) {
        array_push($trainer_docs_exists, $attach_id);
        $update_data = $trainer_docs_exists;
    } else {
        $update_data[] = $attach_id;
    }

    update_post_meta($trainer_id, '_trainer_meta_documentation', $update_data);


}

$profile = get_user_meta( get_current_user_id(), "_profile", true );

if ( $post->post_name != $profile && current_user_can( 'trainer' ) )
wp_redirect( site_url( '/trainers/'.$profile, 302 ) );

$trainer = get_page_by_path( $post->post_name, OBJECT, 'trainers' );

$trainer_meta = get_post_meta( $trainer->ID, "_trainers_meta", true );

//debug( 10, $trainer_meta );

//print_r( $trainer_meta );

$layout = 'full';

$_eo = get_option( '_elementor_general_settings' );

if( isset( $_eo[ 'container_width' ] ))
    $max_width = $_eo[ 'container_width' ];
else
    $max_width = 1140;

get_header();

?>

<div id="body">
  <div class="container" style="max-width: <?php echo $max_width; ?>px" >
    <div class="content-pad-3x">
      <div class="row">
          <div class="content">
              <div class="message-bar"><p>We are transitioning to a new system and you should use that system now.  If you have not already recieved login details please contact Siren.</p>
              <p><a href="https://admin.sirentraining.co.uk"><button>Goto New System</button></a></p></div>
          </div>
      </div>

      <div class="row">
        <div id="content" class="<?php echo $layout!='full'?'col-md-9':'col-md-12' ?><?php echo ($layout == 'left') ? " revert-layout":"";?>">
          <div class="blog-listing">
              <div class="row">
                  <div class="col-sm-6">
                        <h2>Trainer Portal : <?php echo $post->post_title; ?></h2>
                  </div>
                  <div class="col-sm-6">
                      <ul style="list-style-type: none;">
                      <li class="dropdown right">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"  style="padding: 12px;border: 1px solid #e4e4e4;font-weight: 500;font-size: 15px;">Jot Forms
                  <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="https://www.sirentraining.co.uk/efaw-form/" target="_blank">EFAW</a></li>
                      <li><a href="https://www.sirentraining.co.uk/faw-form/"target="_blank">FAW</a></li>
                       <li><a href="https://www.sirentraining.co.uk/paediatric-first-aid-form/" target="_blank">Paediatric First Aid</a></li>
                       <li><a href="https://www.sirentraining.co.uk/fire-marshal-training-form/" target="_blank">Fire Marshal Training</a></li>
                        <li><a href="https://www.sirentraining.co.uk/efaw-sports-form/" target="_blank">EFAW + Sports</a></li>
                  </ul>
                </li>
                </ul>
</div>
                  </div>
          
            </div>
            <br />
            <ul class="nav nav-tabs" id="trainerPortal">
              <li class="active"><a data-toggle="tab" href="#schedule">Your Schedule</a></li>
							<li><a data-toggle="tab" href="#pastjobs">Your Past Jobs</a></li>
              <li><a data-toggle="tab" href="#courses">Available Courses</a></li>
              <li><a data-toggle="tab" href="#course" style="display:none;">Course Details</a></li>

              <li class="dropdown right">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Settings
                  <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a data-toggle="tab" href="#profile">Profile</a></li>
                    <?php if ( current_user_can( 'trainer' ) ) : ?>
                      <li><a href="<?php echo wp_logout_url( '/trainers/' ); ?>">Logout</a></li>
                    <?php endif; ?>
                  </ul>
                </li>
              </ul>

              <div class="tab-content">
								<!--past jobs start-->
								<div id="pastjobs" class="tab-pane fade">
									<h3>your Past Jobs here.</h3>
									 <?php
                  global $theme_twig;

                  $events = get_posts(
                    array(
                      'posts_per_page' => -1,
                      'post_type' => 'product_variation',
                      'post_status' => 'publish',
                      'meta_query' => array(
                        array(
												'relation' => 'AND',
													array(
														'key' => '_trainer_code',
														'value' => $post->post_name
													),
													array (
														'key' => '_start_date',
														'value' => time(),
														'compare' => '<=',
													),
                        ),
                      )
                    )
                  );

                  $schedule = array();

                  $pastjob = array();

                  foreach($events as $event)
                  {
                    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

                    // Get venue
                    $venue = get_page_by_path( $calendar_data['venue']['key'], OBJECT, 'venues' );
                    $venue_meta = get_post_meta( $venue->ID, '_venues_meta', true );

                    // get Product details

                    // debug( 71, preg_split( "/\\r\\n|\\r|\\n/", $venue_meta['address'] ) );
										

                    $pastjob[] = array (
                      'id' => $event->ID,
                      'date' => date( "Y-m-d H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ) ,
                      'fDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ),
                      'tDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'end_date_time' ] ) ),
                      'course' => $calendar_data[ 'product' ][ 'name' ],
                      'venue' => $calendar_data['venue']['name'],
                      'address' => preg_split( "/\\r\\n|\\r|\\n/", $venue_meta['address'] ),
                      'phone' => $venue_meta['phone'] ,
                      'email' => $venue_meta['email'] ,
                      'url' => $venue_meta['url'] ,
                      'details' => preg_split( "/\\r\\n|\\r|\\n/", $calendar_data['notes'] ),
                      'attendees' => 12,
                      'limit' => 20,
                      'register' => site_url( "/pdf-generator/register/".$event->ID ),
                    );

                  }

                  if ( is_array( $pastjob ) )
                  {
                    usort($pastjob, function ($a, $b) {
                      $t1 = strtotime($b['date']);
                      $t2 = strtotime($a['date']);
                      return $t1 - $t2;
                    });
                  }
                  else
                    $pastjob = array();

                  $injector = array(
                    'trainer' => $post->post_name,
                    'pastjob' => $pastjob
                  );

                 $pastjob = $theme_twig->loadTemplate('trainer/_pastjobs.html');

                 echo $pastjob->render( $injector );
									
                  ?>
									
									<!--pastjobs html start-->
								</div>
								<!--past jobs end-->
                <div id="schedule" class="tab-pane fade in active">
                  <h3>You are booked for the following courses.</h3>

                  <?php
                  global $theme_twig;

                  $events = get_posts(
                    array(
                      'posts_per_page' => -1,
                      'post_type' => 'product_variation',
                      'post_status' => 'publish',
                      'meta_query' => array(
                        array(
												'relation' => 'AND',
													array(
														'key' => '_trainer_code',
														'value' => $post->post_name
													),
													array (
														'key' => '_start_date',
														'value' => time(),
														'compare' => '>=',
													),
                        ),
                      )
                    )
                  );
									

                  $schedule = array();

                  foreach( $events as $event )
                  {
                    $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

                    // Get venue
                    $venue = get_page_by_path( $calendar_data['venue']['key'], OBJECT, 'venues' );
                    $venue_meta = get_post_meta( $venue->ID, '_venues_meta', true );

                    // get Product details

                    // debug( 71, preg_split( "/\\r\\n|\\r|\\n/", $venue_meta['address'] ) );
										
										$course_address = get_post_meta($event->ID,'_course_address',true);
										$course_postcode = get_post_meta($event->ID,'_course_postcode',true);
										$course_contactemail = get_post_meta($event->ID,'_course_contactemail',true);
										$course_contactnumber = get_post_meta($event->ID,'_course_contactnumber',true);
										$course_resources = get_post_meta($event->ID,'_course_resources',true);
										$course_any_other_info = get_post_meta($event->ID,'_course_any_other_info',true);

                    $schedule[] = array (
                      'id' => $event->ID,
                      'date' => date( "Y-m-d H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ) ,
                      'fDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ),
                      'tDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'end_date_time' ] ) ),
                      'course' => $calendar_data[ 'product' ][ 'name' ],
                      'venue' => $calendar_data['venue']['name'],
                      'address' => preg_split( "/\\r\\n|\\r|\\n/", $venue_meta['address'] ),
                      'phone' => $venue_meta['phone'] ,
                      'email' => $venue_meta['email'] ,
                      'url' => $venue_meta['url'] ,
                      'details' => preg_split( "/\\r\\n|\\r|\\n/", $calendar_data['notes'] ),
                      'attendees' => 12,
                      'limit' => 20,
                      'register' => site_url( "/pdf-generator/register/".$event->ID ),
											'course_address' => $course_address,
											'course_postcode' => $course_postcode,
											'course_contactemail' => $course_contactemail,
											'course_contactnumber' => $course_contactnumber,
											'course_resources' => $course_resources,
											'course_any_other_info' => $course_any_other_info,
                    );

                  }

                  /*new code start*/
									usort($schedule, function ($a, $b) {
                    $t1 = strtotime($b['date']);
                    $t2 = strtotime($a['date']);
                    return $t1 - $t2;
                  });
									/*new code end*/

                  $injector = array(
                    'trainer' => $post->post_name,
                    'schedule' => $schedule
                  );

                  $schedule = $theme_twig->loadTemplate( 'trainer/_schedule.html' );

                  echo $schedule->render( $injector );

                  ?>
                </div>
                <div id="courses" class="tab-pane fade">
                  
									<div>
										<div class="course-title-custom"><h3>These courses are available.</h3></div>
										<?php $trainer_meta_preferredvenues = $trainer_meta['preferredVenues']; ?>
										<!--new code start-->
										<div class="course-filter-date">
												<label>Sort By : </label><select id="course-sort-date" name="course-sort-date">
													<option value="new">Date Descending</option>
													<option value="old">Date Ascending</option>
												</select>
												<input type="hidden" name="get_preferred_venues" id="get_preferred_venues" value="<?php echo $trainer_meta_preferredvenues; ?>">
												<input type="hidden" name="get_trainer_id_ajax" id="get_trainer_id_ajax" value="<?php echo $trainer->ID; ?>">
											</div>
										<!--new code end-->
										<!--Search by course type start-->
										<div class="course-filter-date">
										<?php 
										$trainer_meta_preferredvenues = $trainer_meta['preferredVenues']; 
										$args_posts = array('posts_per_page' => -1,'post_type' => 'product','post_status' => 'publish','order' => 'DESC');
										$course_posts = get_posts($args_posts);
										
										?>
											<label>Sort By Course Type: </label>
											<select id="course-sort-type" name="course-sort-type">
											<option value="">Select Course Type</option>
											<?php
												foreach($course_posts as $course_post){
											?>
												<option value="<?php echo $course_post->post_title; ?>"> <?php echo $course_post->post_title; ?> </option>
											<?php
												}
											?>
											</select>
											<input type="hidden" name="get_preferred_venues_coursetype" id="get_preferred_venues_coursetype" value="<?php echo $trainer_meta_preferredvenues; ?>">
											<input type="hidden" name="get_trainer_id_ajax_coursetype" id="get_trainer_id_ajax_coursetype" value="<?php echo $trainer->ID; ?>">
										</div>
										<!--Search by course type end-->
									</div>
									

                  <?php

                  $events = get_posts(

                    array (
                      'posts_per_page' => -1,
                      'nopaging' => true,
                      'post_type' => 'product_variation',
                      'post_status' => 'publish',
                      'meta_query' => array (
                        'relation' => 'AND',
                        array (
                          'relation' => 'OR',
                          array (
                            array (
                              'key' => '_trainer_code',
                              'value' => "none",
                            ),
                            array (
                              'key' => '_trainer_code',
                              'compare' => 'NOT EXIST',
                            ),
                          ),
                        ),
                        //array (
                        array (
                          'key' => '_venue_code',
                          'value' => $trainer_meta['preferredVenues'],
                          'compare' => 'IN'
                        ),
                        //),
                        //array (
                        array (
                          'key' => '_start_date',
                          'value' => time(),
                          'compare' => '>=',
                        ),
                        //),
                        )
                        )
                      );

                      $all_other_events = get_posts (

                        array (
                          'posts_per_page' => -1,
                          'nopaging' => true,
                          'post_type' => 'product_variation',
                          'post_status' => 'publish',
                          'meta_query' => array (
                            'relation' => 'AND',
                            array (
                              'relation' => 'OR',
                              array (
                                array (
                                  'key' => '_trainer_code',
                                  'value' => "none",
                                ),
                                array (
                                  'key' => '_trainer_code',
                                  'compare' => 'NOT EXIST',
                                ),
                              ),
                            ),
                            //array (
                            array (
                              'key' => '_venue_code',
                              'value' => $trainer_meta['preferredVenues'],
                              'compare' => 'NOT IN'
                            ),
                            //),
                            //array (
                            array (
                              'key' => '_start_date',
                              'value' => time(),
                              'compare' => '>=',
                            ),

                            //)
                            )
                            )
                          );

                          //debug( 'events', $events );

                          // $events = array_merge( $events, $all_other_events );
                          // foreach( $all_other_events as $e )
                          //     $events[] = $e;


                          $available = array();

                          foreach( $events as $event )
                          {
                            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

                            if ( !is_array( $calendar_data ) )
                                continue;

                            // ob_start();
                            // var_dump( $calendar_data );
                            // echo "<div><pre>".ob_get_clean()."</pre><br /></div>";
                                
        
    
                            // Get venue

                            if ( $calendar_data['venue']['key'] != "none" )
                            {
                              // debug( "calendar_data", $calendar_data );

                              $venue = get_page_by_path( $calendar_data['venue']['key'], OBJECT, 'venues' );

                              $venue_meta = get_post_meta( $venue->ID, '_venues_meta', true );

                              if ( "" == $venue_meta )
                              {
                                $venue_meta = array
                                (
                                  'address' => "",
                                  'phone' => "",
                                  'email' => "",
                                  'url' => ""
                                );
                              }
                            }
                            else
                            {
                              $venue_meta = array
                              (
                                'address' => "",
                                'phone' => "",
                                'email' => "",
                                'url' => ""
                              );
                            }

                            // debug( "venue", $venue_meta  );

                            $booked_course_trainer = "Apply";
                            $booked_color = "background-color:#EBE9EB;color:#1D469F";
                            $booked_class = "booking_request";
                                                          

                            $available[date( "Y-m-d H:i", strtotime( $calendar_data[ 'start_date_time' ] ) )] = array (
                              'id' => $event->ID,
                              'date' => date( "Y-m-d H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ) ,
                              'fDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ),
                              'tDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'end_date_time' ] ) ),
                              'course' => $calendar_data[ 'product' ][ 'name' ],
                              'venue' => $calendar_data['venue']['name'],
                              'address' => preg_split( "/\\r\\n|\\r|\\n/", $venue_meta['address'] ),
                              'phone' => $venue_meta['phone'] ,
                              'email' => $venue_meta['email'] ,
                              'url' => $venue_meta['url'] ,
                              'details' => preg_split( "/\\r\\n|\\r|\\n/", $calendar_data['notes'] ),
                              'attendees' => 0, // get_attendee_count( $event->ID )
                              'limit' => $calendar_data[ 'product' ][ 'places' ],
															'bookedcourse' => $booked_course_trainer,
															'bookedcolor' => $booked_color,
															'bookedclass' => $booked_class,
                            );
                          }


                          $also_available = array();

                          foreach( $all_other_events as $event )
                          {
                            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

                            if ( !is_array( $calendar_data ) )
                                continue;

                            // Get venue

                            if ( is_array( $calendar_data ) && $calendar_data['venue']['key'] != "none" )
                            {
                              // error_log( print_r( $calendar_data, true ) );

                              $venue = get_page_by_path( $calendar_data['venue']['key'], OBJECT, 'venues' );

                              $venue_meta = get_post_meta( $venue->ID, '_venues_meta', true );

                              if ( "" == $venue_meta )
                              {
                                $venue_meta = array
                                (
                                  'address' => "",
                                  'phone' => "",
                                  'email' => "",
                                  'url' => ""
                                );
                              }
                            }
                            else
                            {
                              $venue_meta = array
                              (
                                'address' => "",
                                'phone' => "",
                                'email' => "",
                                'url' => ""
                              );
                            }

                            //debug( "venue", $venue_meta  );
														
														/*new code start*/
														$course_avail_postcode = get_post_meta($event->ID,'_course_postcode',true);
														/*new code end*/
														
														$get_calender_data = get_post_meta($event->ID,'_calendar_data',true); 
                            if ( isset( $get_calender_data['trainer_request'] ))
														    $cal_data_new = $get_calender_data['trainer_request'];
                            else
                                $cal_data_new = array(
                                'trainer_id' => 0,
                                'name' => 'Undefined',
                                'confirmed' => false
                                );
														
														$user_d_new = $cal_data_new;
															
                            unset($user_d_new['trainer_id']);
                            unset($user_d_new['name']);
                            unset($user_d_new['confirmed']);
                            
                            $booked_course_trainer = "Apply";
                            $booked_color = "background-color:#EBE9EB;color:#1D469F";
                            $booked_class = "booking_request";
                                                          
                            if(in_array($trainer->ID, array_column($user_d_new, 'trainer_id'))) { // search value in the array
                                $booked_course_trainer = "Applied";
                                $booked_color = "background-color:#F14E63 !important;color:#ffffff";
                                $booked_class = "";
                            }
															
                            // echo "<<<<<"."<br /><pre>".print_r( $calendar_data, true )."</pre><br />".">>>>>"."<br />";

                            $also_available[date( "Y-m-d H:i", strtotime( $calendar_data[ 'start_date_time' ] ) )] = array (
                              'id' => $event->ID,
                              'date' => date( "Y-m-d H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ) ,
                              'fDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'start_date_time' ] ) ),
                              'tDate' => date( "d/m/Y H:i", strtotime( $calendar_data[ 'end_date_time' ] ) ),
                              'course' => $calendar_data[ 'product' ][ 'name' ],
                              'venue' => $calendar_data['venue']['name'],
                              'address' => preg_split( "/\\r\\n|\\r|\\n/", $venue_meta['address'] ),
                              'phone' => $venue_meta['phone'] ,
                              'email' => $venue_meta['email'] ,
                              'url' => $venue_meta['url'] ,
                              'details' => preg_split( "/\\r\\n|\\r|\\n/", ( isset( $calendar_data['notes'] ) && $calendar_data['notes'] != null ? $calendar_data['notes'] : "" ) ),
                              'attendees' => 0, // get_attendee_count( $event->ID )
                              'limit' => $calendar_data[ 'product' ][ 'places' ],
															'postcode' => $course_avail_postcode,
															'bookedcourse' => $booked_course_trainer,
															'bookedcolor' => $booked_color,
															'bookedclass' => $booked_class,
                            );
                          }

                          ksort( $available, SORT_NATURAL );
                          ksort( $also_available, SORT_NATURAL );

                          foreach( $also_available as $e )
                            $available[] = $e;
													
													// /*new code start*/
													// usort($available, function ($a, $b) {
													// $t1 = strtotime($b['date']);
													// $t2 = strtotime($a['date']);
													// return $t1 - $t2;
													// });
													// /*new code end*/

                          $injector = array(
                            'trainer' => $post->post_name,
                            'trainer_id' => $post->ID,
                            'available' => $available
                          );

                          $available = $theme_twig->loadTemplate( 'trainer/_available.html' );

                          echo $available->render( $injector );

                          ?>
                        </div>
                        <div id="profile" class="tab-pane fade">
                          <h3>Your Details</h3>
                          <div class="siren-profile-box">
                            <?php

                            // $ = get_post_meta( $post->ID, "_trainers_meta", true );

                            $injector = array();

                            $injector['nonce'] = wp_create_nonce( "Trainer_Profile_nonce" );
                            $injector['trainer'] = $trainer_meta;
                            $injector['trainer_id'] = $trainer->ID;

                            // error_log( print_r( $trainer_meta, true ) );

                            // error_log( print_r( $injector, true ) );

                            // error_log( print_r( $trainer, true ) );

                            $injector['trainer']['preferredVenues'] = array();

                            $venues = get_posts( array(
                              'posts_per_page' => -1,
                              'post_type' => 'venues',
                              'post_status' => 'publish',
                              'orderby' => 'title',
                              'order' => 'ASC',
                              'nopaging' => true
                            ) ) ;

                            // debug( 246, $trainer_meta );
                            // debug( 247, $venues );
                            // debug( 362, $injector );

                            if ( !empty( $venues ) && !empty( $trainer_meta[ 'preferredVenues' ] ) )
                            {
                              foreach( $venues as $venue )
                              {
                                $injector['trainer']['preferredVenues'][] = array
                                (
                                  'key' => $venue->post_name,
                                  'label' => $venue->post_title,
                                  'checked' => ( in_array( $venue->post_name, $trainer_meta['preferredVenues']) ? true : false )
                                );
                              }
                            }


                            $available = $theme_twig->loadTemplate( 'trainer/_profile.html' );

                            echo $available->render( $injector );

                            ?>
                          </div>
                        </div>

                        <div id="course" class="tab-pane fade">
                          <h3>Course Details</h3>
                          <p>Course data</p>
                        </div>

                      </div>
                    </div>
                  </div><!--/content-->
                </div><!--/row-->
              </div><!--/content-pad-->
            </div><!--/container-->
          </div><!--/body-->

          <script>

          var $trainerID = '<?php echo $post->post_name; ?>';

          var trainer = <?php echo $post->ID; ?>;
          var siren_url = '<?php echo site_url( "booking-api/trainer/request/" ); ?>';
          var ajax_file_url_value = '<?php echo get_stylesheet_directory_uri(); ?>';


          //siren-dev.apadmi.com/booking-api/trainer/request/3128/3364

          jQuery(document).ready(function(){

            // Javascript to enable link to tab
            var hash = document.location.hash;

            var prefix = "_";
            if (hash)
            {
                // console.log( hash );

                // console.log ( hash.replace(prefix,"") );

                jQuery('.nav-tabs a[href="'+hash.replace(prefix,"")+'"]').tab('show');
            }

            // Change hash for page-reload
            jQuery('.nav-tabs a').on('shown.bs.tab', function (e)
            {
              window.location.hash = e.target.hash.replace("#", "#" + prefix);
            });

            jQuery('.collapse').on('show.bs.collapse', function () {
              jQuery('.collapse.in').collapse('hide');
            });
						

			jQuery(document).on('click', '.booking_request', function() {
              var course = jQuery( this ).data( 'course' );

              var button = this;

              // console.log( siren_url+trainer+"/"+course );

              jQuery.ajax(
                {
                  url: siren_url+trainer+"/"+course,
                  method: 'POST',
                  context: document.body
                }
              ).done( function()
              {
                //
              }) .fail(function() {
                 console.log(error );
              });

            jQuery( this ).unbind( "click" ).html( "Applied" );
            jQuery( this ).addClass("trainer-portal-cus");
          });
					
				/*course filter by course type start*/
				jQuery(document).on('change', '#course-sort-type', function() {
				var selected_value = jQuery(this).val();
				var preferred_venue_value = jQuery('#get_preferred_venues_coursetype').val();
				var get_trainer_id = jQuery('#get_trainer_id_ajax_coursetype').val();
				jQuery.post(ajax_file_url_value+"/ajax.php", { 
							 a_selected_value: selected_value, 
							 a_preferred_venue_value: preferred_venue_value,
							 a_get_trainer_id: get_trainer_id,
							 action: 'course-filter-by-coursetype'},function(data) {
								 var trimmed_value = jQuery.trim(data);
								 jQuery(".available_table tbody").html(trimmed_value);
									});
				});
            /*course filter by course type end*/
			 
			/*file upload start*/
			// jQuery(document).on('change', '#upload_trainer_certificates', function() {	
            var data = {};

            jQuery(document).on('click', '#save_trainer_details', function( e ) 
            {
                e.preventDefault();

                // Get form
                var form = jQuery('#upload_trainer_certificates_fm')[0];

                data = jQuery('#upload_trainer_certificates_fm').serializeObject();
                // console.log( data );

                // var fd = {
                //     nonce : data.trainersmeta_noncename,
                //     email : data.user_email,
                //     phone : data.phone,
                //     pword : data.password,
                //     address: data.address,
                //     dateQualExpd: data.dateQualExpd,
                //     user_email: data.user_email,
                //     upload_trainer_id: data.upload_trainer_id,
                //     action: "update_trainer_doc_info" 
                // };

                // fd.preferredVenues = [];

                // jQuery('#upload_trainer_certificates_fm')[0]
                fd = new FormData( form )
                
                // jQuery( ".preferredVenues:checkbox:checked" ).map( function() {
                //     fd.preferredVenues.push( jQuery( this ).val() );
                // });

                // console.log( jQuery( data.preferredVenues ).val() );

                console.log( ajax_file_url_value );

                jQuery('.loading_message').show();	
                jQuery.ajax(
                {
                    type:"POST",
                    // action:"update_trainer_doc_info",
                    url: ajax_file_url_value+"/ajax.php?status=update_trainer_doc_info",
                    // url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function(response){
                        jQuery('.loading_message').hide();
                        jQuery(".trainer_notification").empty();
                        var trimmed_value = jQuery.trim(response);
                        if(trimmed_value=='success'){
                        jQuery(".trainer_notification").fadeIn(1000);
                        jQuery(".trainer_notification").html("Updated Successfully.");
                        jQuery(".trainer_notification").fadeOut(10000);
                        } else {
                        jQuery(".trainer_notification").html('Failed To Upload.');
                        jQuery(".trainer_notification").fadeIn(5000);
                        }
                    },
                    error: function( error ){
                        jQuery('.loading_message').hide();
                        jQuery(".trainer_notification").empty();
                        jQuery(".trainer_notification").fadeIn(1000);
                        jQuery(".trainer_notification").html('Failed.');
                        jQuery(".trainer_notification").fadeOut(10000);
                     
                    }
                });

			});
			/*file upload end*/		
					

        });
				
				
				/*trainer filter end*/
        </script>
        <?php

        get_footer();

        ?>
