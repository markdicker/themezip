<?php

/* Template Name: Pdf Creation */

get_header();

?>

<b>hello welocme</b>

<?php

get_footer();

?>