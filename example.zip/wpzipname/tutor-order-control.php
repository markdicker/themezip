<?php
/*

Plugin Name: Siren Course Order Control 1.0.0
Plugin URI:
Description: Prevent course order autocomplete for invoice customers.
Author: Mark Dicker
Version: 1.0.0

*/



add_filter( 'woocommerce_order_item_needs_processing' , 'siren_filter_woo_item_needs_processing', 10, 3 );
 
function siren_filter_woo_item_needs_processing( $needs_processing, $product, $order_ID ) 
{
    // $product_type = $product->get_type();
    $order = new WC_Order( $order_ID );
    $payment_method = $order->get_payment_method();

    // prevent cod orders for virtual products being marked as complete
    if ( $product->is_virtual() && $payment_method == 'cod' ) 
    {
        return false;
    }
     
    return $needs_processing;
}