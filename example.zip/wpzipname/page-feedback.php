<?php

// print_r( $_POST );
// print_r( $_GET );

$_eo = get_option( '_elementor_general_settings' );

if( isset( $_eo[ 'container_width' ] ))
    $max_width = $_eo[ 'container_width' ];
else
    $max_width = 1140;


$course_id = get_query_var( 'course_id' ); 

$learner_id = get_query_var( 'learner_id' ); 


// echo $course_id.PHP_EOL;
// echo $learner_id.PHP_EOL;

$calendar_data = get_post_meta( $course_id, '_calendar_data', true );

if ( !is_array( $calendar_data ) )
    exit( 500 );

$learner_data = get_post_meta( $learner_id, '_learner_details', true );
    
if ( !is_array( $learner_data ) )
    exit( 500 );

$venue_meta = get_post_meta( $learner_id, '_venues_meta', true );
    
if ( !is_array( $learner_data ) )
    exit( 500 );


$assigned_venue = get_page_by_path( $calendar_data['venue']['key'], OBJECT, 'venues' );

if ( $assigned_venue != null )
{
    $location = $assigned_venue->post_title;
}
else
{
    $location = $calendar_data['venue']['name'];
}


$assigned_product = get_page_by_path( $calendar_data['product']['key'], OBJECT, 'products' );

if ( $assigned_product != null )
{
    $course_name = $assigned_product->post_title;
}
else
{
    $course_name = $calendar_data['product']['name'];
}


if ( isset( $_POST['feedback_tag'] ) && wp_verify_nonce( $_POST['feedback_tag'], "feedback-".$course_id."-".$learner_id )  )
{
    // Save the data

    //echo "<pre>".print_r( $_POST, true )."</pre>";

    $feedback = array(
        'post_title'=> "feedback-".$course_id."-".$learner_id,
        'post_name' => "feedback-".$course_id."-".$learner_id,
        'post_status' => 'publish',
        'post_type' => 'feedback',//set post type to product_variation
        'guid'=> ''
    );

    // 
    $feedback_id = wp_insert_post( $feedback );

    update_post_meta( $feedback_id, "_feedback_data", $_POST );

    update_post_meta( $feedback_id, "_course", $course_id );
    update_post_meta( $feedback_id, "_learner", $learner_id );

    update_post_meta( $course_id, "_feedback", $feedback_id );
    update_post_meta( $learner_id, "_feedback", $feedback_id );

    wp_redirect( site_url( "/pdf-generator/certificate/".$learner_id ), 302 );
}

// check if feed back already left

// if feedback already left then go to certificate

$feedback = get_page_by_path( "feedback-".$course_id."-".$learner_id, OBJECT, "feedback" );

if ( $feedback != null )
{
    wp_redirect( site_url( "/pdf-generator/certificate/".$learner_id ), 302 );
}

get_header();

?>
    <div id="body">
    	<div class="container" style="max-width: <?php echo $max_width; ?>px; margin:0 auto;" >
        	<div class="content-pad-3x">
                <div class="row">
                    <div id="content" class="<?php echo $layout!='full'?'col-md-9':'col-md-12' ?><?php echo ($layout == 'left') ? " revert-layout":"";?>">

                        <h2>Please provide feedback on your recent experience on the following course</h2>

                        <form method="post" >
                        <?php

                            wp_nonce_field( "feedback-".$course_id."-".$learner_id, "feedback_tag" );
                            

                global $theme_twig;

                 $calendar_data = get_post_meta( $course_id, '_calendar_data', true );
        
                 $course_syllabus = get_page_by_path( $calendar_data['syllabus']['key'], OBJECT, 'course_syllabus' );

                $assigned_venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

                if ($assigned_venue != null) 
                {
                    $location = $assigned_venue->post_title;
                } 
                else 
                {
                    $location = $calendar_data['venue']['name'];
                }


         $course = get_page_by_path($calendar_data['product']['key'], OBJECT,
         'product');
 
     
     if (null != $course) $course_name = $course->post_title;
     else $course_name = $calendar_data['product']['name'];

             $injector = array
                                (
                               
                                'course' => $course_name,
                                 'date' => dateRange(strtotime($calendar_data['start_date_time']),
                                    strtotime($calendar_data['end_date_time'])),
                                 'location' => $location,
                                 'course_id' => $course_id,
                                 'learner_id' => $learner_id
                            );

                        $feedback = $theme_twig->loadTemplate( 'feedback/_feedback.html' );

                        echo $feedback->render( $injector );
                                                                
                        ?>
                        <br />
                        <p><input type="submit" value="Submit Feedback" /></p>

                        </form>
<!-- 
                        <p style="margin-top:40px;"><br />
                        <br /></p>
                        <h3>Plese leave us a short review about how we did at : </h3>
                        <p><a href="https://goo.gl/hjMcJA"><button>https://goo.gl/hjMcJA</button></a></p> 

    -->

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
get_footer();

