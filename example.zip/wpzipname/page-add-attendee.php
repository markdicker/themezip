<?php

$layout = 'full';

get_header();

?>
    <div id="body">
    	<div class="container">
        	<div class="content-pad-3x">
                <div class="row">
                    <div id="content" class="<?php echo ($layout!='full')?'col-md-9':'col-md-12' ?><?php echo ($layout == 'left') ? " revert-layout": ""; ?>">
                        <?php
                        $course_id = (int)get_query_var( 'course_id' );

                        // $learners = get_posts( array(
                  		// 			'posts_per_page' => -1,
                  		// 			'post_type' => 'learner',
                  		// 			'post_status' => 'publish',
                  		// 			'post_parent' => $course_id,
                  		// 			'orderby' => 'ID',
                  		// 			'order' => 'ASC',
                  		// 			'nopaging' => true
                  		// 		) ) ;

                        $attendees = array();

                        // foreach( $learners as $learner )
                        // {
                        // 	$attendees[ ] = get_post_meta( $learner->ID, '_learner_details', true );
                        // }


                        $course_data = get_post_meta($course_id, '_calendar_data', true);

                        if ($course_data == "") {
                            return new WP_Error('not_found', "Course not found",
                                array('status' => 404));
                        }

                        $course_data['id'] = $course_id;

                        // $num_places = $course_data['product']['places'];

                        $num_places = 5;

                  		?>

                  		<p>
                        <strong>Important</strong> - Please input the names of all attendees attending PRIOR to the commencement of the course. If you need to amend any names at any point, please revisit this link and update this live document. Thank you.
                        </p>

                  		<table class='attendees' id="<?php echo $course_id ?>" width="100%">
                  			<tbody>
                  				<tr>
                  					<td width="25%">First Name</td>
                  					<td width="25%">Surname</td>
                  					<td width="25%">Personal email</td>
                  					<td width="25%">Mobile Phone</td>
                  				</tr>
													
                          <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" id="add_update_attendeefm">
                          <input type="hidden" name="course_id" value="<?php echo $course_id ?>" />
                          <input type="hidden" name="action" value="update_attendee" />
                          <?php for ($i = 0; $i < $num_places; $i++ ) {?>

                  					<tr>
                  						<td>
                  							<input class="chk_row_<?php echo $i;?>" name="_fname[<?php echo $course_id ?>][<?php echo $i; ?>]" type="text" value="<?php echo $attendees[$i]['fname'] ?>" style="width:100%;" /></td>
                  						<td><input class="chk_row_<?php echo $i;?>" name="_sname[<?php echo $course_id ?>][<?php echo $i; ?>]" type="text" value="<?php echo $attendees[$i]['sname'] ?>" style="width:100%;" /></td>
                  						<td><input class="chk_row_<?php echo $i;?>" type="text" name="_email[<?php echo $course_id ?>][<?php echo $i; ?>]" value="<?php echo $attendees[$i]['pemail'] ?>" style="width:100%;" /></td>
                  						<td><input type="phone" name="_phone[<?php echo $course_id ?>][<?php echo $i; ?>]" value="<?php echo $attendees[$i]['phone'] ?>" style="width:100%;" />
                  							<input type='hidden' name='_cemail[<?php echo $course_id ?>][<?php echo $i; ?>]' value = '<?php echo $attendees[$i]['cemail'] ?>' />
                  						</td>
                  					</tr>


                  					<?php } ?>

                  			</tbody>
                  		</table>

                      <br />

                  		<p class="order-again">
                  			<input type="button" class="button" value="Update Attendee List" onclick="add_attendee_updatelist();" />
                  		</p>
                    </form>
                    </div><!--/content-->
                </div><!--/row-->
            </div><!--/content-pad-->
        </div><!--/container-->
    </div><!--/body-->

<script type="text/javascript">
function add_attendee_updatelist(){

var objErrChk = []; jQuery('input[type="text"]').each(function(){ if(jQuery(this).val() != ''){  objErrChk.push(jQuery(this).attr('class'));}}); 


Array.prototype.customUnique = function () {
    var r = new Array();
    o:for(var i = 0, n = this.length; i < n; i++)
    {
        for(var x = 0, y = r.length; x < y; x++)
        {
            if(r[x]==this[i])
            {
                continue o;
            }
        }
        r[r.length] = this[i];
    }
    return r;
}


var result_objErrChk = objErrChk.customUnique();

var error = '';

for(var x=0;result_objErrChk.length > x; x++ ){
 jQuery('input[type="text"].'+result_objErrChk[x]).each(function(){
  if(jQuery(this).val() == ''){
   jQuery(this).addClass('error');
   error = 'yes';
  }else{
   jQuery(this).removeClass('error');
  }
 });
}

if(error == 'yes'){
alert('Please Fill Firstname, Surname, Email. Its Mandatory.');
}else{
jQuery('#add_update_attendeefm').submit();
}
}
</script>

<?php

get_footer();

?>
