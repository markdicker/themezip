<?php
@ob_start();
@session_start();
include_once('../../../wp-config.php');
global $post,$wpdb;

$attendee_id = $_GET['attendee_id'];

$course_id = $_GET['course_id'];

if(!empty($attendee_id)){

        // $blanks = array('OFSTED' => 'OFSTED-PAED-BLANK-2.pdf', 'EFAW' => 'EFAW-cert-1.4.php', 'PLS-BLANK' => 'PLS-BLANK-1.pdf', 'PLS BLANK' => 'PLS-BLANK-1.pdf', 'Safe Moving _ Handling-pdffiller' => 'Safe-Moving-_-Handling-pdffiller.pdf', 'Fire Marshal cert' => 'Fire-Marshal-Cert.pdf', 'EPFA BLANk (2)' => 'EPFA-BLANk-2.pdf', 'FAW BLANK (2)' => 'FAW-BLANK-2.pdf', 'EFAW-BLANK' => 'EFAW-BLANK-1.pdf', 'ANAPHYLAXIS BLANK' => 'ANAPHYLAXIS-BLANK-1.pdf', 'BLS BLANK' => 'BLS-BLANK-1.pdf', 'FA REFRESH cert-pdffiller' => 'FA-REFRESH-cert-pdffiller.pdf', 'AED Fixed Date' => 'AED-Fixed-Date-1.pdf', 'Basic Paediatric First Aid template' => 'Basic-Paediatric-First-Aid-template.pdf', 'Fire Awareness Certificate' => 'Fire Awareness Certificate.pdf');
		
        // $data = [];
        // $data['attendee'] = get_post_meta( $attendee_id, "_learner_details", true );
        // $data['course_id'] = $data['attendee']['course_id'];
        // $data['calendar_data'] = get_post_meta( $data['course_id'], '_calendar_data', true );
        // $data['course_syllabus'] = get_page_by_path( $data['calendar_data']['syllabus']['key'], OBJECT, 'course_syllabus' );
        // $data['sylla_meta'] = get_post_meta( $data['course_syllabus']->ID, '_syllabus_meta', true );
        // $data['cert_path'] = $data['sylla_meta']['cert_label'];
        // $data['serial'] = $data['sylla_meta']['code'].date( "Ymd", strtotime( $data['calendar_data']['end_date_time'] ) ).sprintf( '%08d', $attendee_id );
        // $data['func'] = 'certificate';

        // //$headers = array( 'Content-type: application/x-www-form-urlencoded' );

        // $filename = "Siren_Training-".$data['serial'].".pdf";
				
				// $cert_path = $data['cert_path'];
				// $serial = $data['serial'];
				// $attendee_firstname = $data['attendee']['fname'];
				// $attendee_surename = $data['attendee']['sname'];
				// $calendar_data_end_date = $data['calendar_data']['end_date_time'];


				// $pdf = new FPDI('P', 'mm', 'A4' );
				
				// $pdf->setPrintHeader( false );
				// $pdf->setPrintFooter( false );
				
				// // set document information
				// $pdf->SetCreator( 'Siren Training Ltd' );
				// $pdf->SetAuthor( 'Mark Dicker' );
				// $pdf->SetTitle( "Learner Certificates" );
				// $pdf->SetSubject( "" );
				// $pdf->SetKeywords('private');
				// $pdf->SetAutoPageBreak( false, 0 );
				
				// $pdf->SetFontSize(20);
				// $pdf->AddPage();
				
				// $pages = $pdf->setSourceFile(get_stylesheet_directory().'/certs/'.$blanks[$cert_path]);
				// $page = $pdf->ImportPage( 1 );
				// $pdf->useTemplate( $page, 0, 0 );
				
				// $pdf->SetFontSize(16);
				// $pdf->SetXY( 14, 232 );
				// $pdf->Cell( 100, 20, $serial, 0, 0, 'L' );
				// $pdf->SetTextColor( 0, 41, 200 );
				// $pdf->SetFont('Helvetica','B',20);
				
				// $pdf->SetXY( 0, 95 );
				// $pdf->Cell ( 210, 20, $attendee_firstname." ".$attendee_surename , 0, 0, 'C' );
				// $pdf->SetFont('Helvetica','B',20);
				
				// $pdf->SetXY( 0, 171 );
				// $pdf->Cell ( 210.0, 20, date( 'jS F Y', strtotime( $calendar_data_end_date ) ) , 0, 0, 'C');
				
				// $pdf->AddPage();
				
				// $page = $pdf->ImportPage( 2 );
				// $pdf->useTemplate( $page, 0, 0 );
				
				// $print_footer = true;
				
				// $filename = "Siren_Training-".$serial.".pdf";
				
				// $pdf->Output( $filename, "I" );
				
				exit();
				
} elseif(!empty($course_id)){

    $master = get_post( $course_id );

    $master_meta = get_post_meta( $master->ID );

    $course = get_post( $master->post_parent );

    $assigned_trainer = get_page_by_path( get_post_meta( $course->ID, '_assigned_trainer', true ), OBJECT, 'trainers' );

    $trainer_meta = get_post_meta( $assigned_trainer->ID, '', true );

    $course_syllabus= get_page_by_path( get_post_meta( $course->ID, '_course_syllabus', true ), OBJECT, 'course_syllabus' );

    $course_meta = get_post_meta( $course_syllabus->ID, '', true );

    $assigned_venue = get_page_by_path( get_post_meta( $course->ID, '_assigned_venue', true ), OBJECT, 'venues' );

    $venue_meta = get_post_meta( $assigned_venue->ID, '', true );

    // get_post_meta does this if you request an individual meta entry - but we got them all and so have to do it ourselves
    $sylla_meta = unserialize( $course_meta['_syllabus_meta'][0] );

    $calendar_data = unserialize( $master_meta['_calendar_data'][0] );

    if ( $assigned_venue != NULL )
        $venue_name = $assigned_venue->post_title;
    else
        $venue_name = $calendar_data['venue']['name'];

    if ( $assigned_trainer != NULL )
        $trainer_name = $assigned_trainer->post_title;
    else
        $trainer_name = $calendar_data['trainer']['name'];

    $learners = get_posts( array(
      'posts_per_page' => -1,
      'post_type' => 'learner',
      'post_status' => 'publish',
      'post_parent' => $course_id,
      'orderby' => 'ID',
      'order' => 'ASC',
      'nopaging' => true
    ) ) ;

    $attendees = array();

    foreach( $learners as $learner )
    {
      $attendees[ ] = get_post_meta( $learner->ID, '_learner_details', true );
    }

    //debug( 175, $master_meta );

    $pdf = new FPDI( 'L', 'mm', 'A4' );

    $pdf->setPrintHeader( false );
    $pdf->setPrintFooter( false );

    // set document information
    $pdf->SetCreator( 'Siren Training Ltd' );
    $pdf->SetAuthor( 'Mark Dicker' );
    $pdf->SetTitle( "Learner Register" );
    $pdf->SetSubject( "" );
    $pdf->SetKeywords( 'private');
    $pdf->SetAutoPageBreak( false, 0 );

    //$pdf->SetFont( 'Times', '', 12 );

    $pdf->SetFontSize(9);

    $num_attendees = count( $learners );

    $line = 6;  // TODO : Replace with a constant

    $print_footer = true;

    $page = 0;
    $last_page =max( 1, ceil ( $num_attendees / 6 ) );

    foreach ( $attendees as $learner )
    {
      if ( 6 == $line )  // TODO : Use constant here as well
      {
        $pdf->AddPage();
        $pages = $pdf->setSourceFile( get_stylesheet_directory().'/certs/learner_register.pdf' );
        $pg = $pdf->ImportPage( 1 );
        $pdf->useTemplate( $pg, 0, 0 );
        $line = 0;

        $page ++;

        $pdf->SetAbsXY( 280, 3 );

        $pdf->SetFontSize(7);

        $pdf->Cell ( 15.0, 10, sprintf( "%d of %d", $page, $last_page ), 0, 0, 'C' );

        $pdf->SetFontSize(9);


        $pdf->SetAbsXY( 94.0, 10.0 );

        $pdf->Cell ( 67.0, 5.0, "", 0, 0, 'L' );

        $pdf->SetAbsXY( 172.0, 10.0 );

        $pdf->Cell ( 65.0, 5.0,  $venue_name, 0, 0, 'L' );


        $pdf->SetAbsXY( 94.0, 16.0 );

        $pdf->Cell ( 111.0, 5.0, $course->post_title, 0, 0, 'L' );

        $pdf->SetAbsXY( 216.5, 16.0 );

        $pdf->Cell ( 63.0, 5.0, $calendar_data['trainer']['name'], 0, 0, 'L' );


        $pdf->SetAbsXY( 98.5, 24.0 );

        //$date = strtok( "_", $master_meta['_calendar_data'][0]['start_date_time'] );
        //$time = strtok( "_" );

        //$date .= " ".str_replace( '-', ':', $time );

        // TODO: replace start date with date from final course object
        $pdf->Cell ( 40.0, 5.0, date( "j/m/Y  H:i", strtotime( $calendar_data['start_date_time'] ) ) , 0, 0, 'L' );

        $pdf->SetAbsXY( 170.0, 24.0 );

        // TODO: replace finish date with date from final course object
        $pdf->Cell ( 30.0, 5.0, date( "j/m/Y  H:i", strtotime( $calendar_data['end_date_time'] ) ), 0, 0, 'L' );

        $pdf->SetAbsXY( 220.0, 26.0 );

        $pdf->Cell ( 30.0, 5.0, $sylla_meta['duration'], 0, 0, 'L' );


        $pdf->SetAbsXY( 21.5, 196.0 );

        $pdf->Cell ( 6.0, 5.0, $num_attendees , 0, 0, 'L' );


        $print_footer = true;
      }

      $_x = 21.25;
      $_y = 50.0 + ( $line * 23.75 );

      $pdf->SetAbsXY( $_x, $_y );

      // TODO: Write the first name letter by letter

      $strlen = strlen( $learner['fname'] );
      for( $i = 0; $i < $strlen; $i++ ) {
        $char = substr( strtoupper( $learner['fname'] ), $i, 1 );

        $pdf->SetAbsXY( $_x+( $i * (81/18) ), $_y );

        $pdf->Cell ( (81.0/18), 5.0, $char, 0, 0, 'C' );

      }

      for( $i = $strlen; $i < 18; $i++ ) {
        $pdf->SetAbsXY( $_x+( $i * (81.0/18) ), $_y );

        $pdf->Cell ( (81.0/18), 5.0, ' ', 0, 0, 'C' );

      }

      $_y += 5.0;

      $pdf->SetAbsXY( $_x, $_y );

      $strlen = strlen( $learner['sname'] );
      for( $i = 0; $i < $strlen; $i++ ) {
        $char = substr( strtoupper( $learner['sname'] ), $i, 1 );

        $pdf->SetAbsXY( $_x+( $i * (81.0/18.0) ), $_y );

        $pdf->Cell ( (81.0/18.0), 5.0, $char, 0, 0, 'C' );

      }

      for( $i = $strlen; $i < 18; $i++ ) {
        $pdf->SetAbsXY( $_x+( $i * (81.0/18.0) ), $_y );

        $pdf->Cell ( (81.0/18.0), 5.0, ' ', 0, 0, 'C' );

      }


      $_y += 6.25;

      $pdf->SetAbsXY( $_x, $_y );

      $strlen = strlen( $learner['pemail'] );
      for( $i = 0; $i < $strlen; $i++ ) {
        $char = substr( $learner['pemail'], $i, 1 );

        $y_l = 0;
        $j = $i;

        if ( $i > 17 )
        {
          $y_l =5.0;
          $j = $i-18;
        }

        $pdf->SetAbsXY( $_x+( $j * (81.0/18.0) ), $_y + $y_l );

        $pdf->Cell ( (81.0/18.0), 5.0, $char, 0, 0, 'C' );

      }

      for( $i = $strlen; $i < 36; $i++ ) {
        $char = substr( $learner['email'], $i, 1 );

        $y_l = 0;
        $j = $i;

        if ( $i > 17 )
        {
          $y_l =5.0;
          $j = $i-18;
        }

        $pdf->SetAbsXY( $_x+( $j * 4.305 ), $_y + $y_l );

        $pdf->Cell ( 4.305, 5.0, "", 0, 0, 'C' );

      }

      $line ++;

    }

    if ( 0 == $page )  // TODO : Use constant here as well
    {
      $pdf->AddPage();
      $pages = $pdf->setSourceFile( get_stylesheet_directory().'/certs/learner_register.pdf' );
      $pg = $pdf->ImportPage( 1 );
      $pdf->useTemplate( $pg, 0, 0 );
      $line = 0;

      $page ++;

      $pdf->SetAbsXY( 280, 3 );

      $pdf->SetFontSize(7);

      $pdf->Cell ( 15.0, 10, sprintf( "%d of %d", $page, $last_page ), 0, 0, 'C' );

      $pdf->SetFontSize(9);


      $pdf->SetAbsXY( 94.0, 10.0 );

      $pdf->Cell ( 67.0, 5.0, "", 0, 0, 'L' );

      $pdf->SetAbsXY( 172.0, 10.0 );

      $pdf->Cell ( 65.0, 5.0, $venue_name, 0, 0, 'L' );


      $pdf->SetAbsXY( 94.0, 16.0 );

      $pdf->Cell ( 111.0, 5.0, $course->post_title, 0, 0, 'L' );

      $pdf->SetAbsXY( 216.5, 16.0 );

      $pdf->Cell ( 63.0, 5.0, $calendar_data['trainer']['name'], 0, 0, 'L' );


      $pdf->SetAbsXY( 98.5, 24.0 );

      //$date = strtok( "_", $master_meta['_calendar_data'][0]['start_date_time'] );
      //$time = strtok( "_" );

      //$date .= " ".str_replace( '-', ':', $time );

      // TODO: replace start date with date from final course object
      $pdf->Cell ( 40.0, 5.0, date( "jS F Y", strtotime( $calendar_data['start_date_time'] ) ) , 0, 0, 'L' );

      $pdf->SetAbsXY( 170.0, 24.0 );

      // TODO: replace finish date with date from final course object
      $pdf->Cell ( 30.0, 5.0, date( "jS F Y", strtotime( $calendar_data['end_date_time'] ) ), 0, 0, 'L' );

      $pdf->SetAbsXY( 220.0, 26.0 );

      $pdf->Cell ( 30.0, 5.0, $sylla_meta['duration'], 0, 0, 'L' );


      $pdf->SetAbsXY( 21.5, 196.0 );

      $pdf->Cell ( 6.0, 5.0, $num_attendees , 0, 0, 'L' );


      $print_footer = true;
    }


    // force print dialog
    $js = 'print(true);';

    // set javascript
    $pdf->IncludeJS($js);

    //Close and output PDF document 

    $pdf->Output( "learner-register.pdf", "I" );

}else{

echo "NOT AVAILABLE";

}

?>