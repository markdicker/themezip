<?php
/**
 * Order details
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/order-details.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 4.6.0
 */

defined( 'ABSPATH' ) || exit;


$order = wc_get_order( $order_id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.OverrideProhibited

if ( ! $order ) {
	return;
}

// check if booking type is personal and buyer not already added.

$business_or_personal = get_post_meta( $order_id, 'business_or_personal', true );

global $wpdb;

// $business_or_personal = get_post_meta( $order_id, 'business_or_personal', true );

$user_id = get_post_meta( $order_id, '_customer_user', true );
$customer = new WC_Customer( $user_id );

// if personal and not already added
if ( "personal" == $business_or_personal )
{
    // error_log( $business_or_personal );

    // error_log( "f-name = ".$customer->get_billing_first_name() );    
    // error_log( "s-name = ".$customer->get_billing_last_name() );    
    // error_log( "email  = ".$customer->get_email() );    
    // error_log( "phone  = ".$customer->get_billing_phone() );    

    // error_log( print_r( $order, true ) );

    //    Add the attendee

    $order_items = $order->get_items( );

    // error_log( print_r( $order_items, true ) ); 

    foreach( $order_items as $order_item )
    {
        // error_log( "item variation id = ".$order_item->get_variation_id() );

        $data = array
        (
            'fname' => $customer->get_billing_first_name(),
            'sname' => $customer->get_billing_last_name(),
            'pemail' => $customer->get_billing_email(),
            'phone' => $customer->get_billing_phone(),
            'cemail' => $customer->get_billing_email(),
            'course_id' => $order_item->get_variation_id(),
            'id' => 0,
            'price' => $order_item->get_total(),
        );
    
        // error_log( print_r( $data, true ) );

        // insert learner

        if ( $data['id'] == 0 )
        {
            $newlearner = array(
                'post_title'=> $data['fname']." ".$data['sname'],
                'post_name' => sanitize_title( $data['fname']." ".$data['sname'] ),
                'post_status' => 'publish',
                'post_parent' => $data['course_id'],
                'post_type' => 'learner',
                'guid' => "",
                'post_content' => ""/*print_r( $data, true )*/
            );

            $newlearner_id = wp_insert_post( $newlearner );

            $data['id'] = $newlearner_id;

            
            update_post_meta( $data['id'], '_woo_order', $order_id );


            update_post_meta( $data['id'], '_learner_details', $data );

            $user = get_user_by( "email", $data['pemail'] );
    
            // wp_die( "User = ". print_r( $user, true ) );
    
            if ( $user !== FALSE )
            {
                // disable sending Tutor emails
                add_filter( 'email_to_students.course_enrolled', 'return_false', 10, 2 );
                add_filter( 'email_to_teachers.a_student_enrolled_in_course', 'return_false', 10, 2 );
    
                // Add learner id to lids
                $uid = $user->ID;
    
                // error_log( "user id = ". $uid );
    
                update_post_meta( $data['id'], '_learner_details', $data );                   
    
                if( function_exists( 'tutils' ) )
                    tutils()->do_enroll( $data[ 'course_id' ], $order_id, $user_id );
                
                update_user_meta( $uid, '_l2c_'.$data[ 'course_id' ], $data['id'] );
    
                $lids = $wpdb->get_col('select post_id from '.$wpdb->postmeta.' WHERE meta_key = "_learner_details" AND meta_value like "%'.$data['pemail'].'%" ');
    
                // wp_die( 'select post_id from '.$wpdb->postmeta.' WHERE meta_key = "_learner_details" AND meta_value like "%'.$_orig_learner[0]['pemail'].'%" '.PHP_EOL.'<br />'. print_r( $lids, true ) );
    
                update_user_meta( $user_id, "lids", $lids ); 
    
                foreach( $lids as $_lid )
                {
                    // $order_id = get_user_meta( $_lid, "_woo_order" );
    
                    $learner_meta =  get_post_meta( $_lid, "_learner_details" );
    
                    if( function_exists( 'tutils' ) )
                        tutils()->do_enroll( $learner_meta[0][ 'course_id' ], $order_id, $uid );
    
                    update_user_meta( $uid, '_l2c_'.$learner_meta[0][ 'course_id' ], $_lid );
    
                    // update_user_meta( $uid, 'last_updated' , time() );
                    
                    // wp_set_current_user( $user_id, $userdata['user_login'] );
                    // wp_set_auth_cookie( $user_id );
                }
    
                // enable sending Tutor emails
                remove_filter( 'email_to_students.course_enrolled', 'return_false', 10 );
                remove_filter( 'email_to_teachers.a_student_enrolled_in_course', 'return_false', 10 );
    				// do_action( 'tutor_after_enrolled', $data[ 'course_id' ], $uid, $newlearner_id );
				$admin_email = get_option( 'admin_email' );
                
                //
                // Not sure what this is for
                //
                // $headers  = 'MIME-Version: 1.0' . "\r\n";
                // $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                // $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
                // $headers .= 'Reply-To: '.$admin_email. "\r\n";
				// wp_mail('ajithkumar072@gmail.com', 'test', "hello",$headers);

            }
    
            // $url = 'http://ec2-18-130-216-50.eu-west-2.compute.amazonaws.com/attendeepost';

            $postData =
                'wp_id='. ( $newlearner_id != null ? $newlearner_id : -1 ).
                '&fname='.$data['fname'].
                '&sname='.$data['sname'].
                '&pemail='.$data['pemail'].
                '&phone='.$data['phone'].
                '&cemail='.$customer->get_billing_email().
                '&course_id='.$data[ 'course_id' ];

            do_action( "siren_integrater_post_attendee", $postData );

            // $ch = curl_init( $url );
            // curl_setopt( $ch, CURLOPT_POST, 1);
            // curl_setopt( $ch, CURLOPT_POSTFIELDS, $postData );
            // curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
            // curl_setopt( $ch, CURLOPT_HEADER, 0);
            // curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

            // $response = curl_exec( $ch );


        } // end if

    }

    //print_r( $request );

    

}

// Process any supplied attendee names

if ( isset( $_POST['attendee_nonce'] ) && wp_verify_nonce( $_POST[ 'attendee_nonce' ], 'order_'.$_POST['order'] ) )
{
global $wpdb;
// print_r($_POST);die;
    // error_log( "order-details" );

	$order_id = $_POST['order'];

	foreach( $_POST['id'] as $course )
	{
		// $attendees = array ();

		foreach( $_POST['_fname'][$course] as $idx => $fname )
		{
			$data = array
			(
				'fname' => $fname,
				'sname' => $_POST['_sname'][$course][ $idx ],
				'pemail' => $_POST['_email'][$course][ $idx ],
				'phone' => $_POST['_phone'][$course][ $idx ],
                'cemail' => $customer->get_billing_email(),
				'course_id' => $course,
				'id' => $_POST['_lid'][$course][ $idx ],
				'price' => $_POST['price'][$course]
			);

			//print_r( $request );

			if ( !( "" == trim( $data['fname'] ) && "" == trim ($data['sname'] ) ) )
			{
				if ( $data['id'] == 0 )
				{
					$newlearner = array(
						'post_title'=> $data['fname']." ".$data['sname'],
						'post_name' => sanitize_title( $data['fname']." ".$data['sname'] ),
						'post_status' => 'publish',
						'post_parent' => $data['course_id'],
						'post_type' => 'learner',
						'guid' => "",
						'post_content' => ""/*print_r( $data, true )*/
					);

					$newlearner_id = wp_insert_post( $newlearner );

					$data['id'] = $newlearner_id;

					update_post_meta( $data['id'], '_woo_order', $order_id );
				}
                else
                    $newlearner_id = $data['id'];

				update_post_meta( $data['id'], '_learner_details', $data );

                $user = get_user_by( "email", $data['pemail'] );

			// 	// custom joining instruction mail
            //     $caldata = get_post_meta($course, "_calendar_data", true);

            //     $venue_obj = get_page_by_title( $caldata['venue']['name'], OBJECT, 'venues' );
            //     $map_url = get_post_meta($venue_obj->ID, 'map_url', true);
            //     $body= '';
            //     $body .= '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>Siren Training</title></head>';
            //     $body .= '<body leftmargin="0"  topmargin="0" offset="0">';
            //     $body .= '<div id="wrapper" dir="ltr">';
            //     $body .= '<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="font-family: Arial, sans-serif;">';
            //     $body .= '<tr><td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="600px">';
            //     $body .= '<tr><td align="left" valign="top"><div id="booking_header_image"><img src="http://www.sirentraining.co.uk/wp-content/uploads/2022/01/siren-logo.png" alt="Siren Training" style="border:none; display:inline; font-size:14px; font-weight:bold; height:auto; line-height:100%; outline:none; text-decoration:none; text-transform:capitalize"></div></td></tr>';
            //     $body .= '<tr><td align="right" valign="top"><div id="address"> </div></td></tr>';
            //     $body .= '<tr><td><br /><br /><p>Hi there,</p><p>We are pleased to confirm bookings on the following courses</p><h4>COURSE DETAILS</h4>';
            //     $body .= '<p>Course Name - '.$caldata['product']['name'].'</p>';
            //     $body .= '<p>Course Start Date - '.date('d-m-Y',strtotime($caldata['start_date_time'])).'</p>';
            //     $body .= '<p>Course End Date - '.date('d-m-Y',strtotime($caldata['end_date_time'])).'</p>';
            //     $body .= '<p>Location - '.$caldata['venue']['name'].'</p>';
            //     if($map_url != ''){
            //     $body .= '<p>View on Google Maps: <a href="'.$map_url.'" target="_blank">'.$map_url.'</a></p><br>';
            //     }
            //     if($caldata['mail_custom_template'] != ''){
            //     $body .= $caldata['mail_custom_template'].'<br>';
            //     }
            //     if($caldata['mhfa_mail_custom_template'] != ''){
            //         $body .= $caldata['mhfa_mail_custom_template'].'<br>';
            //         }
            //     $body .= '<h4>RESCHEDULING/ CANCELLATION POLICY</h4>';
            //     $body .= '<p>More than 7 days = Money Back</p>';
            //     $body .= '<p>48 Hours - 7 Days = 50% refund</p>';
            //     $body .= '<p>Less than 48 Hours = No refund</p><br>';
            //     $body .= '<h4>MORE INFORMATION</h4>';
            //     $body .= '<p>Visit the page to find more information on how to create your account and find your certificate: </p>';
            //     $body .= '<p><a href="https://www.sirentraining.co.uk/pdf-generator/joining/{{course.course_id}}">Joining Instruction</a></p><br>';
            //     $body .= '<h4>INVOICE</h4>';
            //     $body .= '<p>Can we please request that payment is made promptly to avoid any delays, or issues with the running of the course, or the issuing of certificates. Thank you!! </p><br>';
            //     $body .= '<p>Tel:0203 740 8088<br>';
            //     $body .= 'email: info@sirentraining.co.uk</p><br>';
            //     $body .= '<p>Kind regards,<br>';
            //     $body .= 'The Siren team</p>';
            //     $body .= '</td></tr></tbody></table></td></tr></tbody></table></div></body>';

            //     // print_r($body);
			// 	$admin_email = get_option( 'admin_email' );
			// 	$pemail = $data['pemail'];
            //     $headers  = 'MIME-Version: 1.0' . "\r\n";
            //     $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
            //     $headers .= 'From:SIREN TRAINING LTD <'.$admin_email .'>' . "\r\n";
            //     $headers .= 'Reply-To: '.$admin_email. "\r\n";
			// 	// $send = wp_mail($pemail, 'Joining Instruction', $body , $headers);
			// // echo "<pre>";print_r( $send  );echo "</pre>";


                // Send attendee info to new system

                // $url = 'http://ec2-18-130-216-50.eu-west-2.compute.amazonaws.com/attendeepost';

                $postData =
                    'wp_id='. ( $newlearner_id != null ? $newlearner_id : -1 ).
                    '&fname='.$fname.
                    '&sname='.$_POST['_sname'][$course][ $idx ].
                    '&pemail='.$_POST['_email'][$course][ $idx ].
                    '&phone='.$_POST['_phone'][$course][ $idx ].
                    '&cemail='.$customer->get_billing_email().
                    '&course_id='. $course;

                do_action( "siren_integrater_post_attendee", $postData );

                // $ch = curl_init( $url );
                // curl_setopt( $ch, CURLOPT_POST, 1);
                // curl_setopt( $ch, CURLOPT_POSTFIELDS, $postData );
                // curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
                // curl_setopt( $ch, CURLOPT_HEADER, 0);
                // curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

                // $response = curl_exec( $ch );

                if ( $user !== FALSE )
                {
                    // disable sending Tutor emails
                    add_filter( 'email_to_students.course_enrolled', 'return_false', 10, 2 );
                    add_filter( 'email_to_teachers.a_student_enrolled_in_course', 'return_false', 10, 2 );

                    // Add learner id to lids
                    $uid = $user->ID;

                    // error_log( "user id = ". $uid );

                    update_post_meta( $data['id'], '_learner_details', $data );                   

                    if( function_exists( 'tutils' ) )
                        tutils()->do_enroll( $data[ 'course_id' ], $order_id, $user_id );
                    
                    update_user_meta( $uid, '_l2c_'.$data[ 'course_id' ], $data['id'] );

                    $lids = $wpdb->get_col('select post_id from '.$wpdb->postmeta.' WHERE meta_key = "_learner_details" AND meta_value like "%'.$data['pemail'].'%" ');
    
                    // wp_die( 'select post_id from '.$wpdb->postmeta.' WHERE meta_key = "_learner_details" AND meta_value like "%'.$_orig_learner[0]['pemail'].'%" '.PHP_EOL.'<br />'. print_r( $lids, true ) );

                    update_user_meta( $uid, "lids", $lids ); 

                    foreach( $lids as $_lid )
                    {
                        // $order_id = get_user_meta( $_lid, "_woo_order" );

                        $learner_meta =  get_post_meta( $_lid, "_learner_details" );

                        if( function_exists( 'tutils' ) )
                            tutils()->do_enroll( $learner_meta[0][ 'course_id' ], $order_id, $uid );

                        update_user_meta( $uid, '_l2c_'.$learner_meta[0][ 'course_id' ], $_lid );

                        // update_user_meta( $uid, 'last_updated' , time() );
                        
                        // wp_set_current_user( $user_id, $userdata['user_login'] );
                        // wp_set_auth_cookie( $user_id );
                    }

                    // enable sending Tutor emails
                    remove_filter( 'email_to_students.course_enrolled', 'return_false', 10 );
                    remove_filter( 'email_to_teachers.a_student_enrolled_in_course', 'return_false', 10 );
				// do_action( 'tutor_after_enrolled', $data[ 'course_id' ], $uid, $newlearner_id );


                }
                // else
                //     error_log( "Did not locate user" , 0 );				

			}
		}
		//print_r( $attendees ) ;
	}

	unset( $_POST['attendee_nonce'] );

}


$order_items           = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
$show_purchase_note    = $order->has_status( apply_filters( 'woocommerce_purchase_note_order_statuses', array( 'completed', 'processing' ) ) );
$show_customer_details = is_user_logged_in() && $order->get_user_id() === get_current_user_id();
$downloads             = $order->get_downloadable_items();
$show_downloads        = $order->has_downloadable_item() && $order->is_download_permitted();

?>
<section style="border:2px solid #222222; color:#dd3061; padding:20px; text-align:center; margin:20px 0;">
    <p><h2>You can access your account by clicking <a href='<?php echo site_url( "dashboard" );?>'>'Customer Login'</a> in the right top corner.</h2></p>
</section>

<section class="woocommerce-order-details">
	<?php do_action( 'woocommerce_order_details_before_order_table', $order ); ?>

	<h2 class="woocommerce-order-details__title"><?php esc_html_e( 'Course details', 'woocommerce' ); ?></h2>

	<form method="post">

    <?php wp_nonce_field( 'order_'.$order->get_id(), 'attendee_nonce' ); ?>

	<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">

		<thead>
			<tr>
				<th class="woocommerce-table__product-name product-name"><?php esc_html_e( 'Product', 'woocommerce' ); ?></th>
				<th class="woocommerce-table__product-table product-total"><?php esc_html_e( 'Total', 'woocommerce' ); ?></th>
			</tr>
		</thead>

		<tbody>
			<?php
            
			do_action( 'woocommerce_order_details_before_order_table_items', $order );

			foreach ( $order_items as $item_id => $item ) {
                $item_meta = get_metadata( 'order_item', $item_id, "", "");

				$product = $item->get_product();

				$_tp = get_post_meta( $item->get_product_id(), '_tutor_product', 'no');

				if ( $_tp === 'yes' )
				{
					wc_get_template(
						'order/order-details-item-online-course.php',
						array(
							'order'              => $order,
							'item_id'            => $item_id,
							'item'               => $item,
							'show_purchase_note' => $show_purchase_note,
							'purchase_note'      => $product ? $product->get_purchase_note() : '',
							'product'            => $product,
						)
					);
	
				}
				else
				{
					wc_get_template(
						'order/order-details-item-classroom-course.php',
						array(
							'order'              => $order,
							'item_id'            => $item_id,
							'item'               => $item,
							'show_purchase_note' => $show_purchase_note,
							'purchase_note'      => $product ? $product->get_purchase_note() : '',
							'product'            => $product,
						)
					);
	
				}
			}

			do_action( 'woocommerce_order_details_after_order_table_items', $order );
			?>
		</tbody>

		<tfoot>
			<?php
			foreach ( $order->get_order_item_totals() as $key => $total ) {
				?>
					<tr>
						<th scope="row"><?php echo esc_html( $total['label'] ); ?></th>
						<td><?php echo ( 'payment_method' === $key ) ? esc_html( $total['value'] ) : wp_kses_post( $total['value'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
					</tr>
					<?php
			}
			?>
			<?php if ( $order->get_customer_note() ) : ?>
				<tr>
					<th><?php esc_html_e( 'Note:', 'woocommerce' ); ?></th>
					<td><?php echo wp_kses_post( nl2br( wptexturize( $order->get_customer_note() ) ) ); ?></td>
				</tr>
			<?php endif; ?>
		</tfoot>
	</table>

	</from>

	<?php do_action( 'woocommerce_order_details_after_order_table', $order ); ?>
</section>

<?php
if ( $show_customer_details ) 
{
	wc_get_template( 'order/order-details-customer.php', array( 'order' => $order ) );
}


function return_false( $a = null, $b = null )
{
    return "";
}
