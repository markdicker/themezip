<?php
/**
 * Order Item Details
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/order-details-item.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists('tutor_utils')) {
	function tutor_utils() {
		return new \TUTOR\Utils();
	}
}

if ( ! apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {
	return;
}

$item_meta = get_metadata( 'order_item', $item_id, "", "");

?>

<tr class="<?php /* echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'woocommerce-table__line-item order_item', $item, $order ) );*/ ?>">

	<td class="woocommerce-table__product-name product-name">
		<?php
		$is_visible        = $product && $product->is_visible();
		$product_permalink = apply_filters( 'woocommerce_order_item_permalink', $is_visible ? $product->get_permalink( $item ) : '', $item, $order );

		echo apply_filters( 'woocommerce_order_item_name', $product_permalink ? sprintf( '<a href="%s">%s</a>', $product_permalink, $item->get_name() ) : $item->get_name(), $item, $is_visible ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$qty          = $item->get_quantity();
		$refunded_qty = $order->get_qty_refunded_for_item( $item_id );

		if ( $refunded_qty ) {
			$qty_display = '<del>' . esc_html( $qty ) . '</del> <ins>' . esc_html( $qty - ( $refunded_qty * -1 ) ) . '</ins>';
		} else {
			$qty_display = esc_html( $qty );
		}

		echo apply_filters( 'woocommerce_order_item_quantity_html', ' <strong class="product-quantity">' . sprintf( '&times;&nbsp;%s', $qty_display ) . '</strong>', $item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order, false );

		$calendar_data = get_post_meta( $item_meta['_variation_id'][0], "_calendar_data", true );

		echo "<br /><small>".dateRange( strtotime( $calendar_data['start_date_time'] ), strtotime( $calendar_data['end_date_time'] ) )."</small>";

		// wc_display_item_meta( $item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order, false );
		?>
	</td>

	<td class="woocommerce-table__product-total product-total">
		<?php echo $order->get_formatted_line_subtotal( $item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</td>

</tr>
<tr>
	<td colspan="2">
		<input type='hidden' name='order' value='<?php echo $order->get_id(); ?>' />

		<input type='hidden' name='id[]' value='<?php echo $item_meta['_variation_id'][0]; ?>' />
		<input type="hidden" name="price[<?php echo $item_meta['_variation_id'][0]; ?>]" value="<?php echo (double)$item_meta['_line_total'][0] / (double)$item_meta['_qty'][0]; ?>" /> <!-- TODO: Use real values -->

		<?php

			$course_id = $item_meta['_variation_id'][0];
			//$course_data['id'] = $course_id;

			$learners = get_posts( array(
					'posts_per_page' => -1,
					'post_type' => 'learner',
					'post_status' => 'publish',
					'post_parent' => $course_id,
					'orderby' => 'ID',
					'order' => 'ASC',
					'nopaging' => true,
					'meta_query' => array(
    	                array(
                            'key' => '_woo_order',
                            'value' => $order->get_id()
        	            )
					),

				) ) ;

			$attendees = array();

			foreach( $learners as $learner )
			{
				$attendees[ ] = get_post_meta( $learner->ID, '_learner_details', true );
			}

		?>

		<p>Please provide the following details for all attendees for this course</p>

		<table class='attendees' id="<?php echo $item_meta['_variation_id'][0]; ?>" width="100%">
			<tbody>
				<tr>
					<td width="25%">First Name</td>
					<td width="25%">Surname</td>
					<td width="25%">Personal email</td>
					<td width="25%">Mobile Phone</td>
				</tr>

					<?php for ( $i=0; $i < $item['qty']; $i++ ) {

						if ( isset ( $attendees[ $i ]['id'] ) ) {
							$readonly = "readonly";
							$added = true;
						} else {
							$readonly = " ";
							$added = false;
						}

					?>
					<tr>
						<input type="hidden" name="_lid[<?php echo $item_meta['_variation_id'][0]; ?>][]" value="<?php echo ( $i < count( $attendees ) ? $attendees[ $i ]['id'] : "") ; ?>" />
						<td>
							<?php if ( $added ) : ?>
								<img style="float: left; left: -15px; position: absolute; top: 15px;" width="12" height="12" src="/wp-content/themes/siren-ct-0.1.15/img/accept-tick-icon-12.png" />
							<?php endif; ?>
							<input <?php echo $readonly; ?> name="_fname[<?php echo $item_meta['_variation_id'][0]; ?>][]" type="text" value="<?php echo ( $i < count( $attendees ) ? $attendees[ $i ]['fname'] : "") ; ?>" style="width:100%;" /></td>
						<td><input <?php echo $readonly; ?> name="_sname[<?php echo $item_meta['_variation_id'][0]; ?>][]" type="text" value=" <?php echo ( $i < count( $attendees ) ? $attendees[ $i ]['sname'] : "") ; ?>" style="width:100%;" /></td>
						<td><input <?php echo $readonly; ?> type="email" name="_email[<?php echo $item_meta['_variation_id'][0]; ?>][]" value="<?php echo ( $i < count( $attendees ) ? $attendees[ $i ]['pemail'] : "") ; ?>" style="width:100%;" /></td>
						<td><input <?php echo $readonly; ?> type="phone" name="_phone[<?php echo $item_meta['_variation_id'][0]; ?>][]" value="<?php echo ( $i < count( $attendees ) ? $attendees[ $i ]['phone'] : "") ; ?>" style="width:100%;" />
							<input type='hidden' name='_cemail[<?php echo $item_meta['_variation_id'][0]; ?>][]' value = '<?php echo $order->get_billing_email( 'edit' ); ?>' />
						</td>
					</tr>


					<?php } ?>

			</tbody>
		</table>
		<br />

		<?php if ( count( $attendees ) < $item_meta['_qty'][0] ) { ?>

		<p class="order-again">
			<input type="submit" class="button" value="Update Attendee List" />
		</p>

		<?php } ?>

	</td>
</tr>

