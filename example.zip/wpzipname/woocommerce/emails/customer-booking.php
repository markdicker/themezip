<?php
/**
 * Customer completed order email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/customer-completed-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woothemes.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     2.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @hooked WC_Emails::email_header() Output the email header
 */
//do_action( 'woocommerce_email_header', $email_heading, $email );

wc_get_template( 'emails/email-booking-header.php', array( 'email_heading' => $email_heading ) );

?>

<p>Hi there,</p>

<p>We are pleased to confirm bookings on the following courses</p>

<p>
<?php

$order_id = $email->object->get_id();

$items = $email->object->get_items();

$order = new WC_Order( $order_id );

$order->add_order_note( "Joining instructions email sent" );


debug( "items", $items );

foreach ( $items as $item ) {
	$product_qty = $item[ 'qty' ];
	$product_id = $item[ 'product_id' ];
	$product_name = $item[ 'name' ];
	$product_variation_id = $item[ 'variation_id' ];

	$cd = get_post_meta( $product_variation_id, "_calendar_data", true );

	$venueName=$cd['venue']['name'];
	$locationArray = explode('-', $venueName);
	$venueName = $locationArray[0];
	
	$venue_slug = $cd['venue']['key'];

 	echo $product_qty." x ".$product_name." - ".dateRange( strtotime( $cd['start_date_time'] ), strtotime( $cd['end_date_time'] ) )."<br />";
	
	if (preg_match('/ofsted/i', $product_name)) {
      $ofsted = "1";
  }
	
}

$venue_obj = get_page_by_path( $venue_slug, OBJECT, 'venues' );

$file_url_id = get_post_meta($venue_obj->ID, 'course_pdf', true);
$file_url = wp_get_attachment_url($file_url_id);

?>
</p>

<p>You can download your information pack <a href="<?php echo $file_url; ?>">here</a>
or alternativley please copy and paste this url into your browser <?php echo $file_url; ?></p>

<p>The pack contains all the details about the course and location, however if you require further information please don't hesitate to contact us at</p>

<p>Tel:0203 740 8088<br />email: info@sirentraining.co.uk</p>
<br />
<!--new code start-->
<?php if($ofsted == "1") { ?>
<b>Notes : </b><br />

<p>As a part of the OFSTED approved paediatric first aid course you will be required to complete an online learning platform prior to the day of the course.</p>

<p>The eLearning takes 6 hours to complete. Note that you can pause and resume the course whenever you please and access it from any device.</p>

<p>Please register for the eLearning by clicking the link: https://elearnhere.co.uk/sign-up/siren-training-blended-paediatric-course/?gid=2545&unCpNeg3k8dSc</p>

<p>When registering, please put your first name and last name in the "username" box. If your name has already been registered by another learner, please add a number at the end , e.g TinaLewis5</p>

<p>In the Training Provider box you MUST put "Siren"</p>

<p>Please ensure you complete this test by yourself. There will be further questions on the course regarding the subjects in the online package, therefore it will become very apparent if someone else has completed this on your behalf.</p>

<p>We look forward to meeting you on the course.</p>
<?php } ?>
<!--new code end-->

<p>Kind regards,<br />The Siren team</p>

<?php
/**
 * @hooked WC_Emails::order_details() Shows the order details table.
 * @hooked WC_Emails::order_schema_markup() Adds Schema.org markup.
 * @since 2.5.0
 */
 
//do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

/**
 * @hooked WC_Emails::order_meta() Shows order meta data.
 */
//do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

/**
 * @hooked WC_Emails::customer_details() Shows customer details
 * @hooked WC_Emails::email_address() Shows email address
 */
//do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

/**
 * @hooked WC_Emails::email_footer() Output the email footer
 */
//do_action( 'woocommerce_email_footer', $email );


wc_get_template( 'emails/email-booking-footer.php', array( 'email' => $email ) );
