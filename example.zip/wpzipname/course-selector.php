<?php 

function siren_course_selector( $atts, $content="" )
{
    $j_args = json_decode( $content, ARRAY_N );

    if ( is_array( $j_args ) )
    {
        $scs_cats = array_reduce( $j_args, function ( $b, $i ) {

            if ( $b == null )
                $b = array();

            $b[] = $i['cat'];

            return $b;

        }, null);
    }
    else
    {
        $scs_cats = array();
    }

    ob_start( );

    echo PHP_EOL."<script>
        var course_selector_cats = [".implode(",", $scs_cats)."];
    </script>".PHP_EOL.PHP_EOL;

    $GLOBALS['cf_areas'] = array( 
        'london' => 'London',
        'birmingham' => 'Birmingham',
        'manchester' => 'Manchester',
        'online' => 'Online/Virtual'
    );

    $GLOBALS['cf_cats'] = []; // $j_args;

    include (get_stylesheet_directory()."/templates/shortcodes/course-finder.php");

    return ob_get_clean();


    // return "<pre>".print_r( $j_args, true )."</pre>" ;
}

add_shortcode( "siren_course_selector", "siren_course_selector" );


add_action( 'wp_ajax_nopriv_siren_courses_by_location', 'siren_courses_by_location' );
add_action( 'wp_ajax_siren_courses_by_location', 'siren_courses_by_location' );
function siren_courses_by_location(  )
{
    
    global $wpdb, $post;
    
        // $post_id = $_POST['post_id'];

        $location = $_POST[ 'location' ];

        if ( isset( $_POST['sdate'] ) )
            $start_date = $_POST['sdate'];
        else
            $start_date = "";

        if ( isset( $_POST['edate'] ) )
            $end_date = $_POST['edate'];
        else
            $end_date = "";

        if ( isset( $_POST['courses'] ) )
        {
            $course_ids = $wpdb->get_results("SELECT distinct ID FROM ".$wpdb->prefix."posts WHERE post_type = 'product_variation' and post_parent in ( ".$_POST['courses']." ) ");

            if ( is_array( $course_ids ) )
            {
                $courses = array_reduce( $course_ids, function ( $initial, $item ) 
                {
                    $initial[] = $item->ID;

                    return $initial;
                
                }, array() );
            }
            else
            {
                $courses = array();
            }
        }
        else
            $courses = array();

        // error_log( "course Selector" );

        $args = array(
            'posts_per_page' => -1,
            'post_type' => 'product_variation',
            // 'post_parent' => $post_id,
            'nopaging' => true,
            'post_status' => 'publish',
            'meta_query' => array (
                array (
                    'relation' => 'AND',
                    '_calendar_data' => array (
                        'key' => '_calendar_data',
                        'compare' => 'EXISTS',
                        ),
                    '_venue_code' => array (
                        'key' => '_venue_code',
                        'value' => 'none',
                        'compare' => '!=',
                        ),
                    '_private_course' => array (
                        'key' => '_private_course',
                        'compare' => 'NOT EXISTS',
                        ),
                )
            )
        );     
    
        if ( $start_date != "" && $end_date != "" )
        {
            $args[ 'meta_query' ][ '_start_date' ] = array (
                'key' => '_start_date',
                'value' => array ( 
                        strtotime( $start_date ), 
                        strtotime( $end_date ) 
                    ),
                'type' => 'numeric',
                'compare' => 'BETWEEN'
            );

            $args[ 'orderby' ] = array (
                '_start_date' => 'ASC'
            );
        }

        // if ( !empty( $cats ) )
        //   $args['meta_query']['product_cat'] = array (
        //     'key' => 'product_cat',
        //     'value' => $cats ,
        //     'compare' => 'IN',
        //   );

        if ( !empty( $courses ) )
        {
            $args['post__in' ] = $courses;
        }

        $events = get_posts( $args );

        // error_log( print_r( $args, true ) );
    
        // error_log( count( $events ). " Courses Found" ) ;

        //   echo "<pre>".print_r( $CxVLondon, true )."</pre>";die;

        $tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

        $price_display_suffix  = get_option( 'woocommerce_price_display_suffix' );

        if ( $price_display_suffix )
        {
            $price_display_suffix = ' <small class="woocommerce-price-suffix">' . $price_display_suffix . '</small>';
        }

        // error_log( "events = ". print_r( $events, true ) );

        $CxVLondon = array();

        foreach( $events as $event )
        {
            $calendar_data = get_post_meta( $event->ID, '_calendar_data', true );

            // error_log( print_r( $calendar_data, true ) ) ;

            $venue_p = get_page_by_path( $calendar_data['venue']['key'] , OBJECT, 'venues' );

            // if ( trim ( $venue_p->post_title ) == "" )
            // {
                // error_log( print_r( $calendar_data['venue'], true ) );
            // }

            $venue_meta = get_post_meta( $venue_p->ID, "_venues_meta", true );

            if ( strlen( trim( $venue_meta['area'] ) ) == 0 )
                $venue_meta['area'] = 'london';

            if ( strlen($venue_meta['area']) > 0 && ( $venue_meta['area'] !== $location && $venue_meta['area'] !== 'online' )) 
            {
                // error_log( $venue_meta['area']. " != ".$location );
                continue;
            }

            //error_log( $venue_meta['area']. " == ".$location );

            /* Why? */
            global $wpdb;

            $get_gallery_main = $wpdb->get_results("SELECT menu_order FROM ".$wpdb->prefix."posts WHERE ID = '".$venue_p->ID."' ");

            $venue_order_num = $get_gallery_main[0]->menu_order;

            $product_data = $event;

            $product = wc_setup_product_data( $product_data );

            if ( get_total_stock( $product ) == 0 )
                continue;
            
            $date = date( "Ymd", strtotime( $calendar_data[ 'start_date_time' ] ) );

            if ( !isset ( $CxVLondon[$venue_order_num] ) )
                $CxVLondon[$venue_order_num] = $calendar_data['venue'];

            if ( $product->is_in_stock() )
                $booking_link = sprintf( "<a href='%s' class='button'>Book</a>", $product->add_to_cart_url() );//$booking_link = sprintf( "<a href='%s' class='button'>Book</a>", site_url ($product->add_to_cart_url() ) );
            else
                $booking_link = "Sorry, course fully booked";

            $sale_price = $product->get_sale_price();

            $regular_price = $product->get_regular_price();

            $price = 'incl' === $tax_display_mode ? wc_get_price_including_tax( $product ) : wc_get_price_excluding_tax( $product );

            if ( isset( $venue_meta['address'] ) )
                $CxVLondon[$venue_order_num]['meta'] = $venue_meta;
            else
                $CxVLondon[$venue_order_num]['meta']['address'] = array( 'address' => '', 'phone' => '', 'email' => '', 'url' => '' );

            $CxVLondon[$venue_order_num]['name'] = $venue_p->post_title;
            if ( !isset( $calendar_data['_alt_seo_text'] ) )
                $calendar_data['_alt_seo_text'] = "";

            $CxVLondon[$venue_order_num]['area'] = $venue_meta['area'];

            $CxVLondon[$venue_order_num]['courses'][] = array (
                'p' => $event,
                'm' => $calendar_data,
                'sa' => get_total_stock( $product ),
                'regularprice' => $regular_price,
                'saleprice' => $sale_price,
                'price' => $price,
                'booking' => $booking_link,
            );
        }

        ksort($CxVLondon);

        // error_log( print_r( $CxVLondon, true ) );

        $venuArr = '';

        $old_street_link = "https://tinyurl.com/4ht3t8cs";
        $london_bridge_link = "https://tinyurl.com/y9r6aeec";
        $london_bridge_se1_1hr_link = "https://goo.gl/maps/r9zvy9vHHt5dCjiE8";
        $london_bridge_se1_9hh_link = "https://maps.app.goo.gl/vHJ1p7vuAikFoFyZ9";

        // error_log( count( $CxVLondon ) );

        foreach( $CxVLondon as $venue ) :

            // error_log( print_r( $venue, true ) );

            $venuArr .= "<div class='venue-name'>".$venue['name'];
	
            if ( strstr( strtolower( $venue['name'] ), "online" ))
                $venuArr .= "<a href='".get_permalink( $venue['courses'][0]['p']->post_parent )."' target='blank'>CLICK HERE FOR MORE DETAILS</a>";
            elseif ( strstr( strtolower( $venue['name'] ), "virtual" ))
                $venuArr .="";
            else
            {
                if ( strstr( strtolower( $venue['name'] ), "old street" ) )
                    $venuArr .= "<a href='".$old_street_link."' target='blank'>CLICK HERE TO GET DIRECTIONS</a>";
                elseif ( strstr( strtolower( $venue['name'] ), "london bridge - se1 9hh" ) )
                    $venuArr .= "<a href='".$london_bridge_se1_9hh_link."' target='blank'>CLICK HERE TO GET DIRECTIONS</a>";
                elseif ( strstr( strtolower( $venue['name'] ), "london bridge - se1 1hr" ) )
                    $venuArr .= "<a href='".$london_bridge_se1_1hr_link."' target='blank'>CLICK HERE TO GET DIRECTIONS</a>";
                elseif ( strstr( strtolower( $venue['name'] ), "london bridge" ) )
                    $venuArr .= "<a href='".$london_bridge_link."' target='blank'>CLICK HERE TO GET DIRECTIONS</a>";
                else
                    $venuArr .= "<a href='https://maps.google.com/maps/search/?api=1&query=".str_replace( " ", '+', preg_replace( "/\r\n|\r|\n/", "+", $venue['meta']['address'] ))."' target='blank'>CLICK HERE TO GET DIRECTIONS</a>";
            }
	 
			$venuArr .= "</div>";

            $venuArr .= '<table cellspacing="0" cellpadding="0" class="courses-table table table-striped table-condensed cf" width="100%">';
            $venuArr .= '<thead class="cf">';
            $venuArr .= '<tr>';
            // $venuArr .= '<th data-firstsort="asc">Course Title</th>';
            // $venuArr .= '<th>Venue</th>';
            $venuArr .= '<th style="width:30%;">Course Date</th>';
            // $venuArr .= '<th>Time</th>';
            $venuArr .= '<th style="width:30%;">Price</th>';
            $venuArr .= '<th style="width:30%;">Seats</th>';
            $venuArr .= '<th style="width:10%;"></th>';
            $venuArr .= '</tr>';
            $venuArr .= '</thead>';
            $venuArr .= '<tbody>';           

            if ( !empty($venue['courses'] ) )
            {
                $lines = 0;

                $row_class='' ;

                foreach( $venue['courses'] as $course ) :

                    if ( $lines == 5 )
                    {
                        $venuArr .= '<tr class="show-button-row show-'.$venue['key'].'"><td colspan="4" align="center"><span class="show-button" data-key="'.$venue['key'].'"><i class="fa fa-plus"></i> Show More Dates</span></td></tr>';
                        
                        $row_class=' class="hidden-'.$venue['key'].'" style="display:none;" ';                        
                    }

                    $venuArr .= '<tr '.$row_class.'>';
                    // $venuArr .= '<td data-title="Course Title" >'.$course['m']['product']['name'].'</td>';
                    // $venuArr .= '<td data-title="Venue" >'.$course['m']['venue']['name']."<p>".$course['m']['_seo_text'].'</p></td>';
                    $venuArr .= '<td data-title="Course Date" >'.dateRange( strtotime( $course['m']['start_date_time'] ), strtotime( $course['m']['end_date_time'] ) ).'</td>';
                    // $venuArr .= '<td data-title="Time">'.date( "H:i", strtotime( $course['m']['start_date_time'] ) ).'</td>';
                    $venuArr .= '<td data-title="Price" >';
                    
                        if($course['saleprice'])
                        {
                            $venuArr .= '<span class="product-sale-price">'.( "" != $course['saleprice'] ? sprintf( "%4.2lf", $course['saleprice']) . $price_display_suffix : "" ).'</span>';
                        }
                        else 
                        {
                            $venuArr .= '<span>'.( "" != $course['price'] ? sprintf( "%4.2lf", $course['price']) . $price_display_suffix : "" ).'</span>';                        
                        }
                        
                    $venuArr .= '</td>';
                    $venuArr .= '<td data-seatremaining="'.( 0 != $course['sa'] ? $course['sa'] : "" ).'" data-title="Seats Remaining">'.( 0 != $course['sa'] ? $course['sa'] : "" )."<span class='cro_text'>".$course['m']['_seo_text'].'</span></td>';
                    $venuArr .= '<td style="text-align:right" data-title="">'.$course['booking'].'</td>';
                    $venuArr .= '</tr>';

                    $lines++;

                    // break;
                endforeach;

                if ( $lines > 5 )
                {
                    $venuArr .= '<tr class="hide-button-row hide-'.$venue['key'].'"><td colspan="4" align="center"><span class="hide-button" data-key="'.$venue['key'].'"><i class="fa fa-minus"></i> Show Fewer Dates</span></td></tr>';
                }
    
            }else{

                $venuArr .= '<tr><td colspan="4" >No Record Found</td></tr>';

            }
                        
            $venuArr .= '</tbody></table>';


        endforeach;

    if ( "" == $venuArr )
        $venuArr = '<h2>No Courses Found</h2>';

    echo json_encode($venuArr);
    wp_die();  //die();

// echo json_encode($course_venuname_list);
// wp_die();  //die();
}


add_action( 'wp_ajax_nopriv_siren_course_names_by_ids', 'siren_course_names_by_ids' );
add_action( 'wp_ajax_siren_course_names_by_ids', 'siren_course_names_by_ids' );
function siren_course_names_by_ids(  )
{
    
    global $wpdb, $post;
    
        // $post_id = $_POST['post_id'];

        if ( isset( $_POST['courses'] ) )
        {
            $courses = explode( ",", $_POST['courses'] );
        }
        else
        {
            $courses = array();
        }

    // error_log( "course Selector" );

    $args = array(
        'posts_per_page' => -1,
        'post_type' => 'product',
        'post__in' => $courses
        );     
        
    $events = get_posts( $args );

    // error_log( print_r( $args, true ));

    $course_post_list = array();

    foreach( $courses as $course ) 
    {
        foreach( $events as $course_post ) 
        {
            if ( $course == $course_post->ID )
            {
                $course_post_list[] = '<option value="'.$course_post->ID.'">'.$course_post->post_title.'</option>';
            }
        }
    }

    $venuArr = "";

    echo json_encode( $course_post_list );
    wp_die();  //die();

// echo json_encode($course_venuname_list);
// wp_die();  //die();
}

