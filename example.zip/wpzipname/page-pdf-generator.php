<?php

$filename="test.pdf";

// header("Content-type: application/pdf");
// header("Content-Transfer-Encoding: Binary");
// header("Content-disposition: attachment;filename='".$filename."'");
// ob_clean();
// flush();

// die ( "Exit" );

// ob_start();

//error_reporting(E_STRICT | E_ALL);
//ini_set('display_errors',1);

// wp_die( print_r( get_option( 'active_plugins' ), true ) );


$pdf_doc = get_query_var( 'pdf' );

// wp_die( $pdf_doc );

$_id = get_query_var( '_id' );

$_id2 = get_query_var( '_id2' );

$_syllabus = get_query_var('syllabus');


switch( $pdf_doc )
{
    case 'register' :
        create_learner_register( $_id );
        break;
    // case 'certificate' :
    //   create_new_certificate( $_id );
    //   break;
    case 'welcome' :
        create_welcome_pack( $_id, $_syllabus );
        break;
    case 'test':
        create_new_certificate( $_id );
        break;
    case 'certificate' :
    case 'learner-certificate' :
        create_certificate( $_id );
        break;
    case 'joining' :
        create_joining_instructions( $_id, $_syllabus );
        break;
    default:
        echo "<h1>Error</h1>";
        echo "<h2>[".$pdf_doc."] is unkown</h2>";
    break;
}

 function create_new_register ( $course_id ) {
    $data = [];
    $data['master'] = get_post( $course_id );
    $data['master_meta'] = get_post_meta( $data['master']->ID );
    $data['course'] = get_post( $data['master']->post_parent );
    $data['assigned_trainer'] = get_page_by_path( get_post_meta( $data['course']->ID, '_assigned_trainer', true ), OBJECT, 'trainers' );
    $data['trainer_meta'] = get_post_meta( $data['assigned_trainer']->ID, '', true );
    $data['course_syllabus'] = get_page_by_path( get_post_meta( $data['course']->ID, '_course_syllabus', true ), OBJECT, 'course_syllabus' );
    $data['course_meta'] = get_post_meta( $data['course_syllabus']->ID, '', true );
    $data['assigned_venue'] = get_page_by_path( get_post_meta( $data['course']->ID, '_assigned_venue', true ), OBJECT, 'venues' );
    $data['venue_meta'] = get_post_meta( $data['assigned_venue']->ID, '', true );

    // get_post_meta does this if you request an individual meta entry - but we got them all and so have to do it ourselves
    $data['sylla_meta'] = unserialize( $data['course_meta']['_syllabus_meta'][0] );
    $data['calendar_data'] = unserialize( $data['master_meta']['_calendar_data'][0] );

    if ( $data['assigned_venue'] != NULL )
        $data['venue_name'] = $data['assigned_venue']->post_title;
    else
        $data['venue_name'] = $data['calendar_data']['venue']['name'];

    if ( $data['assigned_trainer'] != NULL )
        $data['trainer_name'] = $data['assigned_trainer']->post_title;
    else
        $data['trainer_name'] = $data['calendar_data']['trainer']['name'];

    $data['learners'] = get_posts( array(
      'posts_per_page' => -1,
      'post_type' => 'learner',
      'post_status' => 'publish',
      'post_parent' => $course_id,
      'orderby' => 'ID',
      'order' => 'ASC',
      'nopaging' => true
    ) ) ;

    $data['attendees'] = array();

    foreach( $data['learners'] as $learner )
    {
      $data['attendees'][ ] = get_post_meta( $learner->ID, '_learner_details', true );
    }

    $data['func'] = 'register';

    $filename = "learner-register.pdf";

    $ch = curl_init(bloginfo('site').'/siren/');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    $curl_errno = curl_errno($ch);
    $curl_error = curl_error($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($response, 0, $header_size);
    $body = substr($response, $header_size);

    curl_close($ch);

    if ($curl_errno > 0) {
            echo "cURL Error ($curl_errno): $curl_error\n";
    } else {
            header('Location: '.bloginfo('site').'/siren/certs/' . $filename);
            //echo $response;
    }

    exit();

 }


  function create_learner_register( $course_id )
  {
	
      header('Location: '.get_stylesheet_directory_uri().'/pdf.php?course_id='.$course_id);
  	
	}

  function create_new_certificate( $attendee_id ) 
  {
				
			header('Location: '.get_stylesheet_directory_uri().'/pdf.php?attendee_id='.$attendee_id);
		
  }

  function create_certificate( $attendee_id )
  {
    global $wpdb;
    // // get_post_meta does this if you request an individual meta entry - but we got them all and so have to do it ourselves
    // $sylla_meta = unserialize( $course_meta['_syllabus_meta'][0] );

    // print_r( $attendee_id );

    // if attendee_id starts with a J then it came from JotForm

    $serial_suffix = "";

    if ( substr( $attendee_id, 0, 1 ) ===  'J' )
    {
        $attendee_id = substr( $attendee_id, 1 );

        
        // See if this learner has been imported
        
        $learner_query = array(
          'post_type' => 'learner',
          'meta_query' => array(
            array(
              'key'     => '_jotform_id_'.$attendee_id,
              'value'   => 'imported',
              'compare' => 'EXISTS'
              )
              )
            );
            
            $learners = get_posts( $learner_query );
            
            
        if ( empty( $learners) )
        {
            $serial_suffix = "J";
            // This learner has not been imported or added when submitted so use the Acuiti data
            
            $results = $wpdb->get_results( "SELECT LearnerName,EnterCourseCode,LearnerSurname,LearnerNumber FROM Attendeeinfo WHERE LearnerID = ".$attendee_id);
        
            if ( empty( $results ) )
            exit( 500 );
            
            $attendee_name = $results[0]->LearnerName." ".$results[0]->LearnerSurname;
            
            $course_id = $results[0]->EnterCourseCode;
            
        }
        else
        {
          // Should only be 1 so use the first
          
          $attendee_id = $learners[0]->ID;
          
          
          $attendee = get_post_meta( $attendee_id, "_learner_details", true );
          
          // wp_die( "<pre>". $attendee_id.PHP_EOL.print_r( $attendee, true )."</pre>" );

          if ( !is_array( $attendee  ) )
            exit( 500 );
          
          $attendee_name = $attendee['fname']." ".$attendee['sname'];
          
          
          $parents = get_post_ancestors( $attendee_id );

            // debug( 421, $parent );

            $id = $parents[ 0 ];  // First parent is our variation

            // debug (425, $id );   

            $course_id = $id; //$attendee['course_id'];  
        }

    }
    else
    {        
        $attendee = get_post_meta( $attendee_id, "_learner_details", true );
        
        if ( !is_array( $attendee  ) )
            exit( 500 );

        $attendee_name = $attendee['fname']." ".$attendee['sname'];

        $parents = get_post_ancestors( $attendee_id );

        // debug( 421, $parent );
        
        $id = $parents[ 0 ];  // First parent is our variation

        // debug (425, $id );   


        $course_id = $id; //$attendee['course_id'];
    }

    // print_r( $parents );

    // print_r( $attendee );

    $calendar_data = get_post_meta( $course_id, '_calendar_data', true );

    // print_r(  $calendar_data );

    $course_syllabus = get_page_by_path( $calendar_data['syllabus']['key'], OBJECT, 'course_syllabus' );

    // print_r(  $course_syllabus );

    $sylla_meta = get_post_meta( $course_syllabus->ID, '_syllabus_meta', true );

    // print_r(  $sylla_meta );

    $cert_path = get_attached_file( $sylla_meta['cert_id'] );

    // print_r(  $cert_path );

    $pdf = new FPDI('P', 'mm', 'A4' );

    $pdf->setPrintHeader( false );
    $pdf->setPrintFooter( false );

    // set document information
    $pdf->SetCreator( 'Siren Training Ltd' );
    $pdf->SetAuthor( 'Mark Dicker' );
    $pdf->SetTitle( "Certificate of completion" );
    $pdf->SetSubject( "" );
    $pdf->SetKeywords( 'private');
    $pdf->SetAutoPageBreak( false, 0 );

    // // change font size
    $pdf->SetFontSize(20);

    // $num_attendees = count( $learners );

    $pdf->AddPage();
    if ( $cert_path != "" )
    {
      $pages = $pdf->setSourceFile( $cert_path );
      $page = $pdf->ImportPage( 1 );
      $pdf->useTemplate( $page, 0, 0 );
    }

    // if ( isset( $attendee['source']) && $attendee['source'] == 'JF' )
    // {
    //     $serial_suffix = 'J';
    //     $attendee_id = $attendee['jf_id'];
    // }


    $serial = $sylla_meta['code'].date( "Ymd", strtotime( $calendar_data['end_date_time'] ) ).sprintf( '%08d', $attendee_id ).$serial_suffix;

    $pdf->SetFontSize(16);
    $pdf->SetAbsXY( 14, 232.0 );
    $pdf->Cell ( 100.0, 20, $serial, 0, 0, 'L' );  // TODO : use correct serial

    $pdf->setColor( 'text', 0, 41, 200 );
    $pdf->setFont( "times", 'I' );

    $pdf->SetFontSize(20);

    $pdf->SetAbsXY( 0, 95.0 );
    $pdf->Cell ( 210.0, 20, $attendee_name , 0, 0, 'C' );

    $pdf->setFont( "times" );
    $pdf->SetFontSize(20);

    $pdf->SetAbsXY( 0, 171.0 );
    $pdf->Cell ( 210.0, 20, date( "jS F Y", strtotime( $calendar_data['end_date_time'] ) ) , 0, 0, 'C' );
    $pdf->Cell ( 220.0, 20, $calendar_data['end_date_time']  , 0, 0, 'C' );


    $pdf->AddPage();
    if ( $cert_path != "" )
    {
      //$pages = $pdf->setSourceFile( get_stylesheet_directory().'/certs/EFAW-cert.pdf' );
      $page = $pdf->ImportPage( 2 );
      $pdf->useTemplate( $page, 0, 0 );
    }

    // force print dialog
    $js = 'print(true);';

    // set javascript
    $pdf->IncludeJS($js);

    //Close and output PDF document

    $filename = "Siren_Training-".$serial.".pdf";

    // De-space the filename
    $filename = str_replace(  " ", "-", $filename  );

    header("Content-type: application/pdf");
    header("Content-Transfer-Encoding: Binary");
    header("Content-Disposition: attachment;filename=".$filename."");

    echo $pdf->Output( $filename, "S" );

  }

  //function create_welcome_pack( $order_id )
  //{
  //    $order = wc_get_order( $order_id );
  //
  //    if ( $order === false )


  //        exit(500);
  //
  //    $items =  $order->get_items();
  //
  //
  //    $upload_dir = wp_upload_dir();
  //    //$upload_dir = $upload_dir['path'];
  //
  //    debug( "uploads", $upload_dir );
  //
  //    $pdf = new FPDI( 'P', 'mm', 'A4' );
  //
  //    $pdf->setPrintHeader( false );
  //    $pdf->setPrintFooter( false );
  //
  //    // set document information
  //    $pdf->SetCreator( 'Siren Training Ltd' );
  //    $pdf->SetAuthor( 'Mark Dicker' );
  //    $pdf->SetTitle( "Course Details" );
  //    $pdf->SetSubject( "" );
  //    $pdf->SetKeywords( 'private');
  //    $pdf->SetAutoPageBreak( false, 0 );
  //
  //    //$pdf->SetFont( 'Times', '', 12 );
  //
  //    // // change font size
  //    $pdf->SetFontSize(20);
  //
  //    $num_attendees = count( $learners );
  //
  //    foreach( $items as $item )
  //    {
  //        $pdf->AddPage();
  //
  //        $pdf->Rect( 5, 5, 200, 287, 'F', null, array( 245, 245, 255 ) );

  //
  //        $product_qty = $item[ 'qty' ];
  //        $product_id = $item[ 'product_id' ];
  //        $product_name = $item[ 'name' ];
  //        $product_variation_id = $item[ 'variation_id' ];
  //
  //        $cd = get_post_meta( $product_variation_id, "_calendar_data", true );
  //
  //        $course_syllabus = get_page_by_path( $cd['syllabus']['key'], OBJECT, 'course_syllabus' );
  //
  //        $sylla_meta = get_post_meta( $course_syllabus->ID, '_syllabus_meta', true );
  //
  //        $assigned_venue = get_page_by_path( $cd['venue']['key'], OBJECT, 'venues' );
  //
  //        $venue_meta = get_post_meta( $assigned_venue->ID, '_venues_meta', true );
  //
  //        //die( "<pre>". print_r(  $cd['product']['name'], true )."</pre>" );
  //
  //
  //        // echo $product_qty." x ".$product_name." - ".dateRange( strtotime( $cd['start_date_time'] ), strtotime( $cd['end_date_time'] ) )."<br />";
  //
  //        $pdf->SetFontSize(20);
  //        $pdf->SetAbsXY( 10, 10 );
  //        $pdf->Cell ( 190.0, 20, $cd['product']['name'], 0, 0, 'C' );  // TODO : use correct serial
  //
  //        $pdf->SetFontSize(16);
  //        $pdf->SetAbsXY( 10, 20 );
  //        $pdf->Cell ( 190.0, 20, dateRange( strtotime( $cd['start_date_time'] ), strtotime( $cd['end_date_time'] ) ), 0, 0, 'C' );  // TODO : use correct serial
  //
  //
  //        if ( $img = get_option( 'woocommerce_email_header_image' ) ) {
  //         //   echo '<img src="' . esc_url( $img ) . '" alt="' . get_bloginfo( 'name', 'display' ) . '" />';
  //
  //            $img = str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $img );
  //
  //            debug( "img", $img );
  //
  //            $pdf->Image( $img, 10, 267, 0, 20 );
  //
  //        }
  //
  //        $pdf->SetFontSize(8);
  //        $pdf->SetAbsXY( 85, 266 );
  //        $pdf->Cell ( 115.0, 4, "SIREN TRAINING LTD", 0, 0, 'L' );
  //
  //        $pdf->SetFontSize(8);
  //        $pdf->SetAbsXY( 85, 271 );
  //        $pdf->Cell ( 115.0, 4, "New North House, Lower Ground Floor, 202/208 New North road, London, N1 7BJ", 0, 0, 'L' );
  //
  //        $pdf->SetFontSize(8);
  //        $pdf->SetAbsXY( 85, 276 );
  //        $pdf->Cell ( 115.0, 4, "0203 740 8088", 0, 0, 'L' );
  //
  //        $pdf->SetFontSize(8);
  //        $pdf->SetAbsXY( 85, 281 );
  //        $pdf->Cell ( 115.0, 4, "www.sirentraining.co.uk", 0, 0, 'L' );
  //
  //
  //        $pdf->SetFontSize(12);
  //        //$pdf->SetAbsXY( 20, 30 );
  //        $content = $assigned_venue->post_content;
  //        $content = apply_filters('the_content', $content);
  //        $content = str_replace(']]>', ']]&gt;', $content);
  //
  //        $pdf->writeHTMLCell ( 190, 100, 10, 40, $content, 0);
  //
  //        $pdf->Rect( 10, 175, 70, 86.5, 'F', null, array( 255, 255, 255 ) );
  //
  //        $pdf->SetFontSize(18);
  //        $pdf->SetAbsXY( 12, 177 );
  //        $pdf->Cell ( 50.0, 6, "Location" , 0, 0, 'L' );
  //
  //        // $pdf->SetFontSize(14);
  //        // $pdf->SetAbsXY( 17, 138 );
  //        // $pdf->Cell ( 50.0, 6, $assigned_venue->post_title , 0, 0, 'L' );
  //
  //        $pdf->SetFontSize(12);
  //        // $pdf->SetAbsXY( 17, 138 );
  //        $pdf->writeHTMLCell ( 90, 45, 12, 186, nl2br( $venue_meta['address'] ), 0);
  //
  //        $pdf->SetFontSize(10);
  //        $pdf->SetAbsXY( 12, 236 );
  //        $pdf->Cell ( 50.0, 6, $venue_meta['phone'] , 0, 0, 'L' );
  //
  //        $pdf->SetFontSize(10);
  //        $pdf->SetAbsXY( 12, 242 );
  //        $pdf->Cell ( 50.0, 6, $venue_meta['email'] , 0, 0, 'L' );
  //
  //        $pdf->SetFontSize(10);
  //        $pdf->SetAbsXY( 12, 248 );
  //        $pdf->Cell ( 50.0, 6, $venue_meta['url'] , 0, 0, 'L' );
  //
  //
  //        $pdf->Rect( 85, 175, 115, 80, 'F', null, array( 255, 255, 255 ) );
  //
  //        $map_address = urlencode(preg_replace( "/\r\n|\r|\n/", ", ", $venue_meta['address'] ) );
  //
  //        $img = 'https://maps.googleapis.com/maps/api/staticmap?center='. $map_address .'&size=640x480&markers=color:blue%7CA:'. $map_address .'&key=AIzaSyCZ9xtBrNPc4dPukLyrYK80SpqSNY7aYzs';
  //
  //        $pdf->Image( $img, 85, 175, 115, 86.5, "", "", "T", 1, 300, 'T', false, false, 0, "CM" );
  //
  //
  //
  //
  //
  //    }
  //
  //    $pdf->Output( "Course_Details.pdf", "I" );
  //
  //
  //}

  function create_welcome_pack( $venue, $syllabus )
  {
	
	$venue_post = get_page_by_path($venue, OBJECT, 'venues');
	$venue_post_id = $venue_post->ID;
	$get_venue_pdf = get_post_meta($venue_post_id,'course_pdf',true);
	$venue_attach_url = wp_get_attachment_url($get_venue_pdf);
	
	if(!empty($venue_attach_url)){
		wp_redirect($venue_attach_url,$status = 302);
	}else{
		echo "PDF not available";
		exit(404);
	}

    /*$upload_dir = wp_upload_dir();
    $upload_dir = $upload_dir['baseurl']."/courses/";

    $assigned_venue="";
    $productName="";

    if (is_object($order)) {
      $items = $order->get_items();

      foreach($items as $item) {
        $product_variation_id = $item[ 'variation_id' ];
        $cd = get_post_meta( $product_variation_id, "_calendar_data", true );
        $productName=$cd['product']['key'];
        break;
      }
    } else {
      $cd = get_post_meta( $course_id, "_calendar_data", true );
      $productName=$cd['product']['key'];
    }

    $filename="";

    if($productName=='2-days-paediatric-first-aid' ||$productName=='1-day-paediatric-first-aid' ){
      switch ($venue) {
        case 'clapham':
        case 'clapham-(sw4)':
        case 'clapham-paediatric-ofsted-approved':
        case (preg_match('/clapham/i', $venue) ? true : false):
        $filename='PaediatricClapham.pdf';
        break;
        case 'old-street':
        case 'old-street-(n1)':
        case 'Old%20Street%20-%20Paediatric%20(OFSTED%20approved)%20(N1)':
        case (preg_match('/old/i', $venue) ? true : false):
        $filename='PaediatricFirstAid-OldStreet.pdf';
        break;
        case 'london-bridge':
        case 'london-bridge-(se1)':
        case 'LONDON%20BRIDGE%20(SE1)':
        case (preg_match('/london/i', $venue) ? true : false):
        $filename='LondonBridge.pdf';
        break;

      }
    }else{

      switch ($venue) {
        case 'clapham':
        case 'clapham-(sw4)':
        case 'clapham-paediatric-ofsted-approved':
        case (preg_match('/clapham/i', $venue) ? true : false):
        $filename='PaediatricClapham.pdf';
        break;
        case 'waterloo':
        case 'waterloo-(se1)':
        case (preg_match('/waterloo/i', $venue) ? true : false):
        $filename='Waterloo.pdf';
        break;
        case 'old-street':
        case 'old-street-(n1)':
        case 'Old%20Street%20-%20Paediatric%20(OFSTED%20approved)%20(N1)':
        case (preg_match('/old/i', $venue) ? true : false):
        if (preg_match('/marshal/i', $syllabus)) {
          $filename='OldStreet.pdf';
        } elseif (preg_match('/weekend/i', $venue)) {
          $filename='OldStreetWeekend.pdf';
        } else {
          $filename='OldStreetFirstAid.pdf';
        }
        break;
        case 'london-bridge':
        case 'london-bridge-(se1)':
        case 'LONDON%20BRIDGE%20(SE1)':
        case (preg_match('/london/i', $venue) ? true : false):
        $filename='LondonBridge.pdf';
        break;
        case 'heathrow':
        case 'heathrow-(tw5)':
        case 'heathrow-(parking available)(tw5)':
        case (preg_match('/heathrow/i', $venue) ? true : false):
        $filename='Heathrow.pdf';
        break;
        case 'hammersmith':
        case 'hammersmith-(w6)':
        case (preg_match('/hammersmith/i', $venue) ? true : false):
        $filename='Hammersmith.pdf';
        break;
        case 'southwark':
        case 'southwark-(se1)':
        case (preg_match('/southwark/i', $venue) ? true : false):
        $filename='Southwark.pdf';
        break;
        case 'royal-victoria-docks':
        case 'royal-victoria-docks-(e16)':
        case (preg_match('/victoria/i', $venue) ? true : false):
        $filename='RoyalVictoriaDocks.pdf';
        break;
        case 'birmingham-city-centre':
        case (preg_match('/city/i', $venue) ? true : false):
        $filename='Birmingham-City-Centre.pdf';
        break;
        case 'birmingham-b90':
        case (preg_match('/solihull/i', $venue) ? true : false):
        $filename='Birmingham-Solihull.pdf';
        break;
        case 'shepherds-bush':
        case (preg_match('/shepherds/i', $venue) ? true : false):
        $filename='Shepherds-Bush.pdf';
        break;
        case (preg_match('/kent/i', $venue) ? true : false):
        $filename='Kent.pdf';
        break;
				case (preg_match('/euston/i', $venue) ? true : false):
        $filename='Euston.pdf';
        break;


      }

      if(!empty($filename)){
        $file_url=$upload_dir.$filename;
        wp_redirect($file_url,$status = 302);
      }else{
        echo "PDF not available";
        exit(404);
      }



    }*/


  }

 //  added by mark
function create_pdf($attendee_id){
	    global $wpdb;
	    $results = $wpdb->get_results( "SELECT LearnerName,EnterCourseCode,LearnerSurname,LearnerNumber FROM Attendeeinfo WHERE LearnerID = ".$attendee_id);
	    $result = $wpdb->get_results( "SELECT ws1r3np_postmeta.post_id FROM ws1r3np_postmeta INNER JOIN ws1r3np_posts ON ws1r3np_postmeta.post_id = ws1r3np_posts.ID WHERE ws1r3np_postmeta.meta_key='_learner_details' AND  ws1r3np_postmeta.meta_value LIKE '%".$results[0]->LearnerNumber."%' AND  ws1r3np_posts.post_status='publish' AND ws1r3np_posts.post_type='learner' AND ws1r3np_posts.post_parent='".$results[0]->EnterCourseCode."'");
	    //$result = $wpdb->get_results( "SELECT ws1r3np_postmeta.post_id FROM ws1r3np_postmeta INNER JOIN ws1r3np_posts as post1 ON ws1r3np_postmeta.post_id = post1.ID INNER JOIN ws1r3np_posts as post2 ON post2.ID = post1.post_parent  WHERE ws1r3np_postmeta.meta_key='_learner_details' AND  ws1r3np_postmeta.meta_value LIKE '%".$results[0]->LearnerClientEmail."%' AND  post1.post_status='publish' AND post1.post_type='learner' AND date(post2.post_date) = '2019-03-22'");
	    $blanks = array('OFSTED' => 'OFSTED-PAED-BLANK-2.pdf', 'EFAW' => 'EFAW-cert-1.4.php', 'PLS-BLANK' => 'PLS-BLANK-1.pdf', 'PLS BLANK' => 'PLS-BLANK-1.pdf', 'Safe Moving _ Handling-pdffiller' => 'Safe-Moving-_-Handling-pdffiller.pdf', 'Fire Marshal cert' => 'Fire-Marshal-Cert.pdf', 'EPFA BLANk (2)' => 'EPFA-BLANk-2.pdf', 'FAW BLANK (2)' => 'FAW-BLANK-2.pdf', 'EFAW-BLANK' => 'EFAW-BLANK-1.pdf', 'ANAPHYLAXIS BLANK' => 'ANAPHYLAXIS-BLANK-1.pdf', 'BLS BLANK' => 'BLS-BLANK-1.pdf', 'FA REFRESH cert-pdffiller' => 'FA-REFRESH-cert-pdffiller.pdf', 'AED Fixed Date' => 'AED-Fixed-Date-1.pdf', 'Basic Paediatric First Aid template' => 'Basic-Paediatric-First-Aid-template.pdf', 'Fire Awareness Certificate' => 'Fire Awareness Certificate.pdf');
	   //echo '<pre>';print_r($result);die;
        $attendee_firstname = $results[0]->LearnerName ;
	    $attendee_surename = $results[0]->LearnerSurname;
		
		$data = [];

        $data['attendee'] = get_post_meta( $result[0]->post_id, "_learner_details", true );

        $data['course_id'] = $data['attendee']['course_id'];

        $data['calendar_data'] = get_post_meta( $data['course_id'], '_calendar_data', true );

        $data['course_syllabus'] = get_page_by_path( $data['calendar_data']['syllabus']['key'], OBJECT, 'course_syllabus' );

        $data['sylla_meta'] = get_post_meta( $data['course_syllabus']->ID, '_syllabus_meta', true );

        $data['cert_path'] = $data['sylla_meta']['cert_label'];

        $data['serial'] = $data['sylla_meta']['code'].date( "Ymd", strtotime( $data['calendar_data']['end_date_time'] ) ).sprintf( '%08d', $attendee_id );

        $data['func'] = 'certificate';



        //$headers = array( 'Content-type: application/x-www-form-urlencoded' );



        $filename = "Siren_Training-".$data['serial'].".pdf";

				

				$cert_path = $data['cert_path'];
				$serial = $data['serial'];

				//$attendee_firstname = $data['attendee']['fname'];

				//$attendee_surename = $data['attendee']['sname'];

				$calendar_data_end_date = $data['calendar_data']['end_date_time'];





				$pdf = new FPDI('P', 'mm', 'A4' );

				$pdf->setPrintHeader( false );

				$pdf->setPrintFooter( false );

				

				// set document information

				$pdf->SetCreator( 'Siren Training Ltd' );

				$pdf->SetAuthor( 'Mark Dicker' );

				$pdf->SetTitle( "Learner Certificates" );

				$pdf->SetSubject( "" );

				$pdf->SetKeywords('private');

				$pdf->SetAutoPageBreak( false, 0 );

				

				$pdf->SetFontSize(20);

				$pdf->AddPage();

				

				$pages = $pdf->setSourceFile(get_stylesheet_directory().'/certs/'.$blanks[$cert_path]);

				$page = $pdf->ImportPage( 1 );

				$pdf->useTemplate( $page, 0, 0 );

				

				$pdf->SetFontSize(16);

				$pdf->SetXY( 14, 232 );

				$pdf->Cell( 100, 20, $serial, 0, 0, 'L' );

				$pdf->SetTextColor( 0, 41, 200 );

				$pdf->SetFont('Helvetica','B',20);

				

				$pdf->SetXY( 0, 95 );

				$pdf->Cell ( 210, 20, $attendee_firstname." ".$attendee_surename , 0, 0, 'C' );

				$pdf->SetFont('Helvetica','B',20);

				

				$pdf->SetXY( 0, 171 );

				$pdf->Cell ( 210.0, 20, date( 'jS F Y', strtotime( $calendar_data_end_date ) ) , 0, 0, 'C');
				$pdf->AddPage();

				

				$page = $pdf->ImportPage( 2 );

				$pdf->useTemplate( $page, 0, 0 );

				

				$print_footer = true;

				

				$filename = "Siren_Training-".$serial.".pdf";

				

				$pdf->Output( $filename, "F" );

				

				exit();

  }


function create_joining_instructions( $course_id, $syllabus )
{
    global $theme_twig;

    $calendar_data = get_post_meta( $course_id, '_calendar_data', true );

    // $course_syllabus = get_page_by_path( $calendar_data['syllabus']['key'], OBJECT, 'course_syllabus' );
    $course_syllabus = $calendar_data['syllabus']['key'];

    $course_venue = $calendar_data['venue']['key'];

    $site_url = site_url( '' );

    $assigned_venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

    if ($assigned_venue != null) 
    {
        $location = $assigned_venue->post_title;
    } 
    else 
    {
        $location = $calendar_data['venue']['name'];
    }

    // echo "<pre>";

    // print_r( $calendar_data );

    // print_r( $course_syllabus );

    // print_r( $assigned_venue );

    // print_r( $location );
    
    // echo "</pre>".PHP_EOL;

    $pdf = new FPDI('P', 'mm', 'A4' );

    // $pdf = new FPDI('P', 'mm', 'A4' );

    $pdf->setPrintHeader( false );

    $pdf->setPrintFooter( false );
    
    $pdf->SetMargins(10, 15, 10, true); // set the margins 

    // set document information

    $pdf->SetCreator( 'Siren Training Ltd' );

    $pdf->SetAuthor( 'Mark Dicker' );

    $pdf->SetTitle( "Joining Instructions" );

    $pdf->SetSubject( "" );

    $pdf->SetKeywords('private');

    $pdf->SetAutoPageBreak( true, 15 );

    $pdf->SetFontSize(20);

    $pdf->AddPage();

    $pdf->Image('https://www.sirentraining.co.uk/wp-content/uploads/2014/03/LOGO1-copy.png', 10, 10, 50, '', '', 'https://www.sirentraining.co.uk', 'T', false, 300, 'C');

    $pdf->SetFontSize(16);

    $pdf->SetXY( 10, 23 );
    
    $pdf->SetTextColor( 0xdd, 0x03, 0x41 );

    $pdf->Cell( 190, 20, "Joining Instructions", 0, 0, 'C' );

    $pdf->SetFontSize(12);

    // $pdf->SetXY( 10, 40 );
    
    $pdf->SetTextColor( 0, 0, 0 );

    $fsd = date( "d M Y H:i", strtotime( $calendar_data['start_date_time'] ));
    $fed = date( "d M Y H:i", strtotime( $calendar_data['end_date_time'] ));

    $ofsted = "";

    if (preg_match('/ofsted/i',  $calendar_data['product']['name'])) 
    {
        $ofsted = "<p><b>HOW CAN I ACCESS THE ONLINE LEARNING PLATFORM?</b></p>
            <p>As a part of the OFSTED approved paediatric first aid course you will be required to complete an online learning platform prior to the day of the course.</p>
            <p>The eLearning takes 6 hours to complete. Note that you can pause and resume the course whenever you please and access it from any device. We highly recommend using a laptop for successful course completion and a seamless experience.  </p>
            <p>You would have now already created an account upon making your booking. With your chosen username and password, please log in and go to your profile. In here you will see 'enrolled courses' on the left hand side of the page. Once clicked, you will see the link to proceed with your online learning. </p>
            <p>Please follow the link </p>
            <p><a href='https://www.sirentraining.co.uk/dashboard'>https://www.sirentraining.co.uk/dashboard</a>/</p>
            <p>Fill in your credentials: email address and password.</p>
            <p>If you've forgotten your password or can not access the e- Learning platform you need to change your password.</p>
            <p>Please watch this short video below on how you can change your password. Also, it is very important that you watch this video and learn how to navigate through the e-Learning platform.</p>
            <p><a href='https://youtu.be/35kQjoZQ0UU'>https://youtu.be/35kQjoZQ0UU</a></p>
            <p>Booking on behalf of someone else:</p>
            <p>Please let us know the full details of the attendee you are booking. (Full name and email address). They will then receive a separate email from us at 'Siren Training' - email: info@sirentraining.co.uk.  Please double check all folders, including your junk folder.</p>
            <p>Please ensure you complete this test by yourself. There will be further questions on the course regarding the subjects in the online package, therefore it will become very apparent if someone else has completed this on your behalf.</p>
            <p>We look forward to meeting you on the course.</p>
            </br>";
    }

    $pdf->WriteHTMLCell( 190, 100, 10, 50, "<h4>COURSE DETAILS</h4>
        <p>Course Name - {$calendar_data['syllabus']['name']}</p>
            <p>Course Start Date - {$fsd}</p>
            <p>Course End Date - {$fed}</p> 
        <p>Location - {$location}</p>
        <h4>INFORMATION PACK</h4>
        <p>You can download your information pack <a href=\"https://www.sirentraining.co.uk/pdf-generator/welcome/{$course_venue}/?syllabus={$course_syllabus}\">here</a> 
        or alternatively please copy and paste this url into your browser <a href='https://www.sirentraining.co.uk/pdf-generator/welcome/{$course_venue}/?syllabus={$course_syllabus}'>https://www.sirentraining.co.uk/pdf-generator/welcome/{$course_venue}/?syllabus={$course_syllabus}</a></p>

        <p>The pack contains all the details about the course and location, however if you require further information please don't hesitate to contact us at</p>

        <p>Tel:0203 740 8088<br />
        email: info@sirentraining.co.uk</p>
                
        {$ofsted}

        <p>Kind regards,<br />
        The Siren team</p>" );

    // // $pdf->SetFont('Helvetica','B',20);

    // $pdf->AddPage( );

    // force print dialog
    $js = 'print(true);';

    // set javascript
    $pdf->IncludeJS($js);

    //Close and output PDF document

    $filename = "course-".$course_id."-joining-instructions.pdf";

    // De-space the filename
    $filename = str_replace(  " ", "-", $filename  );

    header("Content-type: application/pdf");
    header("Content-Transfer-Encoding: Binary");
    header("Content-Disposition: attachment;filename=".$filename."");

    echo $pdf->Output( $filename, "S" );

}
