<?php

header( "Content-Type: text/javascript");


error_reporting( E_ALL & ~E_NOTICE & ~E_DEPRECATED );

include_once ( '../../../wp-config.php' );
include_once ( ABSPATH . 'wp-admin/includes/admin.php' );
include_once ( ABSPATH . 'wp-includes/functions.php' );

// if ( ! defined( 'ABSPATH' ) ) {
// 	exit; // Exit if accessed directly
// }

$default_feedback_qs = 'feedback_questions	[
    {
    "type": "rating",
    "name": "_course_rating",
    "title": "How did you find the course",
    "isRequired": true,
    "rateMax": 9
    },
    {
    "type": "rating",
    "name": "_trainer_rating",
    "title": "How did you find the course instructor",
    "isRequired": true,
    "rateMax": 9
    },
    {
    "type": "rating",
    "name": "_venue_rating",
    "title": "Please rate the choice of course venue",
    "isRequired": true,
    "rateMin":1,
    "rateMax": 9
    },
    {
    "type": "rating",
    "name": "_hygiene_rating",
    "title": "Please rate the cleanliness of the quipment",
    "isRequired": true,
    "rateMin":1,
    "rateMax": 9
    },
    {
    "type": "comment",
    "name": "_comments",
    "title": "Please use this space to tell us where we could improve or if there was anything that we did well."
    }';

echo 'var feedback_questions='.stripslashes( get_option( 'feedback_questions', $default_feedback_qs )).';';