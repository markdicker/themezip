<?php

//
// Template Name: Trainer portal
//

global $twig;

wp_enqueue_style( 'custom-styles', get_template_directory_uri() . '/css/main.css' );
wp_enqueue_style( 'trainer-styles', get_template_directory_uri() . '/css/trainer.css' );

get_header();

    // $toolbar = $twig->loadTemplate( 'trainer/_portal.html' );

    // echo $toolbar->render(  );

    echo $twig->render( 'trainer/_portal.html' );

?>

<h3>Here </h3>

<?php

get_footer();

?>
