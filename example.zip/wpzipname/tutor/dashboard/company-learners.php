<?php



$user_id = get_current_user_id();

$context = wp_generate_uuid4();

if ( isset( $_GET[ 'page' ] ) )
{
    $page = $_GET[ 'page' ];    
}
else
{
    $page = 1;
}

?>

<script>var learners_context = '<?php echo $context; ?>'; </script>

<h3><?php _e('Your Learners', 'siren') ?></h3>

<div id="overlay" style="display:none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>

<div class="tutor-dashboard-content-inner">

<div class="sort-bar">
    <!-- <select name="sort-option" id="sort-option" class="sort-option">
        <option value="learner-a">Learner (Asc.)</option>
        <option value="learner-d">Learner (Desc.)</option>
        <option value="course-a">Course (Asc.)</option>
        <option value="course-d">Course (Desc.)</option>
        <option value="date-a">Date (Newest)</option>
        <option value="date-d">Date (Oldest)</option>
        <option value="certificate">Certificate</option>
    </select> -->
    <input id='search-box' type='text' name='search-box' class='search-box' value='' placeholder='Search Query'/>
    <input id='search-action' type='submit' name='sort-bar-action' class='action' value='Search'/>
    
</div>

<?php

if ( $user_id )
{
    
    $sort_by = 'date';
    $order_by= 'desc';

    // $lids = get_company_lids( $user_id );

    $table = siren_get_learner_table( $user_id, $context, 1, $sort_by, $order_by ); // get first page

    echo "<script>var curPage = 1; var lastPage = ".$table['page_count']."; </script>";

    // echo "<pre>".print_r( $my_courses, true )."</pre>";

    // print_r( $table );

    if ( $table['count'] != 0 ) :
        // Display first page

        ?>

        <table class='table learners'>
            <thead>
                <tr>
                    <!-- <th scope='col'>lid</th> -->
                    <th scope='col'>Learner<i id="name" class="fa fa-fw fa-sort" data-column="name" data-dir="desc"></i></th>
                    <th scope='col'>Course<i id="course" class="fa fa-fw fa-sort" data-column="course"></i></th>
                    <th scope='col'>Date<i id="date" class="fa fa-fw fa-sort-desc" data-column="date"></i></th>
                    <th scope='col'>Certificate<i id="cert" class="fa fa-fw fa-sort" data-column="cert"></i></th>
                </tr>
            </thead>    

            <tbody>

        <?php

        foreach( $table['data'] as $learner )
        {
          // print_r($learner);
            $start_date = date( "D, d M Y H:i", strtotime( $learner['start_date_time'] ) );   // date( "Y-m-d H:i:s", 
            $end_date = date( "D, d M Y H:i", strtotime( $learner['end_date_time'] ) );

            ?>
                <tr>
                    <!-- <td><?php echo $learner['lid']; ?></td> -->
                    <td><?php echo $learner['name']; ?></td>
                    <td><?php echo $learner['course'];  ?><br/></td>
                    <td><?php echo $learner['fdate']; ?></td>
                    <td><?php if ( $learner['certificate'] ) : ?>
                            <a href = "<?php echo site_url( "/pdf-generator/certificate/".$learner['id'] ); ?>">Download</a>
                        <?php endif; ?></td>
                </tr>

            <?php

        }

        ?>

            </tbody>
            <tfoot>
                <tr>
                    <!-- <th scope='col'>lid</th> -->
                    <td colspan="4" class='table-footer' scope='col'><i class="fa fa-arrow-left disabled-option" data-dir="back" ></i> Page <span class='current'>1</span> of <span class='last-page'><?php echo $table['page_count'] ; ?></span> <i class="fa fa-arrow-right" data-dir="forward"></i></td>
                </tr>
            </tfoot>    

        </table>

        <?php
        wp_reset_postdata();
    else:
        echo __('You don\'t have any learners', 'tutor');
    endif;
}


?>
</div>