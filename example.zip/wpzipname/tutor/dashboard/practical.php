<?php 


?>

<h3><?php _e('Practical Courses', 'siren'); ?></h3>

<div class="tutor-dashboard-content-inner">

    <?php /*
    <div class="tutor-dashboard-inline-links">
        <ul>
            <li class="active"><a href="<?php echo tutor_utils()->get_tutor_dashboard_page_permalink('enrolled-courses'); ?>"> <?php _e('All Courses', 'tutor'); ?></a> </li>
            <li><a href="<?php echo tutor_utils()->get_tutor_dashboard_page_permalink('enrolled-courses/active-courses'); ?>"> <?php _e('Active Courses', 'tutor'); ?> </a> </li>
            <li><a href="<?php echo tutor_utils()->get_tutor_dashboard_page_permalink('enrolled-courses/completed-courses'); ?>">
					<?php _e('Completed Courses', 'tutor'); ?> </a> </li>
        </ul>
    </div>
    */ 

    $user_id = get_current_user_id();

    // print_r( $user_id );

    if ( $user_id )
    {

        $my_courses = siren_get_classroom_courses_by_user( $user_id );

        // echo "<pre>".print_r( $my_courses, true )."</pre>";

        if ($my_courses && $my_courses->have_posts()):
            ?>

            <table class='table'>
                <thead>
                    <tr>
                        <th scope='col'>Course</th>
                        <th scope='col'>Date</th>
                        <th scope='col'>Certificate</th>
                    </tr>
                </thead>    

                <tbody>

            <?php
    
            while ($my_courses->have_posts()):

                $my_courses->the_post();

                $calendar_data = get_post_meta( get_the_ID(), '_calendar_data'. false );

                if ( is_array( $calendar_data ) )
                    $calendar_data = $calendar_data[0];
                
                // echo "<pre>".print_r( $calendar_data, true )."</pre>";

                $lid = get_usermeta( $user_id, '_l2c_'.get_the_ID(). false );

                $learner_details = get_post_meta( $lid, "_learner_details", true );

                //echo "<pre>".print_r( $learner_details, true )."</pre>";

                $start_date = date( "D, d M Y H:i", strtotime( $calendar_data['start_date_time'] ) );   // date( "Y-m-d H:i:s", 
                $end_date = date( "D, d M Y H:i", strtotime( $calendar_data['end_date_time'] ) );

                $product = get_post( $product_id );

                ?>
                
                <!-- <div class="siren-classroom-course-wrap siren-classroom-course-<?php the_ID(); ?>">
                    <div class="siren-classroom-course-left">
                        <div class="siren-classroom-course-content">
                            <h3><?php echo $calendar_data['product']['name']; //$product->post_title; //the_title(); ?></h3>
                        </div>
                        <div class="siren-classroom-course-date" style="float:break;" ><?php echo dateRange(strtotime($calendar_data['start_date_time']), strtotime($calendar_data['end_date_time']))." ".date( "H:i", strtotime( $calendar_data['start_date_time']) )." - ".date( "H:i", strtotime( $calendar_data['end_date_time']) ) ; ?></div>
                    </div>
                    <div class="siren-classroom-course-right">
                        <?php if ( isset( $learner_details['passed'] ) && $learner_details['passed'] ) : ?>
                            <?php if ( isset( $learner_details['course_id'] ) ) : ?>
                            
                                <a href = "<?php echo site_url("/feedback/".$learner_details['course_id']."/".$lid); //echo site_url( "/pdf-generator/certificate/".$lid ); ?>">Download</a>
                        
                            <?php endif; ?>    
                        <?php endif; ?>
                    </div>

                </div> -->
 
                    <tr>
                        <td><?php echo $calendar_data['product']['name']; //$product->post_title; //the_title(); ?>
                        <?php if ( isset( $learner_details['course_id'] ) ) : ?>
                            <div><a href="<?php echo site_url( "/pdf-generator/joining/".$learner_details['course_id'] ); ?>""> Joining Instructions</a></div></td>
                        <?php else: ?>
                            <div></div></td>
                        <?php endif; ?>
                        <td><?php echo dateRange(strtotime($calendar_data['start_date_time']), strtotime($calendar_data['end_date_time']))."<p><small>".date( "H:i", strtotime( $calendar_data['start_date_time']) )." - ".date( "H:i", strtotime( $calendar_data['end_date_time']) )."</small></p>" ; ?></td>
                        <td><?php if ( isset( $learner_details['passed'] ) && $learner_details['passed'] ) : ?>
                            <?php if ( isset( $learner_details['course_id'] ) ) : ?>
                                <a href = "<?php echo site_url("/feedback/".$learner_details['course_id']."/".$lid); // echo site_url( "/pdf-generator/certificate/".$lid ); ?>">Download</a>
                            <?php endif; ?>
                        <?php endif; ?></td>
                    </tr>

                <?php
            endwhile;

            ?>

                </tbody>
            </table>

            <?php
            wp_reset_postdata();
        else:
            echo __('You haven\'t taken any courses', 'tutor');
        endif;
    }

    ?>

</div>

