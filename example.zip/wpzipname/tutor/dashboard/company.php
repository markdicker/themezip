<?php

$user_id = get_current_user_id();

// wp_die( print_r( $user, true ) );

$team_count = count( siren_get_company_ids_by_user( $user_id ) ) - 1; // Do not iunclude current user in counbt 


$learner_count = count( get_company_lids( $user_id ) );

$bookings_count = count( siren_get_orders_by_company( $user_id ) );

?>

<h3><?php _e('Overview', 'siren') ?></h3>

<div class="tutor-dashboard-content-inner">

    <div class="tutor-dashboard-info-cards">
        <a href="<?php echo site_url( "dashboard/company-team" ); ?>"  class="tutor-dashboard-info-card">
            <p>
                <span><?php _e('Team Members', 'tutor'); ?></span>
                <span class="tutor-dashboard-info-val"><?php echo esc_html($team_count); ?></span>
            </p>
        </a>
        <a href="<?php echo site_url( "dashboard/company-learners" ); ?>" class="tutor-dashboard-info-card">
            <p>
                <span><?php _e('Learners', 'tutor'); ?></span>
                <span class="tutor-dashboard-info-val"><?php echo esc_html($learner_count); ?></span>
            </p>
        </a>
        <a href="<?php echo site_url( "dashboard/company-bookings" ); ?>" class="tutor-dashboard-info-card">
            <p>
                <span><?php _e('Bookings', 'tutor'); ?></span>
                <span class="tutor-dashboard-info-val"><?php echo esc_html($bookings_count); ?></span>
            </p>
        </a>
    </div>
</div>
