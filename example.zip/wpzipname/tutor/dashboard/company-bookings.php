<?php

$user_id = get_current_user_id();

$bookings = siren_get_orders_by_company( $user_id );

// wp_die( print_r( $bookings, true ) ) ;

?>
<h3><?php _e('Booking History', 'siren') ?></h3>

<div class="tutor-dashboard-content-inner">
    <div class="responsive-table-wrap">
        <table>
            <thead>
                <tr>
                    <th><?php _e('ID', 'tutor'); ?></th>
                    <th><?php _e('Courses', 'tutor'); ?></th>
                    <th><?php _e('Amount', 'tutor'); ?></th>
                    <th><?php _e('Status', 'tutor'); ?></th>
                    <th><?php _e('Date', 'tutor'); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach ($bookings as $order){
                $wc_order = wc_get_order($order->ID);
                ?>
                <tr>
                    <td>#<?php echo $order->ID; ?></td>
                    <td>
                        <?php
                        $courses = tutor_utils()->get_course_enrolled_ids_by_order_id($order->ID);
                        if (tutor_utils()->count($courses)){
                            foreach ($courses as $course){
                                echo '<p>'.get_the_title($course['course_id']).'</p>';
                            }
                        }
                        else
                        {
                            foreach ( $wc_order->get_items() as $item_id => $item ) {
                                $variation_id = $item->get_variation_id();

                                $calendar_data = get_post_meta( $variation_id, '_calendar_data'. false );

                                if ( is_array( $calendar_data ) )
                                    $calendar_data = $calendar_data[0];

                                if( "" == $calendar_data['product']['name'] )
                                {
                                    $prod = $item->get_product();

                                    echo "<p>".get_the_title( $prod )."</p>";
                                }
                                else
                                    echo "<p>".$calendar_data['product']['name']."</p>";
                            }
                        }
                        ?>
                        <div><a href="<?php echo site_url( "/pdf-generator/joining/".$variation_id ); ?>""> Joining Instructions</a></div>
                    </td>
                    <td><?php echo tutor_utils()->tutor_price($wc_order->get_total()); ?></td>
                    <td><?php echo tutor_utils()->order_status_context($order->post_status); ?></td>

                    <td>
                        <?php echo date_i18n(get_option('date_format'), strtotime($order->post_date)) ?>
                    </td>
                </tr>
                <?php
            }
        ?>
            </tbody>
        </table>
    </div>
</div>    
