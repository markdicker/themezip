<?php

$user_id = get_current_user_id();


?>
<h3><?php _e('Team', 'siren') ?></h3>

<div class="tutor-dashboard-content-inner">

<?php

if ( $user_id ) 
{
    $team = siren_get_company_ids_by_user( $user_id );

    // $lids = get_company_lids( $user_id );
    
    // echo "<pre>".print_r( $team, true )."</pre>";

    if ( count( $team ) > 1 ) :
        ?>

        <table class='table'>
            <thead>
                <tr>
                    <th scope='col'>Name</th>
                    <th scope='col'>Email</th>
                </tr>
            </thead>    

            <tbody>

        <?php

        foreach( $team as $lid ):

            if ( $lid == $user_id )
                continue;

            $member = get_user_by( 'ID', $lid );

            // echo "<pre>".print_r( $member, true )."</pre>";

            ?>
                      
                <tr>
                    <td><?php echo $member->data->display_name; ?></td>
                    <td><?php echo $member->data->user_email; ?></td>
                </tr>

            <?php
        endforeach;

        ?>

            </tbody>
        </table>

        <?php
        wp_reset_postdata();
    else:
        echo __('You don\'t have a team', 'tutor');
    endif;
}


?>

</div>
