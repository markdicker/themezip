<?php



$user_id = get_current_user_id();

$context = wp_generate_uuid4();

if ( isset( $_GET[ 'page' ] ) )
{
    $page = $_GET[ 'page' ];
}
else
{
    $page = 1;
}

?>

<script>var learners_context = '<?php echo $context; ?>'; </script>

<h3><?php _e('Bookers', 'siren') ?></h3>

<div id="overlay" style="display:none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>

<div class="tutor-dashboard-content-inner">
  <?php echo do_shortcode('[booker_course_calendar /]'); ?>
</div>
