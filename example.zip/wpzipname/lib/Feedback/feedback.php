<?php

/* 
 * 
 * Feedback class
 *
 */

 class Feedback extends StdClass {

    private $questions;    

    public function __construct( $feedback_questions = array() ) 
    {
        $this->$questions = $feedback_questions;
    }

    public function render( )
    {
        foreach( $this->$questions as $question )
        {
            switch ( $question['type'] )
            {
                case 'rating' :
                    self::render_rating( $question );
                    break;
                case 'comment' :
                    self::render_comment( $question );
                    break;
                case 'text' :
                    self::render_text( $question );
                    break;
            }
            echo "<br />";
        }
    }

    private function render_rating( $question )
    {
        $rateMin = ( isset( $question['rateMin']) ? $question['rateMin'] : 1 );
        $rateMax = ( isset( $question['rateMax']) ? $question['rateMax'] : 10 );

        echo "<p><h3>".$question['title']."</h3>";
        echo '<table cellpadding="2" cellspacing="2" border="0" width="100%">
            <thead>
                <tr>';
    
        for ( $i = $rateMin; $i <= $rateMax; $i++ )
            echo '<th align="center">'.$i.'</th>';

        echo '</tr>
            </thead>
    
            <tbody>
                <tr>';
        
        for ( $i = $rateMin; $i <= $rateMax; $i++ )
            echo '<td align="center"><input type="radio" name="'.$question['name'].'" value="'.$i.'" /></td>';

        echo ' </tr>
            </tbody>
        </table>
        </p>';

    }

    private function render_comment( $question )
    {
        echo '<p><h3>'.$question['title'].'</h3>';
        echo '<textarea name="'.$question['name'].'" rows="6" style="width:100%;"></textarea>';
        echo '</p>';
    }

    private function render_text( $question )
    {
        echo '<p><h3>'.$question['title'].'</h3>';
        echo '<input type="text" name="'.$question['name'].'" style="width:100%;" />';
        echo '</p>';
    }

 };

