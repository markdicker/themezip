<?php
@ob_start();
@session_start();
include_once '../../../wp-config.php';

global $post, $wpdb, $woocommerce;

// error_log( print_r( $_REQUEST, true ));

if ($_REQUEST['action'] == 'course-filter-by-date') {
    $selected_value = $_REQUEST['a_selected_value'];
    $prefered_venue_value = $_REQUEST['a_preferred_venue_value'];
    $trainer_id = $_REQUEST['a_get_trainer_id'];

    $events = get_posts(

        array(
            'posts_per_page' => -1,
            'order' => 'DESC',
            'nopaging' => true,
            'post_type' => 'product_variation',
            'post_status' => 'publish',
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'relation' => 'OR',
                    array(
                        array(
                            'key' => '_trainer_code',
                            'value' => "none",
                        ),
                        array(
                            'key' => '_trainer_code',
                            'compare' => 'NOT EXIST',
                        ),
                    ),
                ),
                //array (
                array(
                    'key' => '_venue_code',
                    'value' => $prefered_venue_value,
                    'compare' => 'IN',
                ),
                //),
                //array (
                array(
                    'key' => '_start_date',
                    'value' => time(),
                    'compare' => '>=',
                ),
                //),
            ),
        )
    );

    $all_other_events = get_posts(

        array(
            'posts_per_page' => -1,
            'order' => 'DESC',
            'nopaging' => true,
            'post_type' => 'product_variation',
            'post_status' => 'publish',
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'relation' => 'OR',
                    array(
                        array(
                            'key' => '_trainer_code',
                            'value' => "none",
                        ),
                        array(
                            'key' => '_trainer_code',
                            'compare' => 'NOT EXIST',
                        ),
                    ),
                ),
                //array (
                array(
                    'key' => '_venue_code',
                    'value' => $prefered_venue_value,
                    'compare' => 'NOT IN',
                ),
                //),
                //array (
                array(
                    'key' => '_start_date',
                    'value' => time(),
                    'compare' => '>=',
                ),

                //)
            ),
        )
    );

    //debug( 'events', $events );

    // $events = array_merge( $events, $all_other_events );
    // foreach( $all_other_events as $e )
    //     $events[] = $e;

    $available = array();

    foreach ($events as $event) {
        $calendar_data = get_post_meta($event->ID, '_calendar_data', true);

        // Get venue

        if ($calendar_data['venue']['key'] != "none") {
            // debug( "calendar_data", $calendar_data );

            $venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

            $venue_meta = get_post_meta($venue->ID, '_venues_meta', true);

            if ("" == $venue_meta) {
                $venue_meta = array
                    (
                    'address' => "",
                    'phone' => "",
                    'email' => "",
                    'url' => "",
                );
            }
        } else {
            $venue_meta = array
                (
                'address' => "",
                'phone' => "",
                'email' => "",
                'url' => "",
            );
        }

        // debug( "venue", $venue_meta  );

        $available[date("Y-m-d H:i", strtotime($calendar_data['start_date_time']))] = array(
            'id' => $event->ID,
            'date' => date("Y-m-d H:i", strtotime($calendar_data['start_date_time'])),
            'fDate' => date("d/m/Y H:i", strtotime($calendar_data['start_date_time'])),
            'tDate' => date("d/m/Y H:i", strtotime($calendar_data['end_date_time'])),
            'course' => $calendar_data['product']['name'],
            'venue' => $calendar_data['venue']['name'],
            'address' => preg_split("/\\r\\n|\\r|\\n/", $venue_meta['address']),
            'phone' => $venue_meta['phone'],
            'email' => $venue_meta['email'],
            'url' => $venue_meta['url'],
            'details' => preg_split("/\\r\\n|\\r|\\n/", $calendar_data['notes']),
            'attendees' => 0, // get_attendee_count( $event->ID )
            'limit' => $calendar_data['product']['places'],
        );
    }

    $also_available = array();

    foreach ($all_other_events as $event) {
        $calendar_data = get_post_meta($event->ID, '_calendar_data', true);

        // Get venue

        if ($calendar_data['venue']['key'] != "none") {
            // debug( "calendar_data", $calendar_data );

            $venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

            $venue_meta = get_post_meta($venue->ID, '_venues_meta', true);

            if ("" == $venue_meta) {
                $venue_meta = array
                    (
                    'address' => "",
                    'phone' => "",
                    'email' => "",
                    'url' => "",
                );
            }
        } else {
            $venue_meta = array
                (
                'address' => "",
                'phone' => "",
                'email' => "",
                'url' => "",
            );
        }

        //debug( "venue", $venue_meta  );

        $course_avail_postcode = get_post_meta($event->ID, '_course_postcode', true);

        /* Get trainer request start */
        $get_calender_data = get_post_meta($event->ID, '_calendar_data', true);
        $cal_data_new = $get_calender_data['trainer_request'];

        $user_d_new = $cal_data_new;

        unset($user_d_new['trainer_id']);
        unset($user_d_new['name']);
        unset($user_d_new['confirmed']);

        if (in_array($trainer_id, array_column($user_d_new, 'trainer_id'))) { // search value in the array
            $booked_course_trainer = "Applied";
            $booked_color = "background-color:#F14E63 !important;color:#ffffff";
            $booked_class = "";
        } else {
            $booked_course_trainer = "Apply";
            $booked_color = "background-color:#EBE9EB;color:#1D469F";
            $booked_class = "booking_request";
        }

        /* Get trainer request end */

        $also_available[date("Y-m-d H:i", strtotime($calendar_data['start_date_time']))] = array(
            'id' => $event->ID,
            'date' => date("Y-m-d H:i", strtotime($calendar_data['start_date_time'])),
            'fDate' => date("d/m/Y H:i", strtotime($calendar_data['start_date_time'])),
            'tDate' => date("d/m/Y H:i", strtotime($calendar_data['end_date_time'])),
            'course' => $calendar_data['product']['name'],
            'venue' => $calendar_data['venue']['name'],
            'address' => preg_split("/\\r\\n|\\r|\\n/", $venue_meta['address']),
            'phone' => $venue_meta['phone'],
            'email' => $venue_meta['email'],
            'url' => $venue_meta['url'],
            'details' => preg_split("/\\r\\n|\\r|\\n/", $calendar_data['notes']),
            'attendees' => 0, // get_attendee_count( $event->ID )
            'limit' => $calendar_data['product']['places'],
            'postcode' => $course_avail_postcode,
            'bookedcourse' => $booked_course_trainer,
            'bookedcolor' => $booked_color,
            'bookedclass' => $booked_class,
        );
    }

    ksort($available, SORT_NATURAL);
    ksort($also_available, SORT_NATURAL);

    foreach ($also_available as $e) {
        $available[] = $e;
    }

    $available_old = $available;

    $available_reverse = array_reverse($available);

    $available_new = $available_reverse;

    if ($selected_value == 'new') {

        $available_sort = $available_new;

    } else {

        $available_sort = $available_old;

    }

    foreach ($available_sort as $available_sorts) {

        $available_id = $available_sorts['id'];
        $available_date = $available_sorts['date'];
        $available_fDate = $available_sorts['fDate'];
        $available_tDate = $available_sorts['tDate'];
        $available_course = $available_sorts['course'];
        $available_details = $available_sorts['details'];
        $available_venue = $available_sorts['venue'];
        $available_address = $available_sorts['address'];
        $available_phone = $available_sorts['phone'];
        $available_email = $available_sorts['email'];
        $available_url = $available_sorts['url'];
        $available_postcode = $available_sorts['postcode'];
        $available_bookedcourse = $available_sorts['bookedcourse'];
        $available_bookedcolor = $available_sorts['bookedcolor'];
        $available_bookedclass = $available_sorts['bookedclass'];

        $frame_html .= '<tr >
													<td data-value="' . $available_date . '"><p>' . $available_fDate . '<br /><br />' . $available_tDate . '</p></td>
													<td><p><b>' . $available_course . '</b></p></td><td><p><b>' . $available_venue . '</b></p><div>';

        foreach ($available_address as $available_addres) {

            $frame_html .= $available_addres . '<br>';

        }
        $frame_html .= "<br>";
        //if($available_phone){ $frame_html .= $available_phone.'<br>'; }
        if ($available_postcode) {$frame_html .= $available_postcode . '<br>';}
        if ($available_email) {$frame_html .= $available_email . '<br>';}
        if ($available_url) {$frame_html .= $available_url . '<br>';}

        $frame_html .= '</div>'.
                        '</td>'.
                        '<td><p class="booking_request-whole"><button data-course="' . $available_id . '" style="' . $available_bookedcolor . '" class="' . $available_bookedclass . '">' . $available_bookedcourse . '</button></p></td>'.
                        '</tr>';

    }

    echo $frame_html;

}

/*trainer docs start*/

if ($_REQUEST['status'] == 'update_trainer_doc_info') 
{
    /*trainer docs start*/
    // error_log( "Update trainer info" );
    
    
    // check_admin_referer( "Trainer_Profile_nonce", "nonce" );
    
    
    extract( $_REQUEST );
    
    if ( !wp_verify_nonce ( $nonce, "Trainer_Profile_nonce" ) ) 
    {
        wp_send_json_error( 400, array() );
        die();
    }

    // error_log( print_r( $_FILES, true ) );

    $trainer_meta = get_post_meta( $upload_trainer_id, "_trainers_meta", true );

    // error_log( print_r( $trainer_meta, true ) );

    $trainer_meta['phone'] = $phone;

    $trainer_meta['address'] = $address;
        
    $trainer_meta['dateQualExpd'] = $dateQualExpd;

    $trainer_meta['preferredVenues'] = $preferredVenues;

    // error_log( print_r( $preferredVenues, true ) );

    update_post_meta(  $upload_trainer_id, "_trainers_meta", $trainer_meta );

    // error_log( print_r( $_FILES, true ) );

    echo "success";

    die();

    
}
if ( 0 ) { // if ($_REQUEST['action'] == 'update_trainer_doc_info') {

    // error_log( "Update trainer info" );

    check_admin_referer( "Trainer_Profile_nonce", "nonce" );

    // error_log( "Post Data ");
    // error_log( print_r( $_POST, true ) );

    // error_log( "Request ");
    // error_log( print_r( $_REQUEST, true ) );

    // error_log( print_r( $_FILES, true ) );

    require_once ABSPATH . 'wp-admin/includes/image.php';

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $trainer_id = $_REQUEST['upload_trainer_id'];

    $file_name = $_FILES['upload_trainer_certificates']['name'];

    $file_tmp_name = $_FILES['upload_trainer_certificates']['tmp_name'];

    $uploadedfile = $_FILES['upload_trainer_certificates'];

    $upload_overrides = array('test_form' => false);

    $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

    $attach_id = $movefile["url"];

    $trainer_docs_exists = get_post_meta($trainer_id, '_trainer_meta_documentation', true);

    if (!empty($trainer_docs_exists)) {
        array_push($trainer_docs_exists, $attach_id);
        $update_data = $trainer_docs_exists;
    } else {
        $update_data[] = $attach_id;
    }

    update_post_meta($trainer_id, '_trainer_meta_documentation', $update_data);

    echo "success";

}
/*trainer docs end*/

/*filter by course type start*/
if ($_REQUEST['action'] == 'course-filter-by-coursetype') {
    $selected_value = $_REQUEST['a_selected_value'];
    $prefered_venue_value = $_REQUEST['a_preferred_venue_value'];
    $trainer_id = $_REQUEST['a_get_trainer_id'];

    $events = get_posts(

        array(
            'posts_per_page' => -1,
            'order' => 'DESC',
            'nopaging' => true,
            'post_type' => 'product_variation',
            'post_status' => 'publish',
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'relation' => 'OR',
                    array(
                        array(
                            'key' => '_trainer_code',
                            'value' => "none",
                        ),
                        array(
                            'key' => '_trainer_code',
                            'compare' => 'NOT EXIST',
                        ),
                    ),
                ),
                //array (
                array(
                    'key' => '_venue_code',
                    'value' => $prefered_venue_value,
                    'compare' => 'IN',
                ),
                //),
                //array (
                array(
                    'key' => '_start_date',
                    'value' => time(),
                    'compare' => '>=',
                ),
                //),
            ),
        )
    );

    $all_other_events = get_posts(

        array(
            'posts_per_page' => -1,
            'order' => 'DESC',
            'nopaging' => true,
            'post_type' => 'product_variation',
            'post_status' => 'publish',
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'relation' => 'OR',
                    array(
                        array(
                            'key' => '_trainer_code',
                            'value' => "none",
                        ),
                        array(
                            'key' => '_trainer_code',
                            'compare' => 'NOT EXIST',
                        ),
                    ),
                ),
                //array (
                array(
                    'key' => '_venue_code',
                    'value' => $prefered_venue_value,
                    'compare' => 'NOT IN',
                ),
                //),
                //array (
                array(
                    'key' => '_start_date',
                    'value' => time(),
                    'compare' => '>=',
                ),

                //)
            ),
        )
    );

    //debug( 'events', $events );

    // $events = array_merge( $events, $all_other_events );
    // foreach( $all_other_events as $e )
    //     $events[] = $e;

    $available = array();

    foreach ($events as $event) {
        $calendar_data = get_post_meta($event->ID, '_calendar_data', true);

        // Get venue

        if ($calendar_data['venue']['key'] != "none") {
            // debug( "calendar_data", $calendar_data );

            $venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

            $venue_meta = get_post_meta($venue->ID, '_venues_meta', true);

            if ("" == $venue_meta) {
                $venue_meta = array
                    (
                    'address' => "",
                    'phone' => "",
                    'email' => "",
                    'url' => "",
                );
            }
        } else {
            $venue_meta = array
                (
                'address' => "",
                'phone' => "",
                'email' => "",
                'url' => "",
            );
        }

        // debug( "venue", $venue_meta  );

        $available[date("Y-m-d H:i", strtotime($calendar_data['start_date_time']))] = array(
            'id' => $event->ID,
            'date' => date("Y-m-d H:i", strtotime($calendar_data['start_date_time'])),
            'fDate' => date("d/m/Y H:i", strtotime($calendar_data['start_date_time'])),
            'tDate' => date("d/m/Y H:i", strtotime($calendar_data['end_date_time'])),
            'course' => $calendar_data['product']['name'],
            'venue' => $calendar_data['venue']['name'],
            'address' => preg_split("/\\r\\n|\\r|\\n/", $venue_meta['address']),
            'phone' => $venue_meta['phone'],
            'email' => $venue_meta['email'],
            'url' => $venue_meta['url'],
            'details' => preg_split("/\\r\\n|\\r|\\n/", $calendar_data['notes']),
            'attendees' => 0, // get_attendee_count( $event->ID )
            'limit' => $calendar_data['product']['places'],
        );
    }

    $also_available = array();

    foreach ($all_other_events as $event) {
        $calendar_data = get_post_meta($event->ID, '_calendar_data', true);

        // Get venue

        if ($calendar_data['venue']['key'] != "none") {
            // debug( "calendar_data", $calendar_data );

            $venue = get_page_by_path($calendar_data['venue']['key'], OBJECT, 'venues');

            $venue_meta = get_post_meta($venue->ID, '_venues_meta', true);

            if ("" == $venue_meta) {
                $venue_meta = array
                    (
                    'address' => "",
                    'phone' => "",
                    'email' => "",
                    'url' => "",
                );
            }
        } else {
            $venue_meta = array
                (
                'address' => "",
                'phone' => "",
                'email' => "",
                'url' => "",
            );
        }

        //debug( "venue", $venue_meta  );

        /* Get trainer request start */
        $get_calender_data = get_post_meta($event->ID, '_calendar_data', true);
        $cal_data_new = $get_calender_data['trainer_request'];
        $product_name = $get_calender_data['product']['name'];

        $user_d_new = $cal_data_new;

        unset($user_d_new['trainer_id']);
        unset($user_d_new['name']);
        unset($user_d_new['confirmed']);

        if (in_array($trainer_id, array_column($user_d_new, 'trainer_id'))) { // search value in the array
            $booked_course_trainer = "Applied";
            $booked_color = "background-color:#F14E63 !important;color:#ffffff";
            $booked_class = "";
        } else {
            $booked_course_trainer = "Apply";
            $booked_color = "background-color:#EBE9EB;color:#1D469F";
            $booked_class = "booking_request";
        }

        /* Get trainer request end */

        if ($selected_value == $product_name) {
            $also_available[date("Y-m-d H:i", strtotime($calendar_data['start_date_time']))] = array(
                'id' => $event->ID,
                'date' => date("Y-m-d H:i", strtotime($calendar_data['start_date_time'])),
                'fDate' => date("d/m/Y H:i", strtotime($calendar_data['start_date_time'])),
                'tDate' => date("d/m/Y H:i", strtotime($calendar_data['end_date_time'])),
                'course' => $calendar_data['product']['name'],
                'venue' => $calendar_data['venue']['name'],
                'address' => preg_split("/\\r\\n|\\r|\\n/", $venue_meta['address']),
                'phone' => $venue_meta['phone'],
                'email' => $venue_meta['email'],
                'url' => $venue_meta['url'],
                'details' => preg_split("/\\r\\n|\\r|\\n/", $calendar_data['notes']),
                'attendees' => 0, // get_attendee_count( $event->ID )
                'limit' => $calendar_data['product']['places'],
                'postcode' => $course_avail_postcode,
                'bookedcourse' => $booked_course_trainer,
                'bookedcolor' => $booked_color,
                'bookedclass' => $booked_class,
            );
        }

    }

    ksort($available, SORT_NATURAL);
    ksort($also_available, SORT_NATURAL);

    foreach ($also_available as $e) {
        $available[] = $e;
    }

    $available_old = $available;

    $available_reverse = array_reverse($available);

    $available_new = $available_reverse;

    foreach ($available_new as $key => $available_sorts) {

        $available_id = $available_sorts['id'];
        $available_date = $available_sorts['date'];
        $available_fDate = $available_sorts['fDate'];
        $available_tDate = $available_sorts['tDate'];
        $available_course = $available_sorts['course'];
        $available_details = $available_sorts['details'];
        $available_venue = $available_sorts['venue'];
        $available_address = $available_sorts['address'];
        $available_phone = $available_sorts['phone'];
        $available_email = $available_sorts['email'];
        $available_url = $available_sorts['url'];
        $avail_booked_course_trainer = $available_sorts['bookedcourse'];
        $avail_bookedcolor = $available_sorts['bookedcolor'];
        $avail_bookedclass = $available_sorts['bookedclass'];

        $frame_html .= '<tr >'.
                        '.<td data-value="' . $available_date . '"><p>' . $available_fDate . ' ' . '<br /><br />' . $available_tDate . '</p></td>'.
                        '<td><p><b>' . $available_course . '</b></p></td><td><p><b>' . $available_venue . '</b></p><div>';

        foreach ($available_address as $available_addres) {

            $frame_html .= $available_addres . '<br>';

        }
        $frame_html .= "<br>";
        if ($available_phone) {$frame_html .= $available_phone . '<br>';}
        if ($available_email) {$frame_html .= $available_email . '<br>';}
        if ($available_url) {$frame_html .= $available_url . '<br>';}

        $frame_html .= '</div>'.
                        '</td>'.
                        '<td><p class="booking_request-whole"><button data-course="' . $available_id . '" style="' . $avail_bookedcolor . '" class="' . $avail_bookedclass . '">' . $avail_booked_course_trainer . '</button></p></td>'.
                        '</tr>';

    }

    echo $frame_html;

}
/*filter by course type end*/
