<?php

    global $cf_areas, $cf_cats, $cf_courses;

?>

<style>
#loading 
{
    position: fixed;
    display:none;
    z-index:999;
    background-color:rgba( 0,0,0,0.5 );
    width:100%;
    height:100%;
    left:0;
    top:0;
}

#spinner
{
    border: 5px solid #f3f3f3;
    border-radius: 50%;
    border-top: 5px solid #3498db;
    width: 60px;
    height: 60px;
    -webkit-animation: spin 2s linear infinite;
    animation: spin 2s linear infinite;
    position: absolute;
    left: calc( 50% - 30px );
    /* right: 0; */
    text-align: center;
    margin: 0 auto;
    top: calc( 50% - 30px );
    /* bottom: 0; */
}
/* Safari */
@-webkit-keyframes spin 
{
    0% { -webkit-transform: rotate(0deg); }
    100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin 
{
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

</style>

<script>

const CATEGORY_BIT = 0x01;
const COURSE_BIT = 0x02;
const AREA_BIT = 0x04;
const DATE_BIT = 0x08;

const CAN_SEARCH = CATEGORY_BIT | COURSE_BIT | AREA_BIT | DATE_BIT ;

// console.log( CATEGORY_BIT, COURSE_BIT, AREA_BIT, DATE_BIT, CAN_SEARCH );

var fields_entered = 0;

</script>

<form class='course-finder'>
    <div class="elementor-row course-finder">
        
        <div class="elementor-column elementor-col-20 elementor-top-column elementor-element">
            <select id="cs_category" name="cs_category" class="cs_category" >
                <option value="">Choose Category</option>
                <?php foreach ( $cf_cats as $cats ) :
                    $cat = get_term( $cats['cat'], "product_cat" ); 
                ?>

                    <option value="<?php echo $cat->term_id; ?>" data-courses="<?php echo implode( ",", $cats['crs']); ?>"><?php echo $cat->name; ?></option>

                <?php endforeach; ?>  
            </select>
            
        </div>

        <div class="elementor-column elementor-col-30 elementor-top-column elementor-element">
            <select id="cs_id" name="cs_id" class="cs_id" >
                <option value="">Choose Course</option>                
            </select>
        </div>

        <div class="elementor-column elementor-col-15 elementor-top-column elementor-element">
            <select id="cs_location" name="cs_location" class="cs_location" >
                <option value="">Select Area</option>
                <?php foreach( $cf_areas as $key => $area ) : ?>
                    <option value="<?php echo $key; ?>"><?php echo $area; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element">
            <input type="hidden" id="sdate" value="" />
            <input type="hidden" id="edate" value="" />
            <span class='cs_daterange' >
                <input id="longdate" value="Select Date Range" style="border:0;"/>
                <i id="date-range-calendar" class="fa fa-calendar"></i>
            </span>

        </div>

        <div class="elementor-column elementor-col-10 elementor-top-column elementor-element">
            <input id="cs_submit" type="submit" class='cs_search' value="Search" />
        </div>

    </div>
    <div class="elementor-row">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element">
            <div id="cf_error" class="error"></div>
        </div>
    </div>
</form>

<div class="elementor-row">
    <div class="elementor-column elementor-top-column elementor-element home_book_tables">
        <div class="home_book_table"></div>
    </div>
</div>
