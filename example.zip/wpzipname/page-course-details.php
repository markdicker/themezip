<?php

// var_dump( get_query_var( 'trainer_id' ) );

// var_dump( get_query_var( 'course_id' ) );

$profile = get_user_meta( get_current_user_id(), "_profile", true );

if ( $post->post_name != $profile && current_user_can( 'trainer' ) )
    wp_redirect( site_url( '/trainers/'.$profile, 302 ) );

$layout = 'full';

get_header();

?>
    <div id="body">
    	<div class="container">
        	<div class="content-pad-3x">
                <div class="row">
                    <div id="content" class="<?php echo $layout!='full'?'col-md-9':'col-md-12' ?><?php echo ($layout == 'left') ? " revert-layout":"";?>">
                        <div class="blog-listing">
                            <h2>Trainer Portal : <?php echo $post->post_title; ?></h2>
                            <br />
                            <ul class="nav nav-tabs" id="trainerPortal">
                                <li class="active"><a data-toggle="tab" href="#schedule">Your Schedule</a></li>                            
                                <li><a data-toggle="tab" href="#courses">Available Courses</a></li>
                                <li><a data-toggle="tab" href="#course" style="display:none;">Course Details</a></li>

                                <li class="dropdown right">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Settings
                                    <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a data-toggle="tab" href="#profile">Profile</a></li>
                                        <?php if ( current_user_can( 'trainer' ) ) : ?>
                                            <li><a href="<?php echo wp_logout_url( '/trainers/' ); ?>">Logout</a></li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <div id="schedule" class="tab-pane fade in active">
                                    <h3>You are booked for the following courses.</h3>

                                    <?php                                                                       
                                    global $theme_twig;

                                        $injector = array( 
                                            'trainer' => $post->post_name,
                                            'schedule' => array( 
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "First Aid",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                                array ( 
                                                    'date' => '2016-07-02',
                                                    'course' => "Defibrillator Training",
                                                    'venue' => 'Siren Training Centre',
                                                    'attendees' => 12
                                                ),
                                            )
                                        );

                                        $schedule = $theme_twig->loadTemplate( 'trainer/_schedule.html' );

                                        echo $schedule->render( $injector );
                                        
                                    ?>

                                </div>
                                <div id="courses" class="tab-pane fade">
                                    <h3>These courses are available.</h3>
                                    <p>Unassigned courses</p>
                                </div>
                                <div id="profile" class="tab-pane fade">
                                    <h3>Your Details</h3>
                                    <p>Profile data</p>
                                </div>

                                <div id="course" class="tab-pane fade">
                                    <h3>Course Details</h3>
                                    <p>Course data</p>
                                </div>

                            </div>
                        </div>
                    </div><!--/content-->
                </div><!--/row-->
            </div><!--/content-pad-->
        </div><!--/container-->
    </div><!--/body-->

    <script>

    var $trainerID = '<?php echo $post->post_name; ?>';

    jQuery(document).ready(function(){
        // jQuery('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
        //     localStorage.setItem('activeTab', jQuery(e.target).attr('href'));
        // });
        
        // var activeTab = localStorage.getItem('activeTab');

        // // on load of the page: switch to the currently selected tab
        // var hash = window.location.hash;

        // if(activeTab)
        // {
        //     jQuery('#trainerPortal a[href="' + activeTab + '"]').tab('show');
        // }


        // Javascript to enable link to tab
        var hash = document.location.hash;
        var prefix = "_";
        if (hash) 
        {
            jQuery('.nav-tabs a[href='+hash.replace(prefix,"")+']').tab('show');
        } 

        // Change hash for page-reload
        jQuery('.nav-tabs a').on('shown.bs.tab', function (e) 
        {
            window.location.hash = e.target.hash.replace("#", "#" + prefix);
        });

        jQuery('.collapse').on('show.bs.collapse', function () {
            jQuery('.collapse.in').collapse('hide');
        });
    });



    </script>
<?php

get_footer();

?>
